<?php echo e($slot); ?>

<?php /**PATH /home/wahaname/public_html/edukasi/vendor/laravel/framework/src/Illuminate/Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>