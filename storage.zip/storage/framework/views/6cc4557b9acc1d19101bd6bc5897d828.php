<?php $__env->startSection('content'); ?>
<div class="pcoded-content">
    <!-- Page-header start -->
    <div class="page-header">
        <div class="page-block">
            <div class="row align-items-center">
                <div class="col-md-8">
                    <div class="page-header-title">
                        <h5 class="m-b-10">Periksa Jawaban Kuis</h5>
                        <p class="m-b-0">Siswa: <strong><?php echo e($attempt->student->name); ?></strong> | Kuis: <strong><?php echo e($attempt->quiz->title); ?></strong></p>
                    </div>
                </div>
                <div class="col-md-4">
                    <ul class="breadcrumb-title">
                        <li class="breadcrumb-item"><a href="<?php echo e(route('instructor.dashboard')); ?>"><i class="fa fa-home"></i></a></li>
                        <li class="breadcrumb-item"><a href="<?php echo e(route('instructor.quiz.results', $attempt->quiz_id)); ?>">Hasil Kuis</a></li>
                        <li class="breadcrumb-item"><a href="#!">Periksa</a></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    <!-- Page-header end -->

    <div class="pcoded-inner-content">
        <div class="main-body">
            <div class="page-wrapper">
                <div class="page-body">
                    <div class="row d-flex justify-content-center">
                        <div class="col-md-10 col-lg-8">
                            <!-- Kartu Hasil Ringkas -->
                            <div class="card">
                                <div class="card-body text-center">
                                    <?php if($attempt->status == 'passed'): ?>
                                        <h4 class="text-success">Status: Lulus</h4>
                                    <?php else: ?>
                                        <h4 class="text-danger">Status: Gagal</h4>
                                    <?php endif; ?>
                                    <h5>Skor: <strong><?php echo e(rtrim(rtrim(number_format($attempt->score, 2, ',', '.'), '0'), ',')); ?></strong></h5>
                                </div>
                            </div>

                            <!-- Rincian Jawaban -->
                            <div class="card">
                                <div class="card-header">
                                    <h5>Rincian Jawaban Siswa</h5>
                                </div>
                                <div class="card-block">
                                    <?php $__currentLoopData = $attempt->quiz->questions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="mb-5">
                                            <h6>Soal <?php echo e($index + 1); ?>:</h6>
                                            <p class="lead"><?php echo nl2br(e($question->question_text)); ?></p>
                                            <?php
                                                $studentAnswersForThisQuestion = $attempt->answers->where('question_id', $question->id);
                                                $studentAnswerIds = $studentAnswersForThisQuestion->pluck('selected_option_id')->toArray();
                                                $isQuestionCorrect = $studentAnswersForThisQuestion->isNotEmpty() && $studentAnswersForThisQuestion->first()->is_correct;
                                            ?>
                                            <div class="options-review">
                                                <?php $__currentLoopData = $question->options; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <?php
                                                        $isStudentAnswer = in_array($option->id, $studentAnswerIds);
                                                        $isCorrectAnswer = $option->is_correct;
                                                        $labelClass = '';
                                                        if ($isStudentAnswer && $isCorrectAnswer) { $labelClass = 'bg-success text-white'; } 
                                                        elseif ($isStudentAnswer && !$isCorrectAnswer) { $labelClass = 'bg-danger text-white'; } 
                                                        elseif (!$isStudentAnswer && $isCorrectAnswer) { $labelClass = 'bg-info text-white'; }
                                                    ?>
                                                    <div class="p-2 rounded mb-2 <?php echo e($labelClass); ?>">
                                                        <?php if($isStudentAnswer): ?>
                                                            <i class="fa fa-check-circle-o mr-2"></i> <strong>Jawaban Siswa</strong>
                                                        <?php elseif($isCorrectAnswer): ?>
                                                            <i class="fa fa-check mr-2"></i> <strong>Kunci Jawaban</strong>
                                                        <?php else: ?>
                                                            <i class="fa fa-circle-o mr-2" style="opacity: 0.5;"></i>
                                                        <?php endif; ?>
                                                        <?php echo e($option->option_text); ?>

                                                    </div>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </div>
                                            <?php if($question->explanation): ?>
                                                <div class="alert alert-info mt-3">
                                                    <strong><i class="fa fa-lightbulb-o"></i> Penjelasan:</strong><br>
                                                    <?php echo nl2br(e($question->explanation)); ?>

                                                </div>
                                            <?php endif; ?>
                                        </div>
                                        <?php if(!$loop->last): ?><hr><?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app-layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/wahaname/public_html/edukasi/resources/views/instructor/quizzes/results/show.blade.php ENDPATH**/ ?>