 

<?php $__env->startPush('styles'); ?>
<style>
    /* Custom styles for our new, self-contained accordion */
    .custom-accordion .module-item {
        /* Creates the separator lines */
        border-bottom: 1px solid #f0f0f0;
    }
    .custom-accordion .module-item:first-of-type {
        border-top: 1px solid #f0f0f0;
    }

    .custom-accordion .module-title {
        display: flex;
        align-items: center;
        padding: 15px 20px;
        cursor: pointer;
        transition: background-color 0.3s ease;
        background-color: #fff;
        color: #333;
    }

    .custom-accordion .module-title:hover {
        background-color: #f5f5f5;
    }

    /* Style for the active/open module title */
    .custom-accordion .module-title.active {
        background-color: #4680ff;
        color: #fff;
    }
    .custom-accordion .module-title.active .badge-warning {
        background-color: #fff;
        color: #f8b425;
    }


    /* The content area that slides up and down */
    .custom-accordion .module-content {
        max-height: 0;
        overflow: hidden;
        transition: max-height 0.3s ease-out;
        background-color: #fff;
        padding: 0 20px; /* Add padding for a cleaner look when open */
    }
</style>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    <div class="pcoded-content">
        <div class="page-header">
            <div class="page-block">
                <div class="row align-items-center">
                    <div class="col-md-8">
                        <div class="page-header-title">
                            <h5 class="m-b-10"><?php echo e($course->title); ?></h5>
                            <p class="m-b-0"><?php echo e($course->instructor->name); ?></p>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <ul class="breadcrumb-title">
                            <li class="breadcrumb-item"><a href="#"><i class="fa fa-home"></i></a></li>
                            <li class="breadcrumb-item"><a href="#">Kursus Saya</a></li>
                            <li class="breadcrumb-item"><a href="#!"><?php echo e($course->title); ?></a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
        <div class="pcoded-inner-content">
            <div class="main-body">
                <div class="page-wrapper">
                    <div class="page-body">
                        <?php if($is_preview): ?>
                            <div class="alert alert-warning text-center text-dark" style="background-color: #f2e529;">
                                <strong>Mode Pratinjau</strong><br>
                                Anda melihat halaman ini sebagai Admin/Superadmin/Instruktur. Progres tidak akan disimpan.
                            </div>
                        <?php endif; ?>

                        <?php if(session('success')): ?>
                            <div class="alert alert-success"><?php echo e(session('success')); ?></div>
                        <?php endif; ?>
                        <?php if(session('error')): ?>
                            <div class="alert alert-danger"><?php echo e(session('error')); ?></div>
                        <?php endif; ?>

                        <div class="row">
                            
                            <div class="col-lg-8">
                                <div class="card">
                                    <div class="card-header">
                                        <h5 id="lesson-title">Selamat Datang di Kursus!</h5>
                                    </div>
                                    <div class="card-block" id="lesson-content" style="min-height: 500px;">
                                        <div class="text-center text-muted">
                                            <p><i class="fa fa-arrow-left fa-2x"></i></p>
                                            <h5>Pilih pelajaran dari daftar isi di sebelah kanan untuk memulai.</h5>
                                            <hr>
                                            <p class="mt-4"><strong>Deskripsi Kursus:</strong></p>
                                            <div><?php echo $course->description; ?></div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            
                            <div class="col-lg-4">
                                <div class="card">
                                    <div class="card-header">
                                        <h5 class="card-header-text">Daftar Isi Kursus</h5>
                                    </div>
                                    <div class="card-block accordion-block">
                                        <div class="custom-accordion" id="custom-accordion">

                                            <?php $__empty_1 = true; $__currentLoopData = $course->modules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $module): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                                <?php
                                                    // Logic to check if the module is locked for the student
                                                    $isLocked =
                                                        !$is_preview &&
                                                        $module->points_required > 0 &&
                                                        $currentCoursePoints < $module->points_required;
                                                ?>

                                                <div class="module-item">
                                                    <!-- Accordion Module Title -->
                                                    <div class="module-title waves-effect waves-light">
                                                        <span>
                                                            <?php if($isLocked): ?>
                                                                <i class="fa fa-lock mr-2"></i>
                                                            <?php endif; ?>
                                                            <strong><?php echo e($module->title); ?></strong>
                                                        </span>
                                                        <?php if($isLocked): ?>
                                                            <span class="badge badge-warning ml-auto"><?php echo e($module->points_required); ?> Poin Dibutuhkan</span>
                                                        <?php endif; ?>
                                                    </div>
                                                    <!-- End Accordion Module Title -->

                                                    <!-- Accordion Content (List of Lessons) -->
                                                    <div class="module-content">
                                                        <ul class="list-group list-group-flush">
                                                             <li class="list-group-item d-flex justify-content-between align-items-center">
                                                                <a href="#" class="load-leaderboard-btn text-dark" data-module-id="<?php echo e($module->id); ?>">
                                                                    <i class="fa fa-bar-chart mr-2"></i>
                                                                    Leaderboard <?php echo e($module->title); ?>

                                                                </a>
                                                            </li>
                                                            <?php $__currentLoopData = $module->lessons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lesson): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <?php
                                                                    // Logic to determine the icon based on lesson type
                                                                    $icon = 'bi bi-file-text'; // Default icon
                                                                    $type = strtolower(class_basename($lesson->lessonable_type));

                                                                    if ($type === 'lessonvideo') $icon = 'bi bi-collection-play';
                                                                    if ($type === 'quiz') $icon = 'bi bi-pencil-square';
                                                                    if ($type === 'lessondocument') $icon = 'bi bi-file-earmark-pdf';
                                                                    if ($type === 'lessonlinkcollection') $icon = 'bi bi-folder2-open';
                                                                    if ($type === 'lessonassignment') $icon = 'bi bi-clipboard2';
                                                                    if ($type === 'lessonpoint') $icon = 'bi bi-chat-left-quote';
                                                                ?>

                                                                <li class="list-group-item d-flex justify-content-between align-items-center <?php echo e($isLocked ? 'bg-light' : ''); ?>" id="sidebar-lesson-<?php echo e($lesson->id); ?>">
                                                                    
                                                                    <a href="#" class="load-lesson <?php echo e($isLocked ? 'text-muted' : 'text-dark'); ?>" data-lesson-id="<?php echo e($lesson->id); ?>">
                                                                        <i class="<?php echo e($icon); ?> mr-2"></i>
                                                                        <?php echo e($lesson->title); ?>

                                                                    </a>
                                                                    <?php if(in_array($lesson->id, $completedLessonIds)): ?>
                                                                        <i class="fa fa-check-circle text-success"></i>
                                                                    <?php endif; ?>
                                                                </li>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        </ul>
                                                    </div>
                                                    <!-- End Accordion Content -->
                                                </div>

                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                                <p class="text-muted p-3">Kursus ini belum memiliki modul.</p>
                                            <?php endif; ?>

                                        </div>

                                        
                                        <div class="mt-4">
                                            <button class="btn btn-outline-primary w-100 mb-2" id="load-leaderboard">
                                                <i class="fa fa-bar-chart mr-2"></i> Leaderboard
                                            </button>
                                            <button class="btn btn-outline-primary w-100 mb-2" id="load-review-form"
                                                <?php if(!$allLessonsCompleted && !$is_preview): ?>
                                                    disabled
                                                    title="Selesaikan semua pelajaran untuk memberikan feedback"
                                                <?php endif; ?>>
                                                <i class="fa fa-star mr-2"></i> Feedback
                                            </button>
                                            <?php if($isEligibleForCertificate): ?>
                                                <button class="btn btn-outline-primary w-100 mb-2" id="load-certificate-preview">
                                                    <i class="bi bi-award-fill me-2"></i> Sertifikat
                                                </button>
                                                <button class="btn btn-outline-primary w-100 mb-2" id="convert-points-btn" data-toggle="modal" data-target="#conversionModal">
                                                    <i class="fa fa-exchange mr-2"></i> Konversi Poin
                                                </button>
                                            <?php else: ?>
                                                <button class="btn btn-outline-primary w-100 mb-2" disabled>
                                                    <i class="bi bi-award-fill me-2"></i> Sertifikat
                                                </button>
                                                <button class="btn btn-outline-primary w-100 mb-2" disabled>
                                                    <i class="fa fa-exchange mr-2"></i> Konversi Poin
                                                </button>
                                            <?php endif; ?>
                                        </div>

                                    </div>
                                </div>
                            </div>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    
    <?php if($isEligibleForCertificate): ?>
        <div class="modal fade" id="conversionModal" tabindex="-1" role="dialog">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title">Konversi Poin ke Diamond</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <?php
                            $pointsData = Auth::user()->coursePoints()->where('course_id', $course->id)->first();
                            $pointsToConvert = $pointsData->pivot->points_earned ?? 0;
                            $conversionRate = \App\Models\SiteSetting::first()->point_to_diamond_rate ?? 1;
                            $diamondsEarned = floor($pointsToConvert * $conversionRate);
                        ?>

                        <?php if($pointsData && $pointsData->pivot->is_converted_to_diamond): ?>
                            <div class="alert alert-success text-center">
                                <i class="fa fa-check-circle fa-2x mb-2"></i><br>
                                Anda sudah pernah mengonversi poin dari kursus ini.
                            </div>
                        <?php else: ?>
                            <p>Anda akan mengonversi semua poin yang Anda dapatkan dari kursus ini menjadi Diamond.</p>
                            <ul class="list-group">
                                <li class="list-group-item d-flex justify-content-between align-items-center">
                                    Total Poin di Kursus Ini
                                    <span class="text-warning"><?php echo e($pointsToConvert); ?> <i class="ti-medall-alt"></i></span>
                                </li>
                                <li class="list-group-item d-flex justify-content-between align-items-center">
                                    Rasio Konversi
                                    <span>1 Poin = <?php echo e((float) $conversionRate); ?> Diamond</span>
                                </li>
                                <li class="list-group-item d-flex justify-content-between align-items-center">
                                    <strong>Diamond yang Akan Didapat</strong>
                                    <strong class="text-primary"><?php echo e($diamondsEarned); ?> <i class="fa fa-diamond"></i></strong>
                                </li>
                            </ul>
                            <p class="text-muted mt-3"><small>Proses ini hanya bisa dilakukan satu kali per kursus dan tidak dapat dibatalkan.</small></p>
                        <?php endif; ?>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Batal</button>
                        <?php if($pointsData && !$pointsData->pivot->is_converted_to_diamond): ?>
                            <form action="<?php echo e(route('student.course.convert_points', $course->id)); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <button type="submit" class="btn btn-primary">Konfirmasi & Konversi Poin</button>
                            </form>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <script>
        document.addEventListener('DOMContentLoaded', function() {

            // --- START: Custom Accordion Script ---
            const accordion = document.getElementById('custom-accordion');
            if (accordion) {
                const moduleTitles = accordion.querySelectorAll('.module-title');

                moduleTitles.forEach(title => {
                    title.addEventListener('click', function() {
                        const content = this.nextElementSibling;
                        const isAlreadyActive = this.classList.contains('active');

                        moduleTitles.forEach(otherTitle => {
                            if (otherTitle !== this) {
                                otherTitle.classList.remove('active');
                                otherTitle.nextElementSibling.style.maxHeight = null;
                                otherTitle.nextElementSibling.style.padding = "0 20px";
                            }
                        });

                        if (isAlreadyActive) {
                            this.classList.remove('active');
                            content.style.maxHeight = null;
                            content.style.padding = "0 20px";
                        } else {
                            this.classList.add('active');
                            content.style.maxHeight = content.scrollHeight + "px";
                            content.style.padding = "10px 20px";
                        }
                    });
                });
            }
            // --- END: Custom Accordion Script ---


            const lessonLinks = document.querySelectorAll('.load-lesson');
            const lessonTitleEl = document.getElementById('lesson-title');
            const lessonContentEl = document.getElementById('lesson-content');
            const isPreview = <?php echo json_encode($is_preview, 15, 512) ?>;
            let completedLessons = <?php echo json_encode($completedLessonIds, 15, 512) ?>;

            const reviewButton = document.getElementById('load-review-form');
            const totalLessons = <?php echo e($course->lessons->count()); ?>;

            // --- FUNGSI UNTUK MEMUAT KONTEN PELAJARAN ---
            function loadLessonContent(lessonId) {
                lessonTitleEl.innerText = 'Memuat...';
                lessonContentEl.innerHTML = '<div class="text-center p-5"><i class="fa fa-spinner fa-spin fa-3x"></i></div>';

                let url = `/student/lessons/${lessonId}/content`;
                if (isPreview) {
                    url += '?preview=true';
                }

                fetch(url)
                    .then(response => response.json())
                    .then(data => {
                        if (data.success) {
                            lessonTitleEl.innerText = data.title;
                            let completeButtonHtml = '';

                            const sidebarItem = document.getElementById(`sidebar-lesson-${lessonId}`);
                            if (sidebarItem) {
                                const lessonTypeIcon = sidebarItem.querySelector('a.load-lesson > i');
                                const isQuizOrAssignment = lessonTypeIcon.classList.contains('bi-pencil-square') || lessonTypeIcon.classList.contains('bi-clipboard2');
                                const isAlreadyCompleted = sidebarItem.querySelector('.fa-check-circle') !== null;

                                // **FIX**: Added !data.is_locked to ensure the button never shows for locked lessons.
                                if (!data.is_locked && !isQuizOrAssignment && !isPreview && !isAlreadyCompleted) {
                                    completeButtonHtml = `<hr><div class="text-center mt-4"><button class="btn btn-success mark-as-complete-btn" data-lesson-id="${lessonId}"><i class="fa fa-check"></i> Tandai Selesai</button></div>`;
                                }
                            }
                            
                            const discussionHtml = data.discussion_html || '';
                            lessonContentEl.innerHTML = data.html + completeButtonHtml + discussionHtml;

                        } else {
                            lessonTitleEl.innerText = 'Gagal Memuat';
                            lessonContentEl.innerHTML = `<p class="text-danger">${data.message || 'Terjadi kesalahan.'}</p>`;
                        }
                    })
                    .catch(error => {
                        console.error('Error fetching lesson content:', error);
                        lessonTitleEl.innerText = 'Gagal Memuat';
                        lessonContentEl.innerHTML = '<p class="text-danger">Terjadi kesalahan jaringan.</p>';
                    });
            }

            lessonLinks.forEach(link => {
                link.addEventListener('click', function(e) {
                    e.preventDefault();
                    loadLessonContent(this.dataset.lessonId);
                });
            });

            // --- LOGIKA UNTUK TOMBOL FEEDBACK ---
            if (reviewButton) {
                reviewButton.addEventListener('click', function(e) {
                    e.preventDefault();
                    lessonTitleEl.innerText = 'Ulasan & Rating Kursus';
                    lessonContentEl.innerHTML = '<div class="text-center p-5"><i class="fa fa-spinner fa-spin fa-3x"></i></div>';
                    const url = "<?php echo e(route('student.course.review.create', $course->id)); ?>";
                    fetch(url)
                        .then(response => response.json())
                        .then(data => {
                            if (data.success) {
                                lessonContentEl.innerHTML = data.html;
                            } else {
                                lessonContentEl.innerHTML = `<p class="text-danger">${data.message || 'Gagal memuat form ulasan.'}</p>`;
                            }
                        })
                        .catch(error => {
                            console.error('Error fetching review form:', error);
                            lessonContentEl.innerHTML = '<p class="text-danger">Terjadi kesalahan jaringan.</p>';
                        });
                });
            }

            // --- Event listener untuk tombol "Tandai Selesai" ---
            lessonContentEl.addEventListener('click', function(e) {
                if (e.target && e.target.classList.contains('mark-as-complete-btn')) {
                    const button = e.target;
                    const lessonId = button.dataset.lessonId;
                    button.disabled = true;
                    button.innerHTML = '<i class="fa fa-spinner fa-spin"></i> Memproses...';
                    fetch(`/lessons/${lessonId}/complete`, {
                            method: 'POST',
                            headers: {
                                'Content-Type': 'application/json',
                                'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>'
                            }
                        })
                        .then(response => response.json())
                        .then(data => {
                            if (data.success) {
                                button.style.display = 'none';
                                const sidebarItem = document.getElementById(`sidebar-lesson-${lessonId}`);
                                if (sidebarItem && !sidebarItem.querySelector('.fa-check-circle')) {
                                    sidebarItem.insertAdjacentHTML('beforeend', ' <i class="fa fa-check-circle text-success"></i>');
                                }
                                completedLessons.push(parseInt(lessonId));

                                if (reviewButton && !isPreview && completedLessons.length >= totalLessons && totalLessons > 0) {
                                    reviewButton.disabled = false;
                                    reviewButton.removeAttribute('title');
                                    reviewButton.classList.remove('btn-outline-primary');
                                    reviewButton.classList.add('btn-success');
                                    reviewButton.innerHTML = '<i class="fa fa-star mr-2"></i> Beri Feedback Sekarang!';
                                }

                            } else {
                                alert(data.message || 'Gagal menandai pelajaran.');
                                button.disabled = false;
                                button.innerHTML = '<i class="fa fa-check"></i> Tandai Selesai';
                            }
                        })
                        .catch(error => {
                            console.error('Error marking lesson complete:', error);
                            alert('Terjadi kesalahan jaringan.');
                            button.disabled = false;
                            button.innerHTML = '<i class="fa fa-check"></i> Tandai Selesai';
                        });
                }
            });

            // --- Event listener untuk form submit review ---
            lessonContentEl.addEventListener('submit', function(e) {
                if (e.target && e.target.id === 'course-review-form') {
                    e.preventDefault();
                    const form = e.target;
                    const submitButton = form.querySelector('button[type="submit"]');
                    const errorAlert = document.getElementById('review-error-alert');
                    submitButton.disabled = true;
                    submitButton.innerHTML = '<i class="fa fa-spinner fa-spin"></i> Mengirim...';
                    errorAlert.style.display = 'none';
                    const formData = new FormData(form);
                    fetch(form.action, {
                            method: 'POST',
                            headers: {
                                'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>',
                                'Accept': 'application/json',
                            },
                            body: formData
                        })
                        .then(response => response.json())
                        .then(data => {
                            if (data.success) {
                                lessonContentEl.innerHTML = `
                                <div class="text-center p-5">
                                    <i class="fa fa-check-circle text-success" style="font-size: 4rem;"></i>
                                    <h4 class="mt-3">Terima Kasih!</h4>
                                    <p class="text-muted">Ulasan Anda telah berhasil kami terima.</p>
                                </div>
                            `;
                                if (reviewButton) reviewButton.style.display = 'none';
                            } else {
                                errorAlert.innerText = data.message || 'Terjadi kesalahan. Pastikan semua kolom terisi.';
                                errorAlert.style.display = 'block';
                            }
                        })
                        .catch(error => {
                            console.error('Error submitting review:', error);
                            errorAlert.innerText = 'Terjadi kesalahan jaringan. Silakan coba lagi.';
                            errorAlert.style.display = 'block';
                        })
                        .finally(() => {
                            submitButton.disabled = false;
                            submitButton.innerText = 'Kirim Ulasan';
                        });
                }
            });

            // --- LOGIKA UNTUK TOMBOL SERTIFIKAT ---
            const certificateButton = document.getElementById('load-certificate-preview');
            if (certificateButton) {
                certificateButton.addEventListener('click', function(e) {
                    e.preventDefault();
                    lessonTitleEl.innerText = 'Sertifikat Kelulusan';
                    lessonContentEl.innerHTML = '<div class="text-center p-5"><i class="fa fa-spinner fa-spin fa-3x"></i></div>';
                    const url = "<?php echo e(route('student.certificate.preview', $course->id)); ?>";
                    fetch(url)
                        .then(response => response.json())
                        .then(data => {
                            if (data.success) {
                                lessonContentEl.innerHTML = data.html;
                            } else {
                                lessonContentEl.innerHTML = `<p class="text-danger">${data.message || 'Gagal memuat pratinjau sertifikat.'}</p>`;
                            }
                        })
                        .catch(error => {
                            console.error('Error fetching certificate preview:', error);
                            lessonContentEl.innerHTML = '<p class="text-danger">Terjadi kesalahan jaringan.</p>';
                        });
                });
            }

            // --- LOGIKA UNTUK TOMBOL LEADERBOARD KURSUS ---
            const leaderboardButton = document.getElementById('load-leaderboard');
            if (leaderboardButton) {
                leaderboardButton.addEventListener('click', function(e) {
                    e.preventDefault();
                    lessonTitleEl.innerText = 'Papan Peringkat Kursus';
                    lessonContentEl.innerHTML = '<div class="text-center p-5"><i class="fa fa-spinner fa-spin fa-3x"></i></div>';
                    const url = "<?php echo e(route('student.course.leaderboard', $course->id)); ?>";
                    fetch(url)
                        .then(response => response.json())
                        .then(data => {
                            if (data.success) {
                                lessonContentEl.innerHTML = data.html;
                            } else {
                                lessonContentEl.innerHTML = `<p class="text-danger">${data.message || 'Gagal memuat papan peringkat.'}</p>`;
                            }
                        })
                        .catch(error => {
                            console.error('Error fetching leaderboard:', error);
                            lessonContentEl.innerHTML = '<p class="text-danger">Terjadi kesalahan jaringan.</p>';
                        });
                });
            }

            // --- LOGIKA UNTUK TOMBOL LEADERBOARD MODUL ---
            const moduleLeaderboardButtons = document.querySelectorAll('.load-leaderboard-btn');
            moduleLeaderboardButtons.forEach(button => {
                button.addEventListener('click', function(e) {
                    e.preventDefault();
                    e.stopPropagation(); // Mencegah accordion dari menutup saat link di dalamnya diklik
                    const moduleId = this.dataset.moduleId;
                    lessonTitleEl.innerText = 'Papan Peringkat Modul';
                    lessonContentEl.innerHTML = '<div class="text-center p-5"><i class="fa fa-spinner fa-spin fa-3x"></i></div>';
                    const url = `<?php echo e(url('/modules')); ?>/${moduleId}/leaderboard`;
                    fetch(url)
                        .then(response => response.json())
                        .then(data => {
                            if (data.success) {
                                lessonContentEl.innerHTML = data.html;
                            } else {
                                lessonContentEl.innerHTML = `<p class="text-danger">${data.message || 'Gagal memuat papan peringkat.'}</p>`;
                            }
                        })
                        .catch(error => {
                            console.error('Error fetching module leaderboard:', error);
                            lessonContentEl.innerHTML = '<p class="text-danger">Terjadi kesalahan jaringan.</p>';
                        });
                });
            });

        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app-layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/wahaname/public_html/edukasi/resources/views/student/courses/show.blade.php ENDPATH**/ ?>