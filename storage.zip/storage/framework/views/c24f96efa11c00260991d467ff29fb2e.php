<div class="d-flex align-items-center justify-content-center h-100">
    
    <div class="card mb-4">
        <div class="card-header">
            <h5>Anda Sudah Memberikan Ulasan</h5>
        </div>
        <div class="card-body d-flex flex-column align-items-center justify-content-center">

                <p>Terimakasih telah memberikan ulasan anda, anda dapat mengelola ulasan anda di halaman Feedback.</p>
                <a href="<?php echo e(route('student.reviews.index')); ?>" class="btn btn-primary">Kelola Ulasan</a>

        </div>
    </div>
</div><?php /**PATH /home/wahaname/public_html/edukasi/resources/views/student/courses/partials/_has_feedback.blade.php ENDPATH**/ ?>