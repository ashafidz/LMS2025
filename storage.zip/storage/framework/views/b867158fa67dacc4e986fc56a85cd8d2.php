

<h4 class="font-weight-bold"><?php echo e($lesson->title); ?></h4>
<p>Berikut adalah daftar tautan referensi untuk pelajaran ini. Klik untuk membuka di tab baru.</p>
<hr>

<?php if($lesson->lessonable->links && count($lesson->lessonable->links) > 0): ?>
    <div class="list-group">
        <?php $__currentLoopData = $lesson->lessonable->links; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $link): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <a href="<?php echo e($link['url']); ?>" target="_blank" rel="noopener noreferrer" class="list-group-item list-group-item-action">
                <i class="fa fa-link mr-2"></i> <?php echo e($link['title']); ?>

                <br>
                <small class="text-muted"><?php echo e($link['url']); ?></small>
            </a>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
<?php else: ?>
    <p class="text-muted text-center">Tidak ada tautan yang ditambahkan untuk pelajaran ini.</p>
<?php endif; ?><?php /**PATH /home/wahaname/public_html/edukasi/resources/views/instructor/lessons/previews/_lessonlinkcollection.blade.php ENDPATH**/ ?>