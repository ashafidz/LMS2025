<?php $__env->startSection('content'); ?>
<section class="login-block">
    <div class="container-fluid px-0">
        <div class="row no-gutters shift-up" style="height: 100vh; overflow: hidden;">

            <!-- KIRI: Gambar dalam kotak biru -->
            <div class="col-md-6 d-none d-md-flex align-items-center justify-content-center bg-primary"
                style="min-height: 100vh;">
                <div
                    style="width: 620px; height: 620px; background-color: white; border-radius: 20px; overflow: hidden; box-shadow: 0 10px 30px rgba(0,0,0,0.3);">
                    <img src="<?php echo e(asset('images/side-images/annie-unsplash.jpg')); ?>" alt="Login Illustration"
                        style="width: 100%; height: 100%; object-fit: cover; object-position: center;">
                </div>
            </div>

            <!-- KANAN: Form Login -->
            <div class="col-md-6 align-items-center d-flex" style="min-height: 100vh;">
                <form class="md-float-material form-material w-100 px-4" method="POST" action="<?php echo e(route('login')); ?>">
                    <?php echo csrf_field(); ?>
                    <div class="auth-box card">
                        <div class="card-block">

                            <div class="text-center mb-3">
                                <h3 class="text-center">Masuk</h3>
                                <p class="font-weight-bold">Masuk Sebagai</p>
                                <div class="d-flex justify-content-center mb-2">
                                    <div class="role-btn btn btn-primary mr-2 active"
                                        onclick="selectRole(this, 'student')">
                                        👨‍🎓 Siswa
                                    </div>
                                    <div class="role-btn btn btn-outline-secondary"
                                        onclick="selectRole(this, 'instructor')">
                                        🧑‍🏫 Instruktur
                                    </div>
                                </div>
                                <input type="hidden" id="selected-role" name="login_preference" value="student">
                            </div>

                            <input type="hidden" name="timezone" id="user_timezone">

                            <!-- Validation Errors -->
                             <?php if($errors->any()): ?>
                                <div class="alert alert-danger">
                                    <?php echo e($errors->first()); ?>

                                </div>
                            <?php endif; ?>

                            <div class="form-group form-primary">
                                <input type="email" name="email" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required placeholder="" value="<?php echo e(old('email')); ?>">
                                <span class="form-bar"></span>
                                <label class="float-label">Alamat Email</label>
                                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="form-group form-primary">
                                <input type="password" name="password" class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required placeholder="">
                                <span class="form-bar"></span>
                                <label class="float-label">Password</label>
                                <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="row mt-2 mb-3">
                                <div class="col text-left">
                                    <div class="checkbox-fade fade-in-primary">
                                        <label>
                                            <input type="checkbox" name="remember">
                                            <span class="cr">
                                                <i class="cr-icon icofont icofont-ui-check txt-primary"></i>
                                            </span>
                                            <span class="text-inverse">Ingatkan Saya</span>
                                        </label>
                                    </div>
                                </div>
                                <div class="col text-right">
                                     <?php if(Route::has('password.request')): ?>
                                        <a href="#" data-toggle="modal" data-target="#forgotModal" class="f-w-600">Lupa Password?</a>
                                    <?php endif; ?>
                                </div>
                            </div>

                            <div class="row mt-4">
                                <div class="col-md-12">
                                    <button type="submit"
                                        class="btn btn-primary btn-md btn-block waves-effect text-center m-b-20">
                                        Log In
                                    </button>
                                </div>
                            </div>

                            <div class="text-center mt-3">
                                <p class="text-muted">Belum punya akun?<a href="<?php echo e(route('register')); ?>"
                                        class="text-primary">Daftar</a></p>
                            </div>

                            <hr>

                            <div class="row">
                                <div class="col-md-10">
                                    <p class="text-inverse text-left m-b-0">Terima Kasih</p>
                                    <p class="text-inverse text-left"><a href="<?php echo e(route('home')); ?>"><b>Kembali ke website</b></a>
                                    </p>
                                </div>
                            </div>

                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</section>



<div class="modal fade" id="forgotModal" tabindex="-1" role="dialog" aria-labelledby="forgotModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered" role="document">
    <div class="modal-content rounded">
      <div class="modal-header">
        <h5 class="modal-title" id="forgotModalLabel">🔐 Lupa Kata Sandi Anda?</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span>&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <div class="mb-4 text-sm text-muted">
            <?php echo e(__('Tidak masalah. Cukup beri tahu kami alamat email Anda dan kami akan mengirimkan tautan untuk mengatur ulang kata sandi Anda.')); ?>

        </div>

        <?php if(session('status')): ?>
            <div class="alert alert-success mb-4" role="alert">
                <?php echo e(session('status')); ?>

            </div>
        <?php endif; ?>

        <?php if($errors->any()): ?>
            <div class="alert alert-danger mb-4">
                <ul class="mb-0 ps-3">
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>

        <form method="POST" action="<?php echo e(route('password.email')); ?>">
            <?php echo csrf_field(); ?>

            <div class="mb-3">
                <label for="email" class="form-label"><?php echo e(__('Email')); ?></label>
                <input id="email" class="form-control" type="email" name="email" value="<?php echo e(old('email')); ?>" required autofocus />
            </div>

            <div class="d-grid mt-4">
                <button type="submit" class="btn btn-dark">
                    <?php echo e(__('Kirim Tautan Reset Kata Sandi')); ?>

                </button>
            </div>
        </form>
        
      </div>
    </div>
  </div>
</div>

<?php $__env->stopSection(); ?>


<?php $__env->startPush('scripts'); ?>
    <style>
        html,
        body {
            height: 100%;
            margin: 0;
            overflow: hidden;
        }

        .shift-up {
            transform: translateY(-30px);
        }
    </style>

    <script>
        document.getElementById('user_timezone').value = Intl.DateTimeFormat().resolvedOptions().timeZone;
    </script>
    <script>
        function selectRole(element, role) {
            // Remove 'active' from all buttons and add 'btn-outline-secondary'
            document.querySelectorAll('.role-btn').forEach(btn => {
                btn.classList.remove('btn-primary', 'active');
                btn.classList.add('btn-outline-secondary');
            });

            // Add 'active' to the clicked button and remove 'btn-outline-secondary'
            element.classList.add('btn-primary', 'active');
            element.classList.remove('btn-outline-secondary');

            // Set the value of the hidden input
            document.getElementById('selected-role').value = role;
        }
    </script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app-layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/wahaname/public_html/edukasi/resources/views/auth/login.blade.php ENDPATH**/ ?>