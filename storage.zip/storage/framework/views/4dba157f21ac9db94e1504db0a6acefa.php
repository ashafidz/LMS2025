<?php $__env->startSection('content'); ?>
    <div class="pcoded-content">
        <!-- Page-header start -->
        <div class="page-header">
            <div class="page-block">
                <div class="row align-items-center">
                    <div class="col-md-8">
                        <div class="page-header-title">
                            <h5 class="m-b-10">Ambil dari Bank Soal</h5>
                            <p class="m-b-0">Pilih soal untuk ditambahkan ke kuis: <strong><?php echo e($quiz->title); ?></strong></p>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <ul class="breadcrumb-title">
                            <li class="breadcrumb-item"><a href="<?php echo e(route('instructor.dashboard')); ?>"><i class="fa fa-home"></i></a></li>
                            <li class="breadcrumb-item"><a href="<?php echo e(route('instructor.modules.lessons.index', $quiz->lesson->module)); ?>">Daftar Pelajaran</a></li>
                            <li class="breadcrumb-item"><a href="<?php echo e(route('instructor.quizzes.manage_questions', $quiz)); ?>">Kelola Soal</a></li>
                            <li class="breadcrumb-item"><a href="#!">Pilih dari Bank Soal</a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
        <!-- Page-header end -->

        <div class="pcoded-inner-content">
            <div class="main-body">
                <div class="page-wrapper">
                    <div class="page-body">
                        <div class="row">
                            <!-- Kolom Daftar Topik -->
                            <div class="col-md-4">
                                <div class="card">
                                    <div class="card-header">
                                        <h5>Topik Soal Anda</h5>
                                    </div>
                                    <div class="card-block">
                                        <div class="list-group">
                                            <?php $__empty_1 = true; $__currentLoopData = $topics; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $topic): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                                
                                                <a href="<?php echo e(route('instructor.quizzes.browse_bank', ['quiz' => $quiz, 'topic_id' => $topic->id])); ?>"
                                                   class="list-group-item list-group-item-action d-flex justify-content-between align-items-center <?php echo e(request('topic_id') == $topic->id ? 'active' : ''); ?>">
                                                    <?php echo e($topic->name); ?>

                                                    
                                                    <span class="badge badge-primary badge-pill"><?php echo e($topic->questions_count); ?></span>
                                                </a>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                                <p class="text-muted">Anda belum memiliki topik soal di Bank Soal.</p>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <!-- Kolom Daftar Soal -->
                            <div class="col-md-8">
                                <div class="card">
                                    <div class="card-header">
                                        <h5>Pilih Soal</h5>
                                        <span>Centang soal yang ingin Anda tambahkan ke kuis.</span>
                                    </div>
                                    <div class="card-block">
                                        <?php if($questionsInTopic): ?>
                                            <form action="<?php echo e(route('instructor.quizzes.attach_questions', $quiz)); ?>" method="POST">
                                                <?php echo csrf_field(); ?>
                                                <div class="table-responsive">
                                                    <table class="table">
                                                        <thead>
                                                            <tr>
                                                                <th style="width: 5%;">Pilih</th>
                                                                <th>Tipe</th>
                                                                <th>Teks Soal</th>
                                                            </tr>
                                                        </thead>
                                                        <tbody>
                                                            <?php $__empty_1 = true; $__currentLoopData = $questionsInTopic; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                                                <tr>
                                                                    <td>
                                                                        <div class="checkbox-fade fade-in-primary">
                                                                            <label>
                                                                                <input type="checkbox" name="question_ids[]" value="<?php echo e($question->id); ?>">
                                                                                <span class="cr"><i class="cr-icon icofont icofont-ui-check txt-primary"></i></span>
                                                                            </label>
                                                                        </div>
                                                                    </td>
                                                                    <td><?php echo e(ucfirst(str_replace('_', ' ', $question->question_type))); ?></td>
                                                                    <td><?php echo e(Str::limit(strip_tags($question->question_text), 100)); ?></td>
                                                                </tr>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                                                <tr>
                                                                    <td colspan="3" class="text-center">Tidak ada soal yang tersedia untuk ditambahkan di topik ini.</td>
                                                                </tr>
                                                            <?php endif; ?>
                                                        </tbody>
                                                    </table>
                                                </div>
                                                <hr>
                                                <div class="text-right">
                                                    <button type="submit" class="btn btn-primary">
                                                        <i class="fa fa-plus-circle"></i> Tambah Soal Terpilih ke Kuis
                                                    </button>
                                                </div>
                                            </form>
                                        <?php else: ?>
                                            <div class="text-center">
                                                <p class="text-muted"><i class="fa fa-arrow-left"></i> Silakan pilih topik di sebelah kiri untuk menampilkan daftar soal.</p>
                                            </div>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app-layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/wahaname/public_html/edukasi/resources/views/instructor/quizzes/browse-bank.blade.php ENDPATH**/ ?>