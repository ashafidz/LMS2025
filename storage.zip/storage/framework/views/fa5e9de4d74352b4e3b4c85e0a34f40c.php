<?php $__env->startSection('content'); ?>
    <div class="pcoded-content">
        <div class="pcoded-inner-content px-3" style="padding-top: 32px;">
            <div class="row g-4 px-2">

                <form action="<?php echo e(route('user.profile.update')); ?>" method="POST" enctype="multipart/form-data"
                    class="row col-12">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>

                    <!-- Avatar & Aksi -->
                    <div class="col-xl-4 col-md-12 mb-4">
                        <div class="card text-center">
                            <div class="card-body py-4">
                                <h6 class="mb-3">Foto Profil</h6>
                    
                                <!-- Gambar Avatar yang Dipilih -->
                                <img id="selectedAvatar" 
                                    src="<?php echo e(asset(Auth::user()->profile_picture_url ?? 'public/images/avatar-4.jpg')); ?>" 
                                    class="img-100 img-radius mb-3" 
                                    alt="User-Profile-Image"
                                    style="width: 100px; height: 100px; object-fit: cover;">
                    
                                <!-- Input Hidden untuk kirim URL avatar ke server -->
                                <input type="hidden" name="profile_picture_url" id="profilePictureInput" 
                                    value="<?php echo e(old('profile_picture_url', Auth::user()->profile_picture_url ?? 'public/images/avatar-4.jpg')); ?>">
                    
                                <!-- Tombol Pilih Avatar -->
                                <button type="button" class="btn btn-outline-primary btn-sm btn-block" data-bs-toggle="modal" data-bs-target="#avatarModal">
                                    Pilih Avatar
                                </button>
                    
                                <?php $__errorArgs = ['profile_picture_url'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="text-danger mt-2"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>     
                            </div>
                    
                            <!-- Modal Pilih Avatar -->
                            <div class="modal fade" id="avatarModal" tabindex="-1" aria-labelledby="avatarModalLabel" aria-hidden="true">
                                <div class="modal-dialog modal-dialog-centered modal-lg">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <h5 class="modal-title" id="avatarModalLabel">Pilih Avatar</h5>
                                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Tutup"></button>
                                        </div>
                                        <div class="modal-body">
                                            <div class="row">
                                                <?php for($i = 1; $i <= 6; $i++): ?>
                                                <div class="col-4 col-md-2 mb-3 text-center">
                                                    <img src="<?php echo e(asset("public/images/avatar-$i.jpg")); ?>"
                                                        class="img-fluid rounded-circle border avatar-option"
                                                        style="cursor:pointer; width: 80px; height: 80px; object-fit: cover;"
                                                        onclick="selectAvatar('<?php echo e(asset("public/images/avatar-$i.jpg")); ?>')">
                                                </div>
                                                <?php endfor; ?>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>    
                    </div>


                    <!-- Form Edit Profil -->
                    <div class="col-xl-8 col-md-12 mb-4">
                        
                        <div class="card">
                            <div class="card-header">
                                <h5>Biografi</h5>
                            </div>
                            <div class="card-body">
                                <div class="form-group">
                                    <textarea class="form-control" id="bio" name="bio" rows="5"><?php echo e(old('bio', $profile->bio ?? '')); ?></textarea>
                                    <?php $__errorArgs = ['bio'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="text-danger mt-2"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                        </div>
                        
                        <div class="card ">
                            <div class="card-header">
                                <h5>Edit Profil</h5>
                            </div>
                            <div class="card-block">
                                <!-- Biodata -->
                                <div class="form-group">
                                    <label for="name">Nama Lengkap</label>
                                    <input type="text" class="form-control" id="name" name="name"
                                        value="<?php echo e(old('name', $user->name)); ?>">
                                    <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="text-danger mt-2"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>

                                <div class="form-group">
                                    <label for="phone_number">Nomor Telepon</label>
                                    <input type="text" class="form-control" id="phone_number" name="phone_number"
                                        value="<?php echo e(old('phone_number', $user->phone_number)); ?>">
                                    <?php $__errorArgs = ['phone_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="text-danger mt-2"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>

                                <div class="form-group">
                                    <label for="birth_date">Tanggal Lahir</label>
                                    <input type="date" class="form-control" id="birth_date" name="birth_date"
                                        value="<?php echo e(old('birth_date', $user->birth_date)); ?>">
                                    <?php $__errorArgs = ['birth_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="text-danger mt-2"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>

                                <div class="form-group">
                                    <label for="gender">Jenis Kelamin</label>
                                    <select class="form-control" id="gender" name="gender">
                                        <option value="">Pilih</option>
                                        <option value="male"
                                            <?php echo e(old('gender', $user->gender) == 'male' ? 'selected' : ''); ?>>
                                            Laki-laki</option>
                                        <option value="female"
                                            <?php echo e(old('gender', $user->gender) == 'female' ? 'selected' : ''); ?>>
                                            Perempuan</option>
                                    </select>
                                    <?php $__errorArgs = ['gender'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="text-danger mt-2"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>

                                <div class="form-group">
                                    <label for="address">Alamat Lengkap</label>
                                    <textarea class="form-control" id="address" name="address" rows="2"><?php echo e(old('address', $user->address)); ?></textarea>
                                    <?php $__errorArgs = ['address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="text-danger mt-2"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>

                                <div class="form-group">
                                    <label for="headline">Headline</label>
                                    <input type="text" class="form-control" id="headline" name="headline"
                                        value="<?php echo e(old('headline', $profile->headline ?? '')); ?>">
                                    <?php $__errorArgs = ['headline'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="text-danger mt-2"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>

                                <?php if(session('active_role') == 'student'): ?>
                                <div class="form-group row">
                                    <label class="col-sm-2 col-form-label">Pasang Badge</label>
                                    <div class="col-sm-10">
                                        <?php if($unlockedBadges->isNotEmpty()): ?>
                                            <select name="equipped_badge_id" class="form-control">
                                                <option value="">-- Tidak Memasang Badge --</option>
                                                <?php $__currentLoopData = $unlockedBadges; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $badge): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($badge->id); ?>" <?php echo e($user->equipped_badge_id == $badge->id ? 'selected' : ''); ?>>
                                                        <?php echo e($badge->title); ?>

                                                    </option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                            <small class="form-text text-muted">Pilih badge yang akan ditampilkan di samping nama Anda.</small>
                                        <?php else: ?>
                                            <p class="form-control-static text-muted">Anda belum memiliki badge.</p>
                                        <?php endif; ?>
                                    </div>
                                </div>
                                <?php endif; ?>

                                <div class="form-group">
                                    <label for="website_url">Website</label>
                                    <input type="url" class="form-control" id="website_url" name="website_url"
                                        value="<?php echo e(old('website_url', $profile->website_url ?? '')); ?>">
                                    <?php $__errorArgs = ['website_url'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="text-danger mt-2"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>

                                <!-- Pendidikan -->
                                <hr>
                                <h6 class="text-primary font-weight-bold mt-4">Data Tambahan</h6>

                                <div class="form-group">
                                    <label for="highest_level_of_education">Pendidikan Terakhir</label>
                                    <input type="text" class="form-control" id="highest_level_of_education"
                                        name="highest_level_of_education"
                                        value="<?php echo e(old('highest_level_of_education', $profile->highest_level_of_education ?? '')); ?>">
                                    <?php $__errorArgs = ['highest_level_of_education'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="text-danger mt-2"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>

                                <div class="form-group">
                                    <label for="profession">Pekerjaan / Profesi </label>
                                    <input type="text" class="form-control" id="profession" name="profession"
                                        value="<?php echo e(old('profession', $profile->profession ?? '')); ?>">
                                    <?php $__errorArgs = ['profession'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="text-danger mt-2"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>

                                <div class="form-group">
                                    <label for="company_or_institution_name">Nama Perusahaan / Institusi Saat Ini</label>
                                    <input type="text" class="form-control" id="company_or_institution_name"
                                        name="company_or_institution_name"
                                        value="<?php echo e(old('company_or_institution_name', $profile->company_or_institution_name ?? '')); ?>">
                                    <?php $__errorArgs = ['company_or_institution_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="text-danger mt-2"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>

                                <div class="form-group">
                                    <label for="company_address">Alamat Perusahaan</label>
                                    <textarea class="form-control" id="company_address" name="company_address" rows="2"><?php echo e(old('company_address', $profile->company_address ?? '')); ?></textarea>
                                    <?php $__errorArgs = ['company_address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="text-danger mt-2"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>

                                <div class="form-group">
                                    <label for="company_tax_id">No. NPWP Perusahaan</label>
                                    <input type="text" class="form-control" id="company_tax_id" name="company_tax_id"
                                        value="<?php echo e(old('company_tax_id', $profile->company_tax_id ?? '')); ?>">
                                    <?php $__errorArgs = ['company_tax_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="text-danger mt-2"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                                                
                                <div class="form-group">
                                    <label for="unique_id_number">Nomor Induk</label>
                                        <input type="text" name="unique_id_number" class="form-control" value="<?php echo e(old('unique_id_number', $profile->unique_id_number ?? '')); ?>" placeholder="NIM/NIP/NIDN...">
                                        <small class="form-text text-muted">Isi dengan Nomor Induk Mahasiswa/Pegawai/Dosen Anda jika ada.</small>
                                </div>

                                <!-- Tombol -->
                                <div class="mt-4 text-right">
                                    <a href="<?php echo e(route('user.profile.index')); ?>"
                                        class="btn btn-secondary btn-sm">Batal</a>
                                    <button type="submit" class="btn btn-primary btn-sm">Simpan Perubahan</button>
                                </div>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
    function selectAvatar(url) {
        // Update preview avatar
        document.getElementById('selectedAvatar').src = url;
        // Set ke input hidden
        document.getElementById('profilePictureInput').value = url;
        
        // Tutup modal
        const modalEl = document.getElementById('avatarModal');
        let modal = bootstrap.Modal.getInstance(modalEl);
        if (!modal) {
            modal = new bootstrap.Modal(modalEl);
        }
        modal.hide();
    }
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app-layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/wahaname/public_html/edukasi/resources/views/profile/edit-student_instructor.blade.php ENDPATH**/ ?>