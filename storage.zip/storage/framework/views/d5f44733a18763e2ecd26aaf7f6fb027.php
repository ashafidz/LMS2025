

<div class="card mt-4">
    <div class="card-header">
        <h5 class="mb-0">Riwayat Pengerjaan Anda</h5>
    </div>
    <div class="card-body p-0">
        <div class="table-responsive">
            <table class="table table-hover mb-0">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Tanggal & Waktu</th>
                        <th>Skor</th>
                        <th>Status</th>
                        <th>Durasi</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $allAttempts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $attempt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            
                            <td><?php echo e($loop->iteration); ?></td>

                            
                            <td><?php echo e($attempt->start_time->isoFormat('D MMM YYYY, HH:mm')); ?></td>

                            
                            <td><?php echo e(rtrim(rtrim($attempt->score, '0'), '.')); ?></td>

                            
                            <td>
                                <?php if($attempt->status == 'passed'): ?>
                                    <span class="badge badge-success">Lulus</span>
                                <?php elseif($attempt->status == 'failed'): ?>
                                    <span class="badge badge-danger">Gagal</span>
                                <?php else: ?>
                                    <span class="badge badge-warning">Sedang Dikerjakan</span>
                                <?php endif; ?>
                            </td>

                            
                            <td>
                                <?php if($attempt->end_time): ?>
                                    
                                    <?php echo e($attempt->start_time->diffForHumans($attempt->end_time, true)); ?>

                                <?php else: ?>
                                    -
                                <?php endif; ?>
                            </td>

                            
                            <td>
                                <?php if($attempt->status != 'in_progress'): ?>
                                    <a href="<?php echo e(route('student.quiz.result', $attempt->id)); ?>" class="btn btn-sm btn-outline-info">
                                        <i class="fa fa-eye"></i> Lihat
                                    </a>
                                <?php else: ?>
                                    <a href="<?php echo e(route('student.quiz.take', $attempt->id)); ?>" class="btn btn-sm btn-outline-warning">
                                        <i class="fa fa-pencil"></i> Lanjutkan
                                    </a>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="6" class="text-center text-muted py-4">
                                Anda belum pernah mengerjakan kuis ini.
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php /**PATH /home/wahaname/public_html/edukasi/resources/views/student/quizzes/partials/_quiz_attempt_history.blade.php ENDPATH**/ ?>