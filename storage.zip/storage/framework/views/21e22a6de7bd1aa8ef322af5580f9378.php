\

<?php $__env->startSection('title', $course->title); ?>

<?php $__env->startSection('content'); ?>
<section style="background: linear-gradient(to right, #ffffff, #e0edff);">
  <div class="container">
    <div class="row align-items-start pt-5 pb-4">
      <div class="col-md-8">
        <a href="<?php echo e(route('courses')); ?>" class="text-muted text-decoration-none d-inline-block mb-2">
          <i class="bi bi-chevron-left"></i> Kembali ke Katalog
        </a>
        <h3 class="fw-bold mb-1 fs-1"><?php echo e($course->title); ?></h3>
        
        
        <?php if($reviewCount > 0): ?>
        <div class="d-flex align-items-center mt-2">
            <span class="fw-bold text-warning me-1 fs-5"><?php echo e(number_format($averageRating, 1)); ?></span>
            <div class="star-rating-display me-2" style="font-size: 0.89rem;>
                <?php for($i = 1; $i <= 5; $i++): ?>
                    <i class="bi <?php echo e($i <= round($averageRating) ? 'bi-star-fill text-warning' : 'bi-star text-muted'); ?>"></i>
                <?php endfor; ?>
            </div>
            <span class="fw-semibold" style="font-size: 1rem; color: #cc7000;">(<?php echo e($reviewCount); ?> ulasan)</span>
        </div>
        <?php endif; ?>

      </div>

      <div class="col-lg-4 mt-4 mt-lg-0">
        <div class="bg-white border rounded p-4 shadow-sm">

          
          
          <?php if($course->payment_type === 'money'): ?>
              <h5 class="mb-1">Harga:</h5>
              <h3 class="fw-bold text-dark">
                  <?php if($course->price > 0): ?>
                      Rp<?php echo e(number_format($course->price, 0, ',', '.')); ?>

                  <?php else: ?>
                      Gratis
                  <?php endif; ?>
              </h3>
          <?php elseif($course->payment_type === 'diamonds'): ?>
              <h5 class="mb-1">Harga Diamond:</h5>
              <h3 class="fw-bold text-primary d-flex align-items-center">
                  <i class="fa fa-diamond me-2"></i> <?php echo e(number_format($course->diamond_price, 0, ',', '.')); ?>

              </h3>
          <?php endif; ?>
          
          
          <?php if(auth()->guard()->check()): ?>
              <?php if(session('active_role') === 'student'): ?>
                <?php if($is_enrolled): ?>
                    <a href="<?php echo e(route('student.courses.show', $course->slug)); ?>" class="btn btn-success w-100 mt-3">Lanjutkan Belajar</a>
                <?php else: ?>
                    <?php if($course->payment_type === 'money'): ?>
                        <form action="<?php echo e(route('student.cart.add', $course->id)); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <button type="submit" class="btn btn-primary rounded-pill w-100 mt-3">
    Tambahkan ke keranjang
</button>
                        </form>
                    <?php elseif($course->payment_type === 'diamonds'): ?>
                        <form action="<?php echo e(route('student.courses.purchase_with_diamonds', $course->id)); ?>" method="POST" onsubmit="return confirm('Beli kursus ini dengan <?php echo e($course->diamond_price); ?> diamond?');">
                            <?php echo csrf_field(); ?>
                            <button type="submit" class="btn btn-info w-100 mt-3" <?php echo e(Auth::user()->diamond_balance < $course->diamond_price ? 'disabled' : ''); ?>>
                                Beli dengan Diamond
                            </button>
                            <?php if(Auth::user()->diamond_balance < $course->diamond_price): ?>
                                <small class="form-text text-danger text-center d-block mt-1">Diamond Anda tidak cukup.</small>
                            <?php endif; ?>
                        </form>
                    <?php endif; ?>
                <?php endif; ?>
              <?php else: ?>
                <button class="btn btn-primary w-100 mt-3 disabled">
                  Hanya Siswa yang Bisa Mendaftar
                </button>
              <?php endif; ?>
          <?php else: ?>
            <a href="<?php echo e(route('login')); ?>" class="btn btn-primary w-100 mt-3">Login untuk Mendaftar</a>
          <?php endif; ?>


          

        </div>
      </div>
    </div>
  </div>
</section>

<section class="py-5 bg-white">
  <div class="container">
    <div class="row gy-5">
      <div class="col-lg-8">
        <div class="mb-4">
          <h5 class="fw-bold mb-3">Tentang Kursus Ini</h5>
          <div class="text-muted">
            <?php echo $course->description; ?>

          </div>
        </div>

        <div class="mb-4">
          <h5 class="fw-bold">Materi yang Akan Kamu Pelajari</h5>
          <div class="accordion" id="accordionMateri">
            <?php $__empty_1 = true; $__currentLoopData = $course->modules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $module): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
              <div class="accordion-item border-0 mb-2 shadow-sm">
                <h2 class="accordion-header" id="heading-<?php echo e($module->id); ?>">
                  <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#materi-<?php echo e($module->id); ?>">
                    <i class="bi bi-card-list me-2 text-dark"></i>
                    <?php echo e($module->title); ?>

                  </button>
                </h2>
                <div id="materi-<?php echo e($module->id); ?>" class="accordion-collapse collapse" data-bs-parent="#accordionMateri">
                  <div class="accordion-body">
                    <ul class="list-unstyled">

                        <?php if($module->lessons->isEmpty()): ?>
                          <p class="text-muted">Belum ada materi untuk modul ini.</p>
                          
                        <?php endif; ?>
                        <?php $__currentLoopData = $module->lessons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lesson): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php
                              if ($lesson->lessonable_type === 'App\Models\LessonArticle') {
                                $icon = 'bi-file-text';
                              } elseif ($lesson->lessonable_type === 'App\Models\LessonVideo') {
                                $icon = 'bi-collection-play';
                              } elseif ($lesson->lessonable_type === 'App\Models\LessonDocument') {
                                $icon = 'bi-file-earmark-pdf';
                              } elseif ($lesson->lessonable_type === 'App\Models\LessonLinkCollection') {
                                $icon = 'bi-folder2-open';
                              } elseif ($lesson->lessonable_type === 'App\Models\LessonAssignment') {
                                $icon = 'bi-pencil-square';
                              } 
                              elseif ($lesson->lessonable_type === 'App\Models\Quiz') {
                                $icon = 'bi-clipboard2';
                              }
                              elseif ($lesson->lessonable_type === 'App\Models\LessonPoint') {
                                $icon = 'bi-chat-left-quote';
                              }
                              else {
                                $icon = 'fa-file-text-o';
                              }
                            ?>
                            <li class="d-flex align-items-center text-muted py-2 <?php echo e(!$loop->last ? 'border-bottom' : ''); ?>">
    <i class="fa <?php echo e($icon); ?> me-2"></i>
    <span><?php echo e($lesson->title); ?></span>
</li>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </ul>
                  </div>
                </div>
              </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <p class="text-muted">Materi untuk kursus ini akan segera ditambahkan.</p>
            <?php endif; ?>
          </div>
        </div>

        
        <hr class="my-5">
        <div>
            <h5 class="fw-bold mb-4">Ulasan dari Siswa</h5>
            <?php $__empty_1 = true; $__currentLoopData = $reviews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $review): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <div class="d-flex mb-4">
                    <img src="<?php echo e($review->user->profile_picture_url ? asset('storage/' . ltrim($review->user->profile_picture_url, '/')) :  'https://placehold.co/80x80/EBF4FF/767676?text=' . strtoupper(substr($review->user->name, 0, 1))); ?>" 
                         alt="<?php echo e($review->user->name); ?>" 
                         class="rounded-circle me-3" 
                         style="width: 50px; height: 50px; object-fit: cover;">
                    <div class="flex-grow-1">
                        <div class="d-flex align-items-center">
                          <h6 class="fw-bold mb-0"><?php echo e($review->user->name); ?></h6>
                          <?php if($review->user->equippedBadge): ?>
                            <span class="bg-primary rounded-pill px-2 py-1 text-white fw-bold small mx-1">
                              <?php echo e($review->user->equippedBadge->title); ?>

                            </span>
                          <?php endif; ?>
                        </div>
                        <div class="d-flex align-items-center mb-2">
                            <div class="star-rating-display me-2">
                                <?php for($i = 1; $i <= 5; $i++): ?>
                                    <i class="bi <?php echo e($i <= $review->rating ? 'bi-star-fill text-warning' : 'bi-star text-muted'); ?>"></i>
                                <?php endfor; ?>
                            </div>
                            <small class="text-muted"><?php echo e($review->created_at->diffForHumans()); ?></small>
                        </div>
                        <p class="text-muted"><?php echo e($review->comment); ?></p>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <div class="text-center text-muted p-4 bg-light rounded">
                    <p class="mb-0">Jadilah yang pertama memberikan ulasan untuk kursus ini!</p>
                </div>
            <?php endif; ?>


            
            <div class="d-flex justify-content-center mt-4">
                <?php echo e($reviews->links()); ?>

            </div>
        </div>

      </div>
      <div class="col-lg-4">
        <div class="mb-4">
          <h6 class="fw-bold mb-3">Instruktur</h6>
          <div class="d-flex align-items-center">
            <img src="<?php echo e($course->instructor->profile_picture_url ? asset('storage/' . ltrim($course->instructor->profile_picture_url, '/')) : 'https://placehold.co/80x80/EBF4FF/767676?text=' . strtoupper(substr($course->instructor->name, 0, 1))); ?>"
                 class="rounded-circle me-3" style="width: 45px; height: 45px; object-fit: cover;">
            <div>
              <strong><?php echo e($course->instructor->name); ?></strong>
            </div>
          </div>
        </div>

        <hr>
        <div>
          <h6 class="fw-bold mb-3">Kategori</h6>
          <span class="badge bg-primary-subtle text-primary px-3 py-2 rounded-pill mb-2 d-inline-block">
            <?php echo e($course->category->name); ?>

          </span>
        </div>
      </div>
      
      

<?php if($relatedCourses->isNotEmpty()): ?>
<div class="mb-5 mt-4" data-aos="fade-up">
    
    <h4 class="fw-bold mb-3 text-primary">Kursus Lain di Kategori Ini</h4>
    
    <div class="row row-cols-1 row-cols-sm-2 row-cols-md-3 row-cols-lg-4 g-3">
        
        
        <?php $__currentLoopData = $relatedCourses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $relatedCourse): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col">
            
            <a href="<?php echo e(route('courses.show', $relatedCourse->slug)); ?>" class="text-decoration-none">
                <div class="card h-100 border-0 shadow-sm rounded-4">
                    
                    
                    <img src="<?php echo e($relatedCourse->thumbnail_url ? asset('storage/' . $relatedCourse->thumbnail_url) : 'https://placehold.co/400x250/edf8fd/0d6efd?text=Kursus'); ?>"
                         class="card-img-top rounded-top-4"
                         style="height: 140px; object-fit: cover;"
                         alt="<?php echo e($relatedCourse->title); ?>">
                         
                    <div class="card-body">
                        
                        <span class="badge bg-warning text-dark mb-2">
                            <?php echo e($relatedCourse->category->name ?? 'Online Course'); ?>

                        </span>

                        
                        <h6 class="fw-bold"><?php echo e($relatedCourse->title); ?></h6>

                        
                        <p class="mb-1 text-muted small">
                            <?php echo e($relatedCourse->instructor->name ?? 'Tanpa Instruktur'); ?>

                        </p>
                        
                        
                        <p class="fw-bold text-primary mb-0">
                            <?php if($relatedCourse->price > 0): ?>
                                Rp<?php echo e(number_format($relatedCourse->price, 0, ',', '.')); ?>

                            <?php else: ?>
                                Gratis
                            <?php endif; ?>
                        </p>
                    </div>
                </div>
            </a>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </div>
</div>
<?php endif; ?>


    </div>
  </div>

    
    


</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.home-layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/wahaname/public_html/edukasi/resources/views/details-course.blade.php ENDPATH**/ ?>