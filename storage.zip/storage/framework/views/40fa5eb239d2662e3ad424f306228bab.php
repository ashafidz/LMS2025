<?php $__env->startSection('title', 'Konfirmasi Pesanan'); ?>

<?php $__env->startSection('content'); ?>
<section class="py-5" style="margin-top: 60px; background-color: #f8f9fa;">
    <div class="container">
        <div class="row d-flex justify-content-center">
            <div class="col-lg-8">
                <div class="card border-0 shadow-sm rounded-4">
                    <div class="card-header bg-white text-center border-0 pt-4 pb-0">
                        <i class="bi bi-receipt-cutoff fs-1 text-primary"></i>
                        <h3 class="fw-bold mt-2">Ringkasan Pesanan Anda</h3>
                        <p class="text-muted">Harap periksa kembali detail pesanan Anda sebelum melanjutkan ke pembayaran.</p>
                    </div>
                    <div class="card-body p-4">
                        
                        <div class="d-flex justify-content-between mb-2">
                            <span class="text-muted">Kode Pesanan:</span>
                            <span class="fw-bold"><?php echo e($order->order_code); ?></span>
                        </div>
                        <div class="d-flex justify-content-between mb-3">
                            <span class="text-muted">Tanggal:</span>
                            <span><?php echo e($order->created_at->format('d F Y')); ?></span>
                        </div>

                        <hr>
                        
                        
                        <h6 class="fw-bold mb-3">Item yang Dipesan:</h6>
                        <ul class="list-group list-group-flush mb-3">
                            <?php $__currentLoopData = $order->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li class="list-group-item d-flex justify-content-between align-items-center px-0">
                                <span><?php echo e($item->course->title); ?></span>
                                <span>Rp<?php echo e(number_format($item->price_at_purchase, 0, ',', '.')); ?></span>
                            </li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>

                        <hr>

                        
                        <div class="d-flex justify-content-between">
                            <span class="text-muted">Subtotal</span>
                            <span>Rp<?php echo e(number_format($order->total_amount, 0, ',', '.')); ?></span>
                        </div>
                        <?php if($order->discount_amount > 0): ?>
                        <div class="d-flex justify-content-between text-success">
                            <span class="text-muted">Diskon (<?php echo e($order->coupon->code ?? ''); ?>)</span>
                            <span>- Rp<?php echo e(number_format($order->discount_amount, 0, ',', '.')); ?></span>
                        </div>
                        <?php endif; ?>
                        <hr>
                        <div class="d-flex justify-content-between fw-bold fs-5">
                            <span>Total Pembayaran</span>
                            <span class="text-primary">Rp<?php echo e(number_format($order->final_amount, 0, ',', '.')); ?></span>
                        </div>
                        
                        <div class="text-center mt-4">
                            <p class="text-muted">Anda akan melakukan transaksi sebesar <strong>Rp<?php echo e(number_format($order->final_amount, 0, ',', '.')); ?></strong></p>
                            
                            
                            <button id="pay-button" class="btn btn-success btn-lg w-100">
                                <i class="bi bi-shield-check"></i> Bayar Sekarang
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    
    <script type="text/javascript"
            src="https://app.sandbox.midtrans.com/snap/snap.js"
            data-client-key="<?php echo e($midtransClientKey); ?>"></script>
            
    
    <script type="text/javascript">
      var payButton = document.getElementById('pay-button');
      payButton.addEventListener('click', function () {
        snap.pay('<?php echo e($snapToken); ?>', {
          onSuccess: function(result){
            console.log(result);
            window.location.href = "<?php echo e(route('payment.success', $order->id)); ?>";
          },
          onPending: function(result){
            console.log(result);
            window.location.href = "<?php echo e(route('payment.pending', $order->id)); ?>";
          },
          onError: function(result){
            console.log(result);
            window.location.href = "<?php echo e(route('payment.failed', $order->id)); ?>";
          },
          onClose: function(){
            /* Pengguna menutup popup tanpa menyelesaikan pembayaran */
            window.location.href = "<?php echo e(route('payment.cancelled', $order->id)); ?>";
          }
        });
      });
    </script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.home-layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/wahaname/public_html/edukasi/resources/views/student/checkout/show.blade.php ENDPATH**/ ?>