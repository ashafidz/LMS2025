<?php $__env->startSection('content'); ?>
<div class="pcoded-content">
    <div class="page-header">
        <div class="page-block">
            <div class="row align-items-center">
                <div class="col-md-8">
                    <div class="page-header-title">
                        <h5 class="m-b-10">Beri Poin Manual</h5>
                        <p class="m-b-0">Pelajaran: <strong><?php echo e($lesson->title); ?></strong></p>
                    </div>
                </div>
                <div class="col-md-4">
                    <ul class="breadcrumb-title">
                        <li class="breadcrumb-item"><a href="<?php echo e(route('instructor.dashboard')); ?>"><i class="fa fa-home"></i></a></li>
                        <li class="breadcrumb-item"><a href="<?php echo e(route('instructor.modules.lessons.index', $lesson->module)); ?>">Daftar Pelajaran</a></li>
                        <li class="breadcrumb-item"><a href="#!">Beri Poin</a></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    <div class="pcoded-inner-content">
        <div class="main-body">
            <div class="page-wrapper">
                <div class="page-body">
                    <div class="row">
                        <div class="col-sm-12">
                            <div class="card">
                                <div class="card-header">
                                    <h5>Daftar Siswa di Kursus: <?php echo e($course->title); ?></h5>
                                    <span>Berikan poin kepada siswa berdasarkan partisipasi atau pencapaian mereka.</span>
                                </div>
                                <div class="card-block table-border-style">
                                    <?php if(session('success')): ?>
                                        <div class="alert alert-success"><?php echo e(session('success')); ?></div>
                                    <?php endif; ?>
                                    <?php if($errors->any()): ?>
                                        <div class="alert alert-danger">
                                            <ul>
                                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <li><?php echo e($error); ?></li>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </ul>
                                        </div>
                                    <?php endif; ?>
                                    <div class="table-responsive">
                                        <table class="table table-hover">
                                            <thead>
                                                <tr>
                                                    <th>Nama Siswa</th>
                                                    <th>Total Poin di Kursus Ini</th>
                                                    <th style="width: 150px;">Beri Poin</th>
                                                    <th class="text-center">Aksi</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php $__empty_1 = true; $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                                    <tr>
                                                        <td><?php echo e($student->name); ?></td>
                                                        <td>
                                                            
                                                            <strong><?php echo e($student->coursePoints->first()->pivot->points_earned ?? 0); ?></strong> Poin
                                                        </td>
                                                        <form action="<?php echo e(route('instructor.lesson_points.award', $lesson->id)); ?>" method="POST">
                                                            <?php echo csrf_field(); ?>
                                                            <input type="hidden" name="user_id" value="<?php echo e($student->id); ?>">
                                                            <td>
                                                                <input type="number" name="points" class="form-control" required min="1" placeholder="e.g., 10">
                                                            </td>
                                                            <td class="text-center">
                                                                <button type="submit" class="btn btn-primary btn-sm">Berikan</button>
                                                            </td>
                                                        </form>
                                                    </tr>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                                    <tr>
                                                        <td colspan="4" class="text-center">Belum ada siswa yang terdaftar di kursus ini.</td>
                                                    </tr>
                                                <?php endif; ?>
                                            </tbody>
                                        </table>
                                    </div>
                                    <div class="d-flex justify-content-center">
                                        <?php echo e($students->links()); ?>

                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app-layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/wahaname/public_html/edukasi/resources/views/instructor/lesson-points/manage.blade.php ENDPATH**/ ?>