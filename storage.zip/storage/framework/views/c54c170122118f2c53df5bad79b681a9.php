<?php $__env->startSection('content'); ?>
    <div class="pcoded-content">
        <!-- Page-header start -->
        <div class="page-header">
            <div class="page-block">
                <div class="row align-items-center">
                    <div class="col-md-8">
                        <div class="page-header-title">
                            <h5 class="m-b-10">Edit Pelajaran</h5>
                            <p class="m-b-0">Tipe: Pelajaran Video</p>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <ul class="breadcrumb-title">
                            <li class="breadcrumb-item"><a href="<?php echo e(route('instructor.dashboard')); ?>"><i class="fa fa-home"></i></a></li>
                            <li class="breadcrumb-item"><a href="<?php echo e(route('instructor.courses.modules.index', $lesson->module->course)); ?>">Modul</a></li>
                            <li class="breadcrumb-item"><a href="<?php echo e(route('instructor.modules.lessons.index', $lesson->module)); ?>"><?php echo e(Str::limit($lesson->module->title, 20)); ?></a></li>
                            <li class="breadcrumb-item"><a href="#!">Edit Video</a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
        <!-- Page-header end -->

        <div class="pcoded-inner-content">
            <div class="main-body">
                <div class="page-wrapper">
                    <div class="page-body">
                        <div class="row">
                            <div class="col-sm-12">
                                <div class="card">
                                    <div class="card-header">
                                        <h5>Edit Detail Pelajaran Video</h5>
                                    </div>
                                    <div class="card-block">
                                        <form action="<?php echo e(route('instructor.lessons.update', $lesson->id)); ?>" method="POST" enctype="multipart/form-data">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('PUT'); ?>

                                            
                                            <div class="form-group row">
                                                <label class="col-sm-2 col-form-label">Pratinjau Video Saat Ini</label>
                                                <div class="col-sm-10">
                                                    <?php if($lesson->lessonable->video_path): ?>
                                                        <?php if($lesson->lessonable->source_type == 'upload'): ?>
                                                            
                                                            <video width="100%" style="max-width: 560px;" controls>
                                                                <source src="<?php echo e(Storage::url($lesson->lessonable->video_path)); ?>" type="video/mp4">
                                                                Browser Anda tidak mendukung tag video.
                                                            </video>
                                                        <?php elseif($lesson->lessonable->source_type == 'youtube'): ?>
                                                            
                                                            <?php
                                                                // Ekstrak ID video dari URL YouTube
                                                                preg_match('%(?:youtube(?:-nocookie)?\.com/(?:[^/]+/.+/|(?:v|e(?:mbed)?)/|.*[?&]v=)|youtu\.be/)([^"&?/ ]{11})%i', $lesson->lessonable->video_path, $match);
                                                                $youtube_id = $match[1] ?? null;
                                                            ?>
                                                            <?php if($youtube_id): ?>
                                                                <div class="embed-responsive embed-responsive-16by9" style="max-width: 560px;">
                                                                    <iframe class="embed-responsive-item" src="https://www.youtube.com/embed/<?php echo e($youtube_id); ?>" allowfullscreen></iframe>
                                                                </div>
                                                            <?php else: ?>
                                                                <p class="text-danger">URL YouTube tidak valid.</p>
                                                            <?php endif; ?>
                                                        <?php endif; ?>
                                                    <?php else: ?>
                                                        <p class="text-muted">Tidak ada video yang terhubung dengan pelajaran ini.</p>
                                                    <?php endif; ?>
                                                </div>
                                            </div>

                                            <hr>

                                            <div class="form-group row">
                                                <label class="col-sm-2 col-form-label">Judul Pelajaran</label>
                                                <div class="col-sm-10">
                                                    <input type="text" name="title" class="form-control" value="<?php echo e(old('title', $lesson->title)); ?>" required>
                                                </div>
                                            </div>

                                            <div class="form-group row">
                                                <label class="col-sm-2 col-form-label">Ubah Sumber Video</label>
                                                <div class="col-sm-10">
                                                    <div class="form-radio">
                                                        <div class="radio radio-inline">
                                                            <label>
                                                                <input type="radio" name="source_type" value="upload" <?php echo e(old('source_type', $lesson->lessonable->source_type) == 'upload' ? 'checked' : ''); ?> onchange="toggleVideoSource(this.value)">
                                                                <i class="helper"></i>Unggah File
                                                            </label>
                                                        </div>
                                                        <div class="radio radio-inline">
                                                            <label>
                                                                <input type="radio" name="source_type" value="youtube" <?php echo e(old('source_type', $lesson->lessonable->source_type) == 'youtube' ? 'checked' : ''); ?> onchange="toggleVideoSource(this.value)">
                                                                <i class="helper"></i>Tautan YouTube
                                                            </label>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>

                                            <div id="upload-source" class="form-group row">
                                                <label class="col-sm-2 col-form-label">File Video Baru (Opsional)</label>
                                                <div class="col-sm-10">
                                                    <input type="file" name="video_file" class="form-control" accept="video/mp4,video/x-matroska,video/quicktime">
                                                    <small class="form-text text-muted">Pilih file baru jika ingin mengganti video. Format: MP4, MKV, MOV. Maks: 100MB.</small>
                                                </div>
                                            </div>

                                            <div id="youtube-source" class="form-group row">
                                                <label class="col-sm-2 col-form-label">URL YouTube</label>
                                                <div class="col-sm-10">
                                                    <input type="url" name="video_path" class="form-control" placeholder="Contoh: https://www.youtube.com/watch?v=xxxxxx" value="<?php echo e(old('video_path', $lesson->lessonable->source_type == 'youtube' ? $lesson->lessonable->video_path : '')); ?>">
                                                </div>
                                            </div>

                                            <div class="form-group row mt-4">
                                                <div class="col-sm-12 text-right">
                                                    <a href="<?php echo e(route('instructor.modules.lessons.index', $lesson->module)); ?>" class="btn btn-secondary">Batal</a>
                                                    <button type="submit" class="btn btn-primary">Simpan Perubahan</button>
                                                </div>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
    function toggleVideoSource(source) {
        const uploadDiv = document.getElementById('upload-source');
        const youtubeDiv = document.getElementById('youtube-source');

        if (source === 'upload') {
            uploadDiv.style.display = '';
            youtubeDiv.style.display = 'none';
        } else {
            uploadDiv.style.display = 'none';
            youtubeDiv.style.display = '';
        }
    }

    document.addEventListener('DOMContentLoaded', function() {
        const initialSource = document.querySelector('input[name="source_type"]:checked').value;
        toggleVideoSource(initialSource);
    });
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app-layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/wahaname/public_html/edukasi/resources/views/instructor/lessons/edit-lessonvideo.blade.php ENDPATH**/ ?>