<?php $__env->startSection('content'); ?>
<div class="pcoded-content">
    <!-- Page-header start -->
    <div class="page-header">
        <div class="page-block">
            <div class="row align-items-center">
                <div class="col-md-8">
                    <div class="page-header-title">
                        <h5 class="m-b-10">Buat Kupon Baru</h5>
                        <p class="m-b-0">Isi detail untuk kupon diskon baru.</p>
                    </div>
                </div>
                <div class="col-md-4">
                    <ul class="breadcrumb-title">
                        <li class="breadcrumb-item"><a href="<?php echo e(route(Auth::user()->getRoleNames()->first() . '.dashboard')); ?>"><i class="fa fa-home"></i></a></li>
                        <li class="breadcrumb-item"><a href="<?php echo e(route(Auth::user()->getRoleNames()->first() . '.coupons.index')); ?>">Kupon</a></li>
                        <li class="breadcrumb-item"><a href="#!">Buat</a></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    <!-- Page-header end -->

    <div class="pcoded-inner-content">
        <div class="main-body">
            <div class="page-wrapper">
                <div class="page-body">
                    <div class="row">
                        <div class="col-sm-12">
                            <div class="card">
                                <div class="card-header">
                                    <h5>Detail Kupon</h5>
                                </div>
                                <div class="card-block">
                                    
                                    <?php if($errors->any()): ?>
                                        <div class="alert alert-danger">
                                            <ul>
                                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <li><?php echo e($error); ?></li>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </ul>
                                        </div>
                                    <?php endif; ?>

                                    <form action="<?php echo e(route(Auth::user()->getRoleNames()->first() . '.coupons.store')); ?>" method="POST">
                                        <?php echo csrf_field(); ?>
                                        <div class="form-group row">
                                            <label class="col-sm-2 col-form-label">Kode Kupon</label>
                                            <div class="col-sm-10">
                                                <input type="text" name="code" class="form-control" value="<?php echo e(old('code')); ?>" required placeholder="Contoh: BELAJARHEMAT25">
                                            </div>
                                        </div>
                                        <div class="form-group row">
                                            <label class="col-sm-2 col-form-label">Deskripsi (Opsional)</label>
                                            <div class="col-sm-10">
                                                <textarea name="description" class="form-control" rows="3"><?php echo e(old('description')); ?></textarea>
                                            </div>
                                        </div>
                                        <hr>
                                        <div class="form-group row">
                                            <label class="col-sm-2 col-form-label">Tipe Diskon</label>
                                            <div class="col-sm-4">
                                                <select name="type" class="form-control" required>
                                                    <option value="fixed" <?php echo e(old('type') == 'fixed' ? 'selected' : ''); ?>>Potongan Harga Tetap (Rp)</option>
                                                    <option value="percent" <?php echo e(old('type') == 'percent' ? 'selected' : ''); ?>>Persentase (%)</option>
                                                </select>
                                            </div>
                                            <label class="col-sm-2 col-form-label">Nilai Diskon</label>
                                            <div class="col-sm-4">
                                                <input type="number" name="value" class="form-control" value="<?php echo e(old('value')); ?>" required placeholder="Contoh: 50000 atau 25">
                                            </div>
                                        </div>
                                        <div class="form-group row">
                                            <label class="col-sm-2 col-form-label">Berlaku Untuk</label>
                                            <div class="col-sm-10">
                                                <select name="course_id" class="form-control">
                                                    <option value="">-- Semua Kursus --</option>
                                                    <?php $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($course->id); ?>" <?php echo e(old('course_id') == $course->id ? 'selected' : ''); ?>><?php echo e($course->title); ?></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                            </div>
                                        </div>
                                        <hr>
                                        <div class="form-group row">
                                            <label class="col-sm-2 col-form-label">Batas Penggunaan</label>
                                            <div class="col-sm-10">
                                                <input type="number" name="max_uses" class="form-control" value="<?php echo e(old('max_uses')); ?>" placeholder="Kosongkan jika tidak terbatas">
                                            </div>
                                        </div>
                                        <div class="form-group row">
                                            <label class="col-sm-2 col-form-label">Masa Berlaku</label>
                                            <div class="col-sm-5">
                                                <input type="datetime-local" name="starts_at" class="form-control" value="<?php echo e(old('starts_at')); ?>">
                                                <small class="form-text text-muted">Tanggal Mulai (Opsional)</small>
                                            </div>
                                            <div class="col-sm-5">
                                                <input type="datetime-local" name="expires_at" class="form-control" value="<?php echo e(old('expires_at')); ?>">
                                                <small class="form-text text-muted">Tanggal Kedaluwarsa (Opsional)</small>
                                            </div>
                                        </div>
                                        <div class="form-group row">
                                            <label class="col-sm-2 col-form-label">Status</label>
                                            <div class="col-sm-10">
                                                <div class="form-radio">
                                                    <div class="radio radio-inline">
                                                        <label><input type="radio" name="is_active" value="1" <?php echo e(old('is_active', '1') == '1' ? 'checked' : ''); ?>><i class="helper"></i>Aktif</label>
                                                    </div>
                                                    <div class="radio radio-inline">
                                                        <label><input type="radio" name="is_active" value="0" <?php echo e(old('is_active') == '0' ? 'checked' : ''); ?>><i class="helper"></i>Tidak Aktif</label>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="form-group row">
                                            <div class="col-sm-12 text-right">
                                                <a href="<?php echo e(route(Auth::user()->getRoleNames()->first() . '.coupons.index')); ?>" class="btn btn-secondary">Batal</a>
                                                <button type="submit" class="btn btn-primary">Simpan Kupon</button>
                                            </div>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app-layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/wahaname/public_html/edukasi/resources/views/shared-admin/coupons/create.blade.php ENDPATH**/ ?>