<?php $__env->startSection('content'); ?>

<div class="container d-flex justify-content-center align-items-center h-100 min-vh-100">

    
    <div class="card shadow-sm border-0" style="max-width: 500px; width: 100%;">
        <div class="card-body p-5 text-center">

            
            <div class="mb-4" style="font-size: 3rem;">⏳</div>

            <h3 class="card-title mb-3">Application Pending Review</h3>
            
            <p class="text-muted">
                Thank you for verifying your email. Your instructor application is currently under review by our team. You will be notified by email once a decision has been made.
            </p>
            
            <hr class="my-4">

            <div class="d-grid gap-2">
                <a href="<?php echo e(route('student.dashboard')); ?>" class="btn bg-primary text-white custom-btn-hover">Go to Student Dashboard</a>
                <form method="POST" action="<?php echo e(route('logout')); ?>" class="d-grid">
                    <?php echo csrf_field(); ?>
                    <button type="submit" class="btn btn-outline-secondary">
                        <?php echo e(__('Log Out')); ?>

                    </button>
                </form>
            </div>

        </div>
    </div>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.home-layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/wahaname/public_html/edukasi/resources/views/auth/pending-instructor.blade.php ENDPATH**/ ?>