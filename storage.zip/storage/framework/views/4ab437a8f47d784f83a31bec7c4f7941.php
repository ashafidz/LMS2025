<?php $__env->startSection('content'); ?>
<div class="pcoded-content">
    <!-- Page-header start -->
    <div class="page-header">
        <div class="page-block">
            <div class="row align-items-center">
                <div class="col-md-8">
                    <div class="page-header-title">
                        <h5 class="m-b-10">Publikasi Kursus</h5>
                        <p class="m-b-0">Review dan kelola kursus yang diajukan oleh instruktur.</p>
                    </div>
                </div>
                <div class="col-md-4">
                    <ul class="breadcrumb-title">
                        <li class="breadcrumb-item"><a href="<?php echo e(route('admin.dashboard')); ?>"><i class="fa fa-home"></i></a></li>
                        <li class="breadcrumb-item"><a href="#!">Publikasi</a></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    <!-- Page-header end -->

    <div class="pcoded-inner-content">
        <div class="main-body">
            <div class="page-wrapper">
                <div class="page-body">
                    <div class="row">
                        <div class="col-sm-12">
                            <div class="card">
                                <div class="card-header">
                                    <h5>Kursus Menunggu Review</h5>
                                    <span>Daftar kursus dengan status "Pending Review".</span>
                                </div>
                                <div class="card-block table-border-style">
                                    <?php if(session('success')): ?>
                                        <div class="alert alert-success"><?php echo e(session('success')); ?></div>
                                    <?php endif; ?>
                                    <?php if(session('error')): ?>
                                        <div class="alert alert-danger"><?php echo e(session('error')); ?></div>
                                    <?php endif; ?>
                                    <div class="table-responsive">
                                        <table class="table table-hover">
                                            <thead>
                                                <tr>
                                                    <th>#</th>
                                                    <th>Judul Kursus</th>
                                                    <th>Instruktur</th>
                                                    <th>Kategori</th>
                                                    <th>Tanggal Diajukan</th>
                                                    <th class="text-center">Aksi</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php $__empty_1 = true; $__currentLoopData = $pendingCourses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                                    <tr>
                                                        <th scope="row"><?php echo e($loop->iteration + $pendingCourses->firstItem() - 1); ?></th>
                                                        <td><?php echo e($course->title); ?></td>
                                                        <td><?php echo e($course->instructor->name); ?></td>
                                                        <td><?php echo e($course->category->name); ?></td>
                                                        <td><?php echo e($course->updated_at->format('d F Y')); ?></td>
                                                        <td class="text-center">
                                                            
                                                            <a href="<?php echo e(route('student.courses.show', ['course' => $course->slug, 'preview' => 'true'])); ?>" class="btn btn-inverse btn-sm" target="_blank">Pratinjau</a>
                                                            
                                                            <button type="button" class="btn btn-success btn-sm" data-toggle="modal" data-target="#approveModal-<?php echo e($course->id); ?>">
                                                                Setujui
                                                            </button>
                                                            
                                                            <button type="button" class="btn btn-danger btn-sm" data-toggle="modal" data-target="#rejectModal-<?php echo e($course->id); ?>">
                                                                Tolak
                                                            </button>
                                                        </td>
                                                    </tr>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                                    <tr>
                                                        <td colspan="6" class="text-center">Tidak ada kursus yang menunggu review saat ini.</td>
                                                    </tr>
                                                <?php endif; ?>
                                            </tbody>
                                        </table>
                                    </div>
                                    <div class="d-flex justify-content-center">
                                        <?php echo e($pendingCourses->links()); ?>

                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Modal untuk setiap kursus -->
    <?php $__currentLoopData = $pendingCourses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<!-- Modal Setujui & Tetapkan Harga -->
<div class="modal fade" id="approveModal-<?php echo e($course->id); ?>" tabindex="-1" role="dialog">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Setujui & Publikasikan Kursus</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <form action="<?php echo e(route(Auth::user()->getRoleNames()->first() . '.publication.publish', $course->id)); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PATCH'); ?>
                <div class="modal-body">
                    <p>Anda akan mempublikasikan kursus: <strong><?php echo e($course->title); ?></strong>.</p>
                    
                    
                    <?php if($course->payment_type === 'money'): ?>
                        <div class="form-group">
                            <label for="price">Tetapkan Harga Kursus (Rp)</label>
                            <input type="number" name="price" class="form-control" required min="0" placeholder="Contoh: 150000">
                        </div>
                    <?php elseif($course->payment_type === 'diamonds'): ?>
                        <div class="form-group">
                            <label for="diamond_price">Tetapkan Harga Diamond</label>
                            <input type="number" name="diamond_price" class="form-control" required min="0" placeholder="Contoh: 500">
                        </div>
                    <?php endif; ?>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Batal</button>
                    <button type="submit" class="btn btn-success">Publikasikan</button>
                </div>
            </form>
        </div>
    </div>
</div>

        <!-- Modal Tolak -->
        <div class="modal fade" id="rejectModal-<?php echo e($course->id); ?>" tabindex="-1" role="dialog">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title">Tolak Kursus</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <form action="<?php echo e(route('admin.publication.reject', $course->id)); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PATCH'); ?>
                        <div class="modal-body">
                            <p>Anda akan menolak kursus: <strong><?php echo e($course->title); ?></strong>.</p>
                            <div class="form-group">
                                <label for="rejection_reason">Alasan Penolakan (Opsional)</label>
                                <textarea name="rejection_reason" class="form-control" rows="4" placeholder="Jelaskan mengapa kursus ini ditolak agar instruktur bisa memperbaikinya..."></textarea>
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-dismiss="modal">Batal</button>
                            <button type="submit" class="btn btn-danger">Tolak Kursus</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app-layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/wahaname/public_html/edukasi/resources/views/shared-admin/publication/index.blade.php ENDPATH**/ ?>