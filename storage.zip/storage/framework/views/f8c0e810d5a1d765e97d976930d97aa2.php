 

<?php $__env->startSection('content'); ?>
    <div class="pcoded-content">
        <!-- Page-header start -->
        <div class="page-header">
            <div class="page-block">
                <div class="row align-items-center">
                    <div class="col-md-8">
                        <div class="page-header-title">
                            <h5 class="m-b-10">Mulai Kuis</h5>
                            <p class="m-b-0">Kursus: <?php echo e($quiz->lesson->module->course->title); ?></p>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <ul class="breadcrumb-title">
                            <li class="breadcrumb-item"><a href="#"><i class="fa fa-home"></i></a></li>
                            <li class="breadcrumb-item"><a
                                    href="<?php echo e(route('student.courses.show', $quiz->lesson->module->course->slug)); ?>">Kursus Saya</a>
                            </li>
                            <li class="breadcrumb-item"><a href="#!">Kuis</a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
        <!-- Page-header end -->

        <div class="pcoded-inner-content">
            <div class="main-body">
                <div class="page-wrapper">
                    <div class="page-body">
                        
                        <?php if($is_preview): ?>
                            <div class="alert alert-warning text-center text-dark" style="background-color: #f2e529;">
                                <strong>Mode Pratinjau</strong><br>
                                Anda melihat halaman ini sebagai Instruktur/Admin. Hasil kuis tidak akan disimpan.
                            </div>
                        <?php endif; ?>

                        <div class="row d-flex justify-content-center">
                            <div class="col-md-8">
                                <div class="card">
                                    <div class="card-body text-center">
                                        <h2 class="card-title" style="font-size: 25px;"><?php echo e($quiz->title); ?></h2>
                                        <p class="card-text text-muted" style="font-size: 16px;">
                                            <?php echo e($quiz->description); ?>

                                        </p>
                                        <hr>
                                        <div class="row text-center">
                                            <div class="col-6 mb-4">
                                                <div class="d-flex flex-column align-items-center">
                                                    <i class="fa fa-question-circle-o fa-3x mb-2"></i>
                                                    <h5>Jumlah Soal</h5>
                                                    <p class="card-text text-muted" style="font-size: 16px;"><?php echo e($quiz->questions_count); ?> Soal</p>
                                                </div>
                                            </div>
                                            <div class="col-6 mb-4">
                                                <div class="d-flex flex-column align-items-center">
                                                    <i class="fa fa-clock-o fa-3x mb-2"></i>
                                                    <h5>Batas Waktu</h5>
                                                    <p class="card-text text-muted" style="font-size: 16px;"><?php echo e($quiz->time_limit ? $quiz->time_limit . ' Menit' : 'Tidak ada'); ?></p>
                                                </div>
                                            </div>
                                            <div class="col-6 mb-4">
                                                <div class="d-flex flex-column align-items-center">
                                                    <i class="fa fa-check-square-o fa-3x mb-2"></i>
                                                    <h5>Nilai Kelulusan</h5>
                                                    <p class="card-text text-muted" style="font-size: 16px;"><?php echo e($quiz->pass_mark); ?>%</p>
                                                </div>
                                            </div>
                                            <div class="col-6 mb-4">
                                                <div class="d-flex flex-column align-items-center">
                                                    <i class="fa fa-repeat fa-3x mb-2"></i>
                                                    <h5>Kesempatan</h5>
                                                    <p class="card-text text-muted" style="font-size: 16px;">
                                                        <?php echo e($quiz->max_attempts ? $attemptCount . ' / ' . $quiz->max_attempts . ' Kali' : 'Tanpa Batas'); ?>

                                                    </p>
                                                </div>
                                            </div>
                                        </div>
                                        <hr>

                                        
                                        <?php if(!$is_preview): ?>
                                            <?php
                                                // Cek apakah siswa masih punya kesempatan untuk mencoba kuis
                                                $canAttempt =
                                                    is_null($quiz->max_attempts) || $attemptCount < $quiz->max_attempts;
                                            ?>

                                            <div class="mt-4">
                                                <?php if($isAvailable): ?>
                                                    
                                                    <?php if($canAttempt): ?>
                                                        <form action="<?php echo e(route('student.quiz.begin', $quiz->id)); ?>"
                                                            method="POST" class="d-inline">
                                                            <?php echo csrf_field(); ?>
                                                            <button type="submit" class="btn btn-primary btn-lg">
                                                                
                                                                <?php echo e($attemptCount > 0 ? 'Coba Lagi' : 'Mulai Kuis'); ?>

                                                            </button>
                                                        </form>
                                                    <?php else: ?>
                                                        
                                                        <button class="btn btn-danger btn-lg" disabled>Kesempatan Habis</button>
                                                    <?php endif; ?>
                                                <?php else: ?>
                                                    <button class="btn btn-danger btn-lg" disabled>Tidak Tersedia</button>
                                                <?php endif; ?>
                                            </div>
                                        <?php else: ?>
                                            
                                            <form action="<?php echo e(route('student.quiz.begin', $quiz->id)); ?>" method="POST">
                                                <?php echo csrf_field(); ?>
                                                <input type="hidden" name="is_preview" value="true">
                                                <button type="submit" class="btn btn-primary btn-lg">Mulai Kuis
                                                    (Preview)</button>
                                            </form>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const isPreview = <?php echo json_encode($is_preview, 15, 512) ?>;
            console.log(isPreview);
        })
    </script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app-layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/wahaname/public_html/edukasi/resources/views/student/quizzes/start.blade.php ENDPATH**/ ?>