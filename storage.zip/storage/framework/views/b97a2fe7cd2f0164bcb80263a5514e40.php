<?php $__env->startSection('content'); ?>
<div class="pcoded-content">
    <div class="page-header">
        <div class="page-block">
            <div class="row align-items-center">
                <div class="col-md-8">
                    <div class="page-header-title">
                        <h5 class="m-b-10">Poin Saya</h5>
                        <p class="m-b-0">Lihat total poin dan riwayat perolehan poin Anda di setiap kursus.</p>
                    </div>
                </div>
                <div class="col-md-4">
                    <ul class="breadcrumb-title">
                        <li class="breadcrumb-item"><a href="<?php echo e(route('student.dashboard')); ?>"><i class="fa fa-home"></i></a></li>
                        <li class="breadcrumb-item"><a href="#!">Poinku</a></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>

    <div class="pcoded-inner-content">
        <div class="main-body">
            <div class="page-wrapper">
                <div class="page-body">
                    
                    <div class="row">
                        
                        <div class="col-md-4">
                            
                            <div class="card widget-visitor-card mb-4">
                                <div class="card-block-big text-center">
                                    <i class="ti-medall-alt text-warning f-40"></i>
                                    <h4 class="m-t-20"><span class="text-warning"><?php echo e(number_format($totalPoints, 0, ',', '.')); ?></span> Poin</h4>
                                    <p>Total Akumulasi Poin anda saat ini</p>
                                </div>
                            </div>
                            
                            
                            <div class="card shadow-sm mb-4">
                                <div class="card-block" style="height:283px;">
                                    <!-- Judul -->
                                    <h6 class="fw-bold mb-1">Line Chart</h6>
                                    <p class="text-muted mb-4">
                                        lorem ipsum dolor sit amet, consectetur adipisicing elit
                                    </p> 
                            
                                    <!-- Grafik -->
                                    <canvas id="myLineChart" style="height:300px;"></canvas>
                                </div>
                            </div>
                            
                            <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
                            <script>
                                const ctx = document.getElementById('myLineChart').getContext('2d');
                            
                                new Chart(ctx, {
                                    type: 'line',
                                    data: {
                                        labels: ['2006', '2007', '2008', '2009', '2010', '2011', '2012'],
                                        datasets: [
                                            {
                                                data: [100, 75, 50, 75, 50, 75, 100],
                                                borderColor: '#99ABCB',
                                                tension: 0.4
                                            },
                                            {
                                                data: [90, 65, 40, 65, 40, 65, 90],
                                                borderColor: '#FF9F40',
                                                tension: 0.4
                                            }
                                        ]
                                    }
                                });
                            </script>

                    
                            
                            <div class="card">
                                <div class="card-header">
                                    <h5>Cara Mendapatkan Poin</h5>
                                </div>
                                <div class="card-block">
                                    <ul class="list-group list-group-flush">
                                        <li class="list-group-item d-flex justify-content-between align-items-center">
                                            Membeli Kursus Dengan Uang <span class="badge badge-success"><?php echo e($siteSettings->points_for_purchase ? number_format($siteSettings->points_for_purchase, 0, ',', '.') : '0'); ?> Poin</span>
                                        </li>
                                        <li class="list-group-item d-flex justify-content-between align-items-center">
                                            Menyelesaikan Lesson Tipe Article <span class="badge badge-success"><?php echo e($siteSettings->points_for_article ? number_format($siteSettings->points_for_article, 0, ',', '.') : '0'); ?> Poin</span>
                                        </li>
                                        <li class="list-group-item d-flex justify-content-between align-items-center">
                                            Menyelesaikan Lesson Tipe Video <span class="badge badge-success"><?php echo e($siteSettings->points_for_video ? number_format($siteSettings->points_for_video, 0, ',', '.') : '0'); ?> Poin</span>
                                        </li>
                                        <li class="list-group-item d-flex justify-content-between align-items-center">
                                            Menyelesaikan Lesson Tipe Dokumen <span class="badge badge-success"><?php echo e($siteSettings->points_for_document ? number_format($siteSettings->points_for_document, 0, ',', '.') : '0'); ?> Poin</span>
                                        </li>
                                        <li class="list-group-item d-flex justify-content-between align-items-center">
                                            Menyelesaikan Lesson Tipe Quiz <span class="badge badge-success"><?php echo e($siteSettings->points_for_quiz ? number_format($siteSettings->points_for_quiz, 0, ',', '.') : '0'); ?> Poin</span>
                                        </li>
                                        <li class="list-group-item d-flex justify-content-between align-items-center">
                                            Menyelesaikan Lesson Tipe Assignment <span class="badge badge-success"><?php echo e($siteSettings->points_for_assignment ? number_format($siteSettings->points_for_assignment, 0, ',', '.') : '0'); ?> Poin</span>
                                        </li>
                                        
                                    </ul>
                                </div>
                            </div>
                        </div>
                    
                        
                        <div class="col-md-8">
                            
                            <div class="card mb-4">
                                <div class="card-header">
                                    <h5>Rincian Poin per Kursus</h5>
                                </div>
                                <div class="card-block table-border-style">
                                    <div class="table-responsive" style="max-height: 320px; overflow-y: auto;">
                                        <table class="table table-hover mb-0">
                                            <thead>
                                                <tr>
                                                    <th>Nama Kursus</th>
                                                    <th>Poin</th>
                                                    <th>Status</th>
                                                    <th class="text-center">Aksi</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php $__empty_1 = true; $__currentLoopData = $pointsPerCourse; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                                    <tr>
                                                        <td><?php echo e($course->title); ?></td>
                                                        <td><strong><?php echo e($course->pivot->points_earned); ?> Poin</strong></td>
                                                        <td>
                                                            <?php if($course->pivot->is_converted_to_diamond): ?>
                                                                <label class="label label-success">Sudah Dikonversi</label>
                                                            <?php else: ?>
                                                                <label class="label label-default">Belum Dikonversi</label>
                                                            <?php endif; ?>
                                                        </td>
                                                        <td class="text-center">
                                                            <button class="btn btn-inverse btn-sm" data-toggle="modal" data-target="#historyModal-<?php echo e($course->id); ?>">
                                                                Lihat Riwayat
                                                            </button>
                                                        </td>
                                                    </tr>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                                    <tr>
                                                        <td colspan="4" class="text-center">Anda belum mendapatkan poin dari kursus manapun.</td>
                                                    </tr>
                                                <?php endif; ?>
                                            </tbody>
                                        </table>
                                    </div>
                                    <div class="d-flex justify-content-center mt-3">
                                        <?php echo e($pointsPerCourse->links()); ?>

                                    </div>
                                </div>
                            </div>
                    
                            
                            <div class="card mb-4">
                                <div class="card-block text-center">
                                    <i class="fa fa-diamond text-c-blue d-block f-40"></i>
                                        <h4 class="m-t-20"><span class="text-c-blue"><?php echo e(number_format($user->diamond_balance, 0, ',', '.')); ?></span> Diamond</h4>
                                    <p class="m-b-20">Saldo Diamond Anda Saat Ini</p>
                                    <a href="<?php echo e(route('courses')); ?>" class="btn btn-primary btn-sm btn-round">Gunakan Diamond</a>
                                </div>
                            </div>
                    
                            
                            <div class="card">
                                <div class="card-header">
                                    <h5>Riwayat Diamond</h5>
                                </div>
                                <div class="card-block table-border-style">
                                    <div class="table-responsive" style="max-height: 220px; overflow-y: auto;">
                                        <table class="table table-hover mb-0">
                                            <thead>
                                                <tr>
                                                    <th>Tanggal</th>
                                                    <th>Deskripsi</th>
                                                    <th class="text-right">Jumlah</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php $__empty_1 = true; $__currentLoopData = $diamondHistories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $history): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                                    <tr>
                                                        <td><?php echo e($history->created_at->format('d M Y, H:i')); ?></td>
                                                        <td><?php echo e($history->description); ?></td>
                                                        <td class="text-right">
                                                            <?php if($history->diamonds > 0): ?>
                                                                <span class="text-success font-weight-bold">+<?php echo e($history->diamonds); ?></span>
                                                            <?php else: ?>
                                                                <span class="text-danger font-weight-bold"><?php echo e($history->diamonds); ?></span>
                                                            <?php endif; ?>
                                                        </td>
                                                    </tr>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                                    <tr>
                                                        <td colspan="3" class="text-center">Anda belum memiliki riwayat diamond.</td>
                                                    </tr>
                                                <?php endif; ?>
                                            </tbody>
                                        </table>
                                    </div>
                                    <div class="d-flex justify-content-center mt-3">
                                        <?php echo e($diamondHistories->links()); ?>

                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    
                    <?php $__currentLoopData = $pointsPerCourse; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="modal fade" id="historyModal-<?php echo e($course->id); ?>" tabindex="-1" role="dialog">
                        <div class="modal-dialog" role="document">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h5 class="modal-title">Riwayat Poin: <?php echo e($course->title); ?></h5>
                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                        <span aria-hidden="true">&times;</span>
                                    </button>
                                </div>
                                <div class="modal-body">
                                    <ul class="list-group list-group-flush">
                                        <?php $__empty_1 = true; $__currentLoopData = $pointHistories[$course->id] ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $history): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                            <li class="list-group-item d-flex justify-content-between align-items-center">
                                                <div>
                                                    <?php echo e($history->description); ?><br>
                                                    <small class="text-muted"><?php echo e($history->created_at->format('d M Y, H:i')); ?></small>
                                                </div>
                                                <span class="badge badge-primary badge-pill">+<?php echo e($history->points); ?></span>
                                            </li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                            <li class="list-group-item text-muted">Tidak ada riwayat untuk kursus ini.</li>
                                        <?php endif; ?>
                                    </ul>
                                </div>
                                <div class="modal-footer">
                                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Tutup</button>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app-layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/wahaname/public_html/edukasi/resources/views/student/my-points/index.blade.php ENDPATH**/ ?>