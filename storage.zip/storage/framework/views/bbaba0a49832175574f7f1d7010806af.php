<?php $__env->startSection('content'); ?>
<div class="pcoded-content">
    <!-- Page-header start -->
    <div class="page-header">
        <div class="page-block">
            <div class="row align-items-center">
                <div class="col-md-8">
                    <div class="page-header-title">
                        <h5 class="m-b-10">Kelola Ulasan Saya</h5>
                        <p class="m-b-0">Lihat dan perbarui semua ulasan yang telah Anda berikan.</p>
                    </div>
                </div>
                <div class="col-md-4">
                    <ul class="breadcrumb-title">
                        <li class="breadcrumb-item"><a href="<?php echo e(route('student.dashboard')); ?>"><i class="fa fa-home"></i></a></li>
                        <li class="breadcrumb-item"><a href="#!">Ulasan Saya</a></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    <!-- Page-header end -->

    <div class="pcoded-inner-content">
        <div class="main-body">
            <div class="page-wrapper">
                <div class="page-body">
                    <?php if(session('success')): ?>
                        <div class="alert alert-success"><?php echo e(session('success')); ?></div>
                    <?php endif; ?>
                    <?php if($errors->any()): ?>
                        <div class="alert alert-danger">
                            <ul>
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($error); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    <?php endif; ?>

                    <!-- BAGIAN ULASAN PLATFORM -->
                    <div class="card">
                        <div class="card-header">
                            <h5>Ulasan Anda Tentang Platform Ini</h5>
                        </div>
                        <div class="card-block">
                            <?php if($platformReview): ?>
                                
                                <div class="d-flex justify-content-between align-items-center">
                                    <div>
                                        <p>Terima kasih atas ulasan Anda! Anda bisa memperbaruinya kapan saja.</p>
                                        <p class="mb-0"><strong>Rating Anda:</strong> 
                                            <span class="text-warning">
                                            <?php for($i = 1; $i <= 5; $i++): ?>
                                                <i class="fa <?php echo e($i <= $platformReview->rating ? 'fa-star' : 'fa-star-o'); ?>"></i>
                                            <?php endfor; ?>
                                            </span>
                                        </p>
                                    </div>
                                    <button class="btn btn-primary" data-toggle="modal" data-target="#platformReviewModal">Edit Ulasan</button>
                                </div>
                            <?php else: ?>
                                
                                <div class="text-center">
                                    <p>Anda belum memberikan ulasan untuk platform kami. Umpan balik Anda sangat berharga untuk membantu kami menjadi lebih baik.</p>
                                    <button class="btn btn-primary" data-toggle="modal" data-target="#platformReviewModal">Beri Ulasan Platform</button>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>

                    <!-- BAGIAN ULASAN INSTRUKTUR -->
                    <div class="card">
                        <div class="card-header">
                            <h5>Ulasan Anda untuk Instruktur</h5>
                        </div>
                        <div class="card-block">
                            <?php $__empty_1 = true; $__currentLoopData = $instructorReviews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $review): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <div class="d-flex justify-content-between align-items-center border-bottom pb-3 mb-3">
                                    <div>
                                        <h6 class="mb-1"><?php echo e($review->instructor->name); ?></h6>
                                        <p class="text-muted mb-1">Dalam kursus: <strong><?php echo e($review->course->title); ?></strong></p>
                                        <p class="mb-0">
                                            <span class="text-warning">
                                            <?php for($i = 1; $i <= 5; $i++): ?>
                                                <i class="fa <?php echo e($i <= $review->rating ? 'fa-star' : 'fa-star-o'); ?>"></i>
                                            <?php endfor; ?>
                                            </span>
                                        </p>
                                    </div>
                                    <button class="btn btn-info btn-sm" data-toggle="modal" data-target="#instructorReviewModal-<?php echo e($review->id); ?>">Edit</button>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <p class="text-muted">Anda belum memberikan ulasan untuk instruktur manapun.</p>
                            <?php endif; ?>
                            <div class="d-flex justify-content-center">
                                <?php echo e($instructorReviews->links('pagination::bootstrap-4')); ?>

                            </div>
                        </div>
                    </div>

                    <!-- BAGIAN ULASAN KURSUS -->
                    <div class="card">
                        <div class="card-header">
                            <h5>Ulasan Anda untuk Kursus</h5>
                        </div>
                        <div class="card-block">
                            <?php $__empty_1 = true; $__currentLoopData = $courseReviews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $review): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <div class="d-flex justify-content-between align-items-center border-bottom pb-3 mb-3">
                                    <div>
                                        <h6 class="mb-1"><?php echo e($review->course->title); ?></h6>
                                        <p class="mb-0">
                                            <span class="text-warning">
                                            <?php for($i = 1; $i <= 5; $i++): ?>
                                                <i class="fa <?php echo e($i <= $review->rating ? 'fa-star' : 'fa-star-o'); ?>"></i>
                                            <?php endfor; ?>
                                            </span>
                                        </p>
                                    </div>
                                    <button class="btn btn-info btn-sm" data-toggle="modal" data-target="#courseReviewModal-<?php echo e($review->id); ?>">Edit</button>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <p class="text-muted">Anda belum memberikan ulasan untuk kursus manapun.</p>
                            <?php endif; ?>
                            <div class="d-flex justify-content-center">
                                <?php echo e($courseReviews->links('pagination::bootstrap-4')); ?>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    
    <?php echo $__env->make('student.my-reviews.partials._platform_review_modal', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <?php $__currentLoopData = $instructorReviews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $review): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php echo $__env->make('student.my-reviews.partials._instructor_review_modal', ['review' => $review], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php $__currentLoopData = $courseReviews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $review): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php echo $__env->make('student.my-reviews.partials._course_review_modal', ['review' => $review], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>


<?php $__env->startPush('styles'); ?>
<style>
    .star-rating { display: inline-block; direction: rtl; }
    .star-rating input { display: none; }
    .star-rating label { font-size: 2.5rem; color: #ddd; cursor: pointer; }
    .star-rating input:checked ~ label, .star-rating label:hover, .star-rating label:hover ~ label { color: #f5b301; }
    .likert-scale .btn-check:checked+.btn { background-color: #007bff; color: white; }
</style>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app-layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/wahaname/public_html/edukasi/resources/views/student/my-reviews/index.blade.php ENDPATH**/ ?>