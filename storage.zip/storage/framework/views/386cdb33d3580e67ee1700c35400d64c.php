<?php $__env->startSection('content'); ?>
<div class="pcoded-content">
    <!-- Page-header start -->
    <div class="page-header">
        <div class="page-block">
            <div class="row align-items-center">
                <div class="col-md-8">
                    <div class="page-header-title">
                        <h5 class="m-b-10">Kursus Saya</h5>
                        <p class="m-b-0">Lanjutkan progres belajar Anda di kursus yang telah Anda miliki.</p>
                    </div>
                </div>
                <div class="col-md-4">
                    <ul class="breadcrumb-title">
                        <li class="breadcrumb-item"><a href="<?php echo e(route('student.dashboard')); ?>"><i class="fa fa-home"></i></a></li>
                        <li class="breadcrumb-item"><a href="#!">Kursus Saya</a></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    <!-- Page-header end -->

    <div class="pcoded-inner-content">
        <div class="main-body">
            <div class="page-wrapper">
                <div class="page-body">
                    <div class="row">
                        <?php $__empty_1 = true; $__currentLoopData = $enrolledCourses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <div class="col-md-6 col-lg-4">
                                <div class="card">
                                    <img class="card-img-top" src="<?php echo e($course->thumbnail_url ? Storage::url($course->thumbnail_url) : 'https://placehold.co/600x400/e0edff/007bff?text=Kursus'); ?>" alt="<?php echo e($course->title); ?>" style="height: 180px; object-fit: cover;">
                                    <div class="card-block">
                                        <h5 class="card-title"><?php echo e($course->title); ?></h5>
                                        <p class="card-text text-muted">Oleh: <?php echo e($course->instructor->name); ?></p>
                                        
                                        
                                        <?php
                                            $progress = 0;
                                            if ($course->lessons_count > 0) {
                                                $progress = ($course->completed_lessons_count / $course->lessons_count) * 100;
                                            }
                                        ?>
                                        <div class="progress mb-3">
                                            <div class="progress-bar" role="progressbar" style="width: <?php echo e($progress); ?>%;" aria-valuenow="<?php echo e($progress); ?>" aria-valuemin="0" aria-valuemax="100"><?php echo e(round($progress)); ?>%</div>
                                        </div>

                                        <a href="<?php echo e(route('student.courses.show', $course->slug)); ?>" class="btn btn-primary btn-block">Lanjutkan Belajar</a>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <div class="col-sm-12">
                                <div class="card">
                                    <div class="card-block text-center p-5">
                                        <i class="fa fa-book fa-3x text-muted mb-3"></i>
                                        <h4>Anda Belum Terdaftar di Kursus Apapun</h4>
                                        <p>Jelajahi katalog kami untuk menemukan kursus yang cocok untuk Anda.</p>
                                        <a href="<?php echo e(route('courses')); ?>" class="btn btn-primary mt-2">Lihat Katalog Kursus</a>
                                    </div>
                                </div>
                            </div>
                        <?php endif; ?>
                    </div>

                    
                    <div class="row">
                        <div class="col-12 d-flex justify-content-center">
                            <?php echo e($enrolledCourses->links()); ?>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app-layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/wahaname/public_html/edukasi/resources/views/student/courses/index.blade.php ENDPATH**/ ?>