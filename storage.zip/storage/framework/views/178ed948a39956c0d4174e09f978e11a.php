<?php $__env->startSection('content'); ?>
<div class="pcoded-content">
    <!-- Page-header start -->
    <div class="page-header">
        <div class="page-block">
            <div class="row align-items-center">
                <div class="col-md-8">
                    <div class="page-header-title">
                        <h5 class="m-b-10">Manajemen Badge</h5>
                        <p class="m-b-0">Buat, lihat, dan kelola semua badge pencapaian.</p>
                    </div>
                </div>
                <div class="col-md-4">
                    <ul class="breadcrumb-title">
                        <li class="breadcrumb-item"><a href="<?php echo e(route('superadmin.dashboard')); ?>"><i class="fa fa-home"></i></a></li>
                        <li class="breadcrumb-item"><a href="#!">Badge</a></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    <!-- Page-header end -->

    <div class="pcoded-inner-content">
        <div class="main-body">
            <div class="page-wrapper">
                <div class="page-body">
                    <div class="row">
                        <div class="col-sm-12">
                            <div class="card">
                                <div class="card-header">
                                    <h5>Daftar Badge</h5>
                                    <div class="card-header-right">
                                        <a href="<?php echo e(route('superadmin.badges.create')); ?>" class="btn btn-primary">Buat Badge Baru</a>
                                    </div>
                                </div>
                                <div class="card-block table-border-style">
                                    <?php if(session('success')): ?>
                                        <div class="alert alert-success"><?php echo e(session('success')); ?></div>
                                    <?php endif; ?>
                                    <div class="table-responsive">
                                        <table class="table table-hover">
                                            <thead>
                                                <tr>
                                                    <th>#</th>
                                                    <th>Ikon</th>
                                                    <th>Judul</th>
                                                    <th>Deskripsi</th>
                                                    <th>Status</th>
                                                    <th class="text-center">Aksi</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php $__empty_1 = true; $__currentLoopData = $badges; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $badge): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                                    <tr>
                                                        <th scope="row"><?php echo e($loop->iteration + $badges->firstItem() - 1); ?></th>
                                                        <td>
                                                            <img src="<?php echo e(Storage::url($badge->icon_path)); ?>" alt="<?php echo e($badge->title); ?>" style="width: 40px; height: 40px; object-fit: cover;">
                                                        </td>
                                                        <td><?php echo e($badge->title); ?></td>
                                                        <td><?php echo e(Str::limit($badge->description, 50)); ?></td>
                                                        <td>
                                                            <?php if($badge->is_active): ?>
                                                                <label class="label label-success">Aktif</label>
                                                            <?php else: ?>
                                                                <label class="label label-default">Tidak Aktif</label>
                                                            <?php endif; ?>
                                                        </td>
                                                        <td class="text-center">
                                                            <a href="<?php echo e(route('superadmin.badges.edit', $badge->id)); ?>" class="btn btn-info btn-sm">
                                                                <i class="fa fa-pencil"></i> Edit
                                                            </a>
                                                            <form action="<?php echo e(route('superadmin.badges.destroy', $badge->id)); ?>" method="POST" class="d-inline" onsubmit="return confirm('Apakah Anda yakin ingin menghapus badge ini?');">
                                                                <?php echo csrf_field(); ?>
                                                                <?php echo method_field('DELETE'); ?>
                                                                <button type="submit" class="btn btn-danger btn-sm">
                                                                    <i class="fa fa-trash"></i> Hapus
                                                                </button>
                                                            </form>
                                                        </td>
                                                    </tr>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                                    <tr>
                                                        <td colspan="6" class="text-center">Belum ada badge yang dibuat.</td>
                                                    </tr>
                                                <?php endif; ?>
                                            </tbody>
                                        </table>
                                    </div>
                                    <div class="d-flex justify-content-center">
                                        <?php echo e($badges->links()); ?>

                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app-layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/wahaname/public_html/edukasi/resources/views/superadmin/badges/index.blade.php ENDPATH**/ ?>