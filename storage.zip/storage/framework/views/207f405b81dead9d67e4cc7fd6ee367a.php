                        <nav class="pcoded-navbar">
                            <div class="sidebar_toggle">
                                <a href="#"><i class="icon-close icons"></i></a>
                            </div>
                            <div class="pcoded-inner-navbar main-menu">
                                <div class="">
                                    <div class="main-menu-header">
                                        
                                        <div class="user-details">
                                            <span id="more-details"><?php echo e(Auth::user()->name); ?><i
                                                    class="fa fa-caret-down"></i></span>
                                        </div>
                                    </div>

                                    <div class="main-menu-content">
                                        <ul>
                                            <li class="more-details">
                                                <a href="<?php echo e(route('home')); ?>"><i class="ti-home"></i>Home</a>
                                                <a href="<?php echo e(route('user.profile.index')); ?>"><i class="ti-user"></i>
                                                    Profile</a>
                                                <a href="<?php echo e(route('student.cart.index')); ?>"><i class="ti-shopping-cart"></i>
                                                    Keranjang</a>
                                                <a href="<?php echo e(route('student.badges.index')); ?>"><i class="ti-medall"></i>Badgeku</a>
                                                <a href="<?php echo e(route('logout')); ?>"
                                                    onclick="event.preventDefault(); document.getElementById('logout-form').submit();"><i
                                                        class="ti-layout-sidebar-left"></i>Logout</a>
                                                <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST"
                                                    style="display: none;">
                                                    <?php echo csrf_field(); ?>
                                                </form>
                                            </li>
                                        </ul>
                                    </div>
                                </div>

                                <div class="pcoded-navigation-label" data-i18n="nav.category.navigation">
                                    Menu Sidebar
                                </div>
                                <ul class="pcoded-item pcoded-left-item">
                                    
                                    <li class="<?php echo e(Request::routeIs('student.my_courses') ? 'active' : ''); ?>">
                                        <a href="<?php echo e(route('student.my_courses')); ?>" class="waves-effect waves-dark">
                                            <span class="pcoded-micon"><i class="ti-agenda"></i><b>D</b></span>
                                            <span class="pcoded-mtext" data-i18n="nav.dash.main">Kursus Saya</span>
                                            <span class="pcoded-mcaret"></span>
                                        </a>
                                    </li>
                                    <li class="<?php echo e(Request::routeIs('student.points.index') ? 'active' : ''); ?>">
                                        <a href="<?php echo e(route('student.points.index')); ?>" class="waves-effect waves-dark">
                                            <span class="pcoded-micon"><i class="ti-crown"></i><b>D</b></span>
                                            <span class="pcoded-mtext" data-i18n="nav.dash.main">Poin & Diamond</span>
                                            <span class="pcoded-mcaret"></span>
                                        </a>
                                    </li>
                                    
                                    <li class="<?php echo e(Request::routeIs('student.reviews.index') ? 'active' : ''); ?>">
                                        <a href="<?php echo e(route('student.reviews.index')); ?>" class="waves-effect waves-dark">
                                            <span class="pcoded-micon"><i class="ti-comment"></i><b>D</b></span>
                                            <span class="pcoded-mtext" data-i18n="nav.dash.main">Feedback</span>
                                            <span class="pcoded-mcaret"></span>
                                        </a>
                                    </li>
                                    <li class="<?php echo e(Request::routeIs('student.transactions.index') ? 'active' : ''); ?>">
                                        <a href="<?php echo e(route('student.transactions.index')); ?>" class="waves-effect waves-dark">
                                            <span class="pcoded-micon"><i class="ti-receipt"></i><b>D</b></span>
                                            <span class="pcoded-mtext" data-i18n="nav.dash.main">Riwayat Transaksi</span>
                                            <span class="pcoded-mcaret"></span>
                                        </a>
                                    </li>
                                    <li class="">
                                        <a href="#" class="waves-effect waves-dark">
                                            <span class="pcoded-micon"><i class="ti-layers"></i><b>FC</b></span>
                                            <span class="pcoded-mtext" data-i18n="nav.form-components.main">Fitur Selanjutnya</span>
                                            <span class="pcoded-mcaret"></span>
                                        </a>
                                    </li>
                                </ul>

                            </div>
                        </nav>
<?php /**PATH /home/wahaname/public_html/edukasi/resources/views/layouts/navigations/sidebars/student-sidebar.blade.php ENDPATH**/ ?>