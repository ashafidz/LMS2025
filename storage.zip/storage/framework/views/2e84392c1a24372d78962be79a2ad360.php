<?php $__env->startSection('content'); ?>
    <div class="pcoded-content">
        <!-- Page-header start -->
        <div class="page-header">
            <div class="page-block">
                <div class="row align-items-center">
                    <div class="col-md-8">
                        <div class="page-header-title">
                            <h5 class="m-b-10">
                                Dashboard
                            </h5>
                            <p class="m-b-0">
                                Selamat datang di Dashboard Admin
                            </p>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <ul class="breadcrumb-title">
                            <li class="breadcrumb-item">
                                <a href="<?php echo e(route('home')); ?>">
                                    <i class="fa fa-home"></i>
                                </a>
                            </li>
                            <li class="breadcrumb-item">
                                <a href="#!">Manajemen Student</a>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
        <!-- Page-header end -->
        <div class="pcoded-inner-content">
            <!-- Main-body start -->
            <div class="main-body">
                <div class="page-wrapper">
                    <!-- Page-body start -->
                    <div class="page-body">
                        <div class="row">

                            <!--  project and team member start -->
                            <div class="col-sm-12">
                                <div class="card table-card">
                                    <div class="card-header">
                                        <h5>List Student</h5>
                                        <p>List student yang terdaftar</p>
                                        <div class="card-header-right">
                                            
                                        </div>
                                    </div>
                                    <div class="card-block">
                                        <div class="table-responsive">
                                            <table class="table table-hover">
                                                <thead>
                                                    <tr>
                                                        <th>
                                                            Nama Student
                                                        </th>
                                                        <th>
                                                            Email
                                                        </th>
                                                        <th class="text-center">
                                                            Student Status
                                                        </th>
                                                        <th class="text-center">
                                                            Action
                                                        </th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <?php $__empty_1 = true; $__currentLoopData = $students_status_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student_status_data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

                                                    
                                                    <?php
                                                        $actionRouteDeactive = Auth::user()->hasRole('admin') 
                                                        ? route('admin.manajemen-student.deactive', $student_status_data)
                                                        : route('superadmin.manajemen-student.deactive', $student_status_data);

                                                                   
                                                        $actionRouteReactivate = Auth::user()->hasRole('admin') 
                                                            ? route('admin.manajemen-student.reactivate', $student_status_data) 
                                                            : route('superadmin.manajemen-student.reactivate', $student_status_data); 
                                                    ?>
                                                    


                                                        <tr>
                                                            <td>
                                                                <div class="d-inline-block align-middle">
                                                                    
                                                                    <img src="<?php echo e($student_status_data->user->profile_picture_url ?? 'https://placehold.co/32x32/EBF4FF/767676?text=SA'); ?>"
                                                                        alt="user image"
                                                                        class="img-radius img-40 align-top m-r-15" />
                                                                    <div class="d-inline-block">
                                                                        <h6>
                                                                            <?php echo e($student_status_data->user->name); ?>

                                                                        </h6>
                                                                        <p class="text-muted m-b-0">
                                                                            <?php echo e($student_status_data->headline); ?>

                                                                        </p>
                                                                    </div>
                                                                </div>
                                                            </td>
                                                            <td>
                                                                <?php echo e($student_status_data->user->email); ?>

                                                            </td>
                                                            <td class="text-center">
                                                                <span
                                                                    class="badge 
                                                                    <?php if($student_status_data->student_status == 'pending'): ?> bg-warning text-dark 
                                                                    <?php elseif($student_status_data->student_status == 'active'): ?> bg-success 
                                                                    <?php else: ?> bg-danger <?php endif; ?>">
                                                                    <?php echo e(ucfirst($student_status_data->student_status)); ?>

                                                                </span>
                                                            </td>
                                                            <td>
                                                                <?php if($student_status_data->student_status === 'active'): ?> 
                                                                    <div class="btn-group d-flex justify-content-center" role="group">
                                                                        <form
                                                                            action="<?php echo e($actionRouteDeactive); ?>"
                                                                            method="POST"
                                                                            onsubmit="return confirm('Apakah kamu yakin ingin deactive Instructor ini?');">
                                                                            <?php echo csrf_field(); ?>
                                                                            <?php echo method_field('PATCH'); ?>
                                                                            <button type="submit"
                                                                                class="btn btn-sm btn-danger">Deactive</button>
                                                                        </form>
                                                                    </div>
                                                                <?php elseif($student_status_data->student_status === 'deactive'): ?>
                                                                    <div class="btn-group d-flex justify-content-center" role="group">
                                                                        <form
                                                                            action="<?php echo e($actionRouteReactivate); ?>"
                                                                            method="POST"
                                                                            onsubmit="return confirm('Apakah kamu yakin ingin Re-active Instructor ini?');">
                                                                            <?php echo csrf_field(); ?>
                                                                            <?php echo method_field('PATCH'); ?>
                                                                            <button type="submit"
                                                                                class="btn btn-sm btn-success">Re-active</button>
                                                                        </form>
                                                                    </div>

                                                                <?php else: ?>
                                                                    <span ><p class="text-center">No actions</p></span>
                                                                <?php endif; ?>
                                                            </td>
                                                        </tr>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                                        <tr>
                                                            <td colspan="6" class="text-center">Tidak ada data.
                                                            </td>
                                                        </tr>
                                                    <?php endif; ?>
                                                </tbody>
                                            </table>
                                        </div>
                                        <div class="card-footer">
                                            <?php echo e($students_status_data->links()); ?>

                                        </div>
                                    </div>
                                </div>
                            </div>
                            <!--  project and team member end -->
                        </div>
                    </div>
                    <!-- Page-body end -->
                </div>
                <div id="styleSelector"></div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app-layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/wahaname/public_html/edukasi/resources/views/shared-admin/manajemen-user/manajemen-student/index.blade.php ENDPATH**/ ?>