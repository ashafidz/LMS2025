


<?php if(isset($recommendedCourses) && $recommendedCourses->isNotEmpty()): ?>
<div class="row mt-5">
    <div class="col-12">
        <h3 class="fw-bold mb-3"><?php echo e($title ?? 'Rekomendasi Kursus'); ?></h3>
        
        
        <div class="horizontal-scroll-wrapper">
            <?php $__currentLoopData = $recommendedCourses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                
                <div class="scroll-item">
                    <a href="<?php echo e(route('courses.show', $course->slug)); ?>" class="text-decoration-none text-dark">
                        <div class="card h-100 shadow-sm border-0 rounded-4 course-card">
                            <img src="<?php echo e($course->thumbnail_url ? Storage::url($course->thumbnail_url) : 'https://placehold.co/600x400'); ?>" 
                                 class="card-img-top rounded-top-4" 
                                 style="height: 150px; object-fit: cover;" 
                                 alt="<?php echo e($course->title); ?>">
                            <div class="card-body d-flex flex-column">
                                <span class="badge bg-primary-subtle text-primary-emphasis align-self-start mb-2"><?php echo e($course->category->name); ?></span>
                                <h5 class="card-title fw-bold text-dark flex-grow-1"><?php echo e(Str::limit($course->title, 50)); ?></h5>
                                <p class="card-text text-muted mb-2">Oleh: <?php echo e($course->instructor->name); ?></p>
                            </div>
                            <div class="card-footer bg-white border-0 pt-0">
                                <?php if($course->payment_type === 'money'): ?>
                                    <span class="fw-bold text-dark fs-5">
                                        <?php if($course->price > 0): ?>
                                            Rp<?php echo e(number_format($course->price, 0, ',', '.')); ?>

                                        <?php else: ?>
                                            Gratis
                                        <?php endif; ?>
                                    </span>
                                <?php elseif($course->payment_type === 'diamonds'): ?>
                                    <span class="fw-bold text-info fs-5 d-flex align-items-center">
                                        <i class="fa fa-diamond me-2"></i> <?php echo e(number_format($course->diamond_price, 0, ',', '.')); ?>

                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                    </a>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</div>
<?php endif; ?>


<?php $__env->startPush('styles'); ?>
<style>
    .horizontal-scroll-wrapper {
        display: flex;
        overflow-x: auto;
        padding-bottom: 1rem;
        -webkit-overflow-scrolling: touch; /* Untuk scroll yang mulus di iOS */
    }
    /* Sembunyikan scrollbar */
    .horizontal-scroll-wrapper::-webkit-scrollbar {
        display: none;
    }
    .scroll-item {
        flex: 0 0 280px; /* Lebar setiap kartu */
        margin-right: 1.5rem;
    }
    .course-card {
        transition: transform 0.2s ease-in-out, box-shadow 0.2s ease-in-out;
    }
    .course-card:hover {
        transform: translateY(-5px);
        box-shadow: 0 8px 25px rgba(0,0,0,0.1) !important;
    }
</style>
<?php $__env->stopPush(); ?><?php /**PATH /home/wahaname/public_html/edukasi/resources/views/partials/_recommended_courses.blade.php ENDPATH**/ ?>