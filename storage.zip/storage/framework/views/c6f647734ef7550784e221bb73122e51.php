

<?php $__env->startSection('content'); ?>
<div class="container d-flex justify-content-center align-items-start min-vh-100" style="background: #f0f4ff; padding-top: 195px;">

    <div class="card shadow-sm border-0 rounded-4" style="max-width: 650px; width: 100%;">
        <div class="card-body px-5 py-4 text-center">

            
            <img src="https://ssl.gstatic.com/ui/v1/icons/mail/rfr/logo_gmail_lockup_default_1x_r2.png" alt="Gmail" style="width: 60px;" class="mb-3">

            
            <h4 class="fw-bold mb-3">Verifikasi Email Anda</h4>

            
            <p class="text-muted mb-3">
                Kami telah mengirimkan tautan verifikasi ke email Anda.<br>
                Silakan periksa kotak masuk dan klik tautan tersebut untuk mengaktifkan akun Anda.
            </p>

            
            <?php if(session('status') == 'verification-link-sent'): ?>
                <div class="alert alert-success mb-3" role="alert">
                    Tautan verifikasi baru telah dikirim ke alamat email Anda.
                </div>
            <?php endif; ?>

            
            <form method="POST" action="<?php echo e(route('verification.send')); ?>">
                <?php echo csrf_field(); ?>
                <button type="submit" class="btn btn-primary w-100 fw-semibold py-2" style="font-size: 1rem;">
                    Kirim Ulang Email Verifikasi
                </button>
            </form>

            
            <form method="POST" action="<?php echo e(route('logout')); ?>" class="mt-2">
                <?php echo csrf_field(); ?>
                <button type="submit" class="btn btn-link text-decoration-none text-muted">
                    Log Out
                </button>
            </form>

            
            <p class="text-muted small mt-3 mb-0">
                Belum menerima email? Periksa folder spam atau klik tombol di atas untuk mengirim ulang.
            </p>

        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.home-layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/wahaname/public_html/edukasi/resources/views/auth/verify-email.blade.php ENDPATH**/ ?>