

<div class="modal fade" id="instructorReviewModal-<?php echo e($review->id); ?>" tabindex="-1" role="dialog">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <form action="<?php echo e(route('student.reviews.instructor.update', $review->id)); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>
                <div class="modal-header">
                    <h5 class="modal-title">Edit Ulasan untuk Instruktur: <?php echo e($review->instructor->name); ?></h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <p>Konteks Kursus: <strong><?php echo e($review->course->title); ?></strong></p>
                    
                    <div class="form-group text-center">
                        <label class="d-block mb-2">Rating Keseluruhan</label>
                        <div class="star-rating">
                            <?php for($i = 5; $i >= 1; $i--): ?>
                            <input type="radio" id="ins-star<?php echo e($review->id); ?>-<?php echo e($i); ?>" name="rating" value="<?php echo e($i); ?>" <?php echo e(old('rating', $review->rating) == $i ? 'checked' : ''); ?> required/><label for="ins-star<?php echo e($review->id); ?>-<?php echo e($i); ?>" title="<?php echo e($i); ?> stars">★</label>
                            <?php endfor; ?>
                        </div>
                    </div>

                    <div class="form-group">
                        <label>Ulasan Anda</label>
                        <textarea name="comment" class="form-control" rows="4"><?php echo e(old('comment', $review->comment)); ?></textarea>
                    </div>

                    <?php if($instructorLikertQuestions->isNotEmpty()): ?>
                        <hr>
                        <label class="d-block mb-3">Penilaian Detail Instruktur:</label>
                        <?php $__currentLoopData = $instructorLikertQuestions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="form-group likert-scale">
                            <p class="mb-1"><?php echo e($question->question_text); ?></p>
                            <div class="btn-group d-flex justify-content-between text-center" role="group">
                                <?php $currentAnswer = $userLikertAnswers[$question->id] ?? 0; ?>
                                <div class="w-25 d-flex flex-column justify-content-center">
                                    <input type="radio" class="btn-check" name="likert_answers[<?php echo e($question->id); ?>]" id="il-<?php echo e($review->id); ?>-<?php echo e($question->id); ?>-1" value="1" <?php echo e($currentAnswer == 1 ? 'checked' : ''); ?> required><label class="" for="il-<?php echo e($review->id); ?>-<?php echo e($question->id); ?>-1">Sangat Tidak Setuju</label>
                                </div>
                                <div class="w-25 d-flex flex-column justify-content-center" >
                                    <input type="radio" class="btn-check" name="likert_answers[<?php echo e($question->id); ?>]" id="il-<?php echo e($review->id); ?>-<?php echo e($question->id); ?>-2" value="2" <?php echo e($currentAnswer == 2 ? 'checked' : ''); ?> required><label class="" for="il-<?php echo e($review->id); ?>-<?php echo e($question->id); ?>-2">Tidak Setuju</label>
                                </div>
                                <div class="w-25 d-flex flex-column justify-content-center">
                                    <input type="radio" class="btn-check" name="likert_answers[<?php echo e($question->id); ?>]" id="il-<?php echo e($review->id); ?>-<?php echo e($question->id); ?>-3" value="3" <?php echo e($currentAnswer == 3 ? 'checked' : ''); ?> required><label class="" for="il-<?php echo e($review->id); ?>-<?php echo e($question->id); ?>-3">Setuju</label>
                                </div>
                                <div class="w-25 d-flex flex-column justify-content-center">
                                    <input type="radio" class="btn-check" name="likert_answers[<?php echo e($question->id); ?>]" id="il-<?php echo e($review->id); ?>-<?php echo e($question->id); ?>-4" value="4" <?php echo e($currentAnswer == 4 ? 'checked' : ''); ?> required><label class="" for="il-<?php echo e($review->id); ?>-<?php echo e($question->id); ?>-4">Sangat Setuju</label>
                                </div>
                            </div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Batal</button>
                    <button type="submit" class="btn btn-primary">Simpan Perubahan</button>
                </div>
            </form>
        </div>
    </div>
</div><?php /**PATH /home/wahaname/public_html/edukasi/resources/views/student/my-reviews/partials/_instructor_review_modal.blade.php ENDPATH**/ ?>