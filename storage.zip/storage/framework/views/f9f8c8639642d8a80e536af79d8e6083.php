<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e(config('app.name', 'Laravel')); ?></title>

    

    
    





    
    <!-- Google font-->
    <link href="https://fonts.googleapis.com/css?family=Roboto:400,500" rel="stylesheet" />
    <!-- waves.css -->
    <link rel="stylesheet" href="<?php echo e(asset('pages/waves/css/waves.min.css')); ?>" type="text/css" media="all" />
    <!-- Required Fremwork -->
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/bootstrap/css/bootstrap.min.css')); ?>" />
    <!-- waves.css -->
    <link rel="stylesheet" href="<?php echo e(asset('pages/waves/css/waves.min.css')); ?>" type="text/css" media="all" />
    <!-- themify icon -->
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('icon/themify-icons/themify-icons.css')); ?>" />
            <link
            rel="stylesheet"
            href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css"
        />

        <link
            rel="stylesheet"
            href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css"
        />
    <!-- Font Awesome -->
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('icon/font-awesome/css/font-awesome.min.css')); ?>" />
    <!-- scrollbar.css -->
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/jquery.mCustomScrollbar.css')); ?>" />
    <!-- am chart export.css -->
    <link rel="stylesheet" href="https://www.amcharts.com/lib/3/plugins/export/export.css" type="text/css"
        media="all" />
            <!-- ico font -->
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('icon/icofont/css/icofont.css')); ?>">
    <!-- Style.css -->
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/style.css')); ?>" />
    


            <style>
            .star-rating {
                display: inline-flex;
                gap: 8px;
                font-size: 20px;
            }

            .star-rating i {
                color: #ddd;
                transition: transform 0.2s, color 0.3s;
                cursor: pointer;
            }

            .star-rating i.hovered,
            .star-rating i.selected {
                color: #facc15; /* kuning keemasan */
                transform: scale(1.2);
            }
        </style>
        <?php echo $__env->yieldPushContent('styles'); ?>
</head>

<body>




    <!-- Pre-loader start -->
    <div class="theme-loader">
        <div class="loader-track">
            <div class="preloader-wrapper">
                <div class="spinner-layer spinner-blue">
                    <div class="circle-clipper left">
                        <div class="circle"></div>
                    </div>
                    <div class="gap-patch">
                        <div class="circle"></div>
                    </div>
                    <div class="circle-clipper right">
                        <div class="circle"></div>
                    </div>
                </div>
                <div class="spinner-layer spinner-red">
                    <div class="circle-clipper left">
                        <div class="circle"></div>
                    </div>
                    <div class="gap-patch">
                        <div class="circle"></div>
                    </div>
                    <div class="circle-clipper right">
                        <div class="circle"></div>
                    </div>
                </div>

                <div class="spinner-layer spinner-yellow">
                    <div class="circle-clipper left">
                        <div class="circle"></div>
                    </div>
                    <div class="gap-patch">
                        <div class="circle"></div>
                    </div>
                    <div class="circle-clipper right">
                        <div class="circle"></div>
                    </div>
                </div>

                <div class="spinner-layer spinner-green">
                    <div class="circle-clipper left">
                        <div class="circle"></div>
                    </div>
                    <div class="gap-patch">
                        <div class="circle"></div>
                    </div>
                    <div class="circle-clipper right">
                        <div class="circle"></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Pre-loader end -->
    <div id="pcoded" class="pcoded">
        <div class="pcoded-overlay-box"></div>
        <div class="pcoded-container navbar-wrapper">
          

            <?php if(auth()->guard()->check()): ?> 

                
                <?php
                    $activeRole = session('active_role', 'student'); // Get active role, default to 'student'

                    // Check if the user is an approved instructor who can switch views
                    $canSwitch =
                        Auth::user()->hasRole('instructor') &&
                        Auth::user()->instructorProfile?->application_status === 'approved' &&
                        Auth::user()->hasRole('student');
                ?>

                
                <?php if($activeRole === 'instructor'): ?>
                    <?php echo $__env->make('layouts.navigations.navbars.instructor-navbar', ['canSwitch' => $canSwitch], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                <?php elseif($activeRole === 'student'): ?>
                    <?php echo $__env->make('layouts.navigations.navbars.student-navbar', ['canSwitch' => $canSwitch], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                <?php elseif(Auth::user()->hasRole('admin')): ?>
                    <?php echo $__env->make('layouts.navigations.navbars.admin-navbar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                <?php elseif(Auth::user()->hasRole('superadmin')): ?>
                    <?php echo $__env->make('layouts.navigations.navbars.superadmin-navbar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                <?php endif; ?>
                
                    
                    
            <?php endif; ?>



            <div class="pcoded-main-container">
                <div class="pcoded-wrapper">
                    <?php if(auth()->guard()->check()): ?>
                    <?php if($activeRole === 'instructor'): ?>
                        <?php echo $__env->make('layouts.navigations.sidebars.instructor-sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                    <?php elseif($activeRole === 'student'): ?>
                        <?php echo $__env->make('layouts.navigations.sidebars.student-sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                    <?php elseif(Auth::user()->hasRole('admin')): ?>
                        <?php echo $__env->make('layouts.navigations.sidebars.admin-sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                    <?php elseif(Auth::user()->hasRole('superadmin')): ?>
                        <?php echo $__env->make('layouts.navigations.sidebars.superadmin-sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                    <?php endif; ?>

                    <?php echo $__env->yieldContent('content'); ?>

                    <?php else: ?>
                        <?php echo $__env->yieldContent('content'); ?>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>



















    <!-- Required Jquery -->
    <script type="text/javascript" src="<?php echo e(asset('js/jquery/jquery.min.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('js/jquery-ui/jquery-ui.min.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('js/popper.js/popper.min.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('js/bootstrap/js/bootstrap.min.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('pages/widget/excanvas.js')); ?>"></script>
    <!-- waves js -->
    <script src="<?php echo e(asset('pages/waves/js/waves.min.js')); ?>"></script>
    <!-- jquery slimscroll js -->
    <script type="text/javascript" src="<?php echo e(asset('js/jquery-slimscroll/jquery.slimscroll.js')); ?> "></script>
    <!-- modernizr js -->
    <script type="text/javascript" src="<?php echo e(asset('js/modernizr/modernizr.js')); ?> "></script>
    <!-- slimscroll js -->
    <script type="text/javascript" src="<?php echo e(asset('js/SmoothScroll.js')); ?>"></script>
    <script src="<?php echo e(asset('js/jquery.mCustomScrollbar.concat.min.js')); ?> "></script>
    <!-- Chart js -->
    <script type="text/javascript" src="<?php echo e(asset('js/chart.js/Chart.js')); ?>"></script>
    <!-- amchart js -->
    <script src="https://www.amcharts.com/lib/3/amcharts.js"></script>
    <script src="<?php echo e(asset('pages/widget/amchart/gauge.js')); ?>"></script>
    <script src="<?php echo e(asset('pages/widget/amchart/serial.js')); ?>"></script>
    <script src="<?php echo e(asset('pages/widget/amchart/light.js')); ?>"></script>
    <script src="<?php echo e(asset('pages/widget/amchart/pie.min.js')); ?>"></script>
    <script src="https://www.amcharts.com/lib/3/plugins/export/export.min.js"></script>
    <!-- menu js -->
    <script src="<?php echo e(asset('js/pcoded.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/vertical-layout.min.js')); ?> "></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script type="text/javascript" src="<?php echo e(asset('pages/accordion/accordion.js')); ?>"></script>
    


    <script>
    // Cek jika timezone belum diatur di session storage browser
    if (!sessionStorage.getItem('timezone_set')) {
        const userTimezone = Intl.DateTimeFormat().resolvedOptions().timeZone;

        // Kirim timezone ke server menggunakan Fetch API
        fetch('/set-timezone', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>' // Penting untuk keamanan
            },
            body: JSON.stringify({ timezone: userTimezone })
        }).then(() => {
            // Tandai bahwa timezone sudah diatur agar tidak dikirim berulang kali
            sessionStorage.setItem('timezone_set', 'true');
        });
    }
</script>

    <!-- custom js -->
    <?php echo $__env->yieldPushContent('scripts'); ?>
    
    <script type="text/javascript" src="<?php echo e(asset('js/script.js')); ?>"></script>


</body>

</html>
<?php /**PATH /home/wahaname/public_html/edukasi/resources/views/layouts/app-layout.blade.php ENDPATH**/ ?>