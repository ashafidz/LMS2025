

<?php $__env->startSection('content'); ?>
<div class="pcoded-content">
    <!-- Page-header start -->
    <div class="page-header">
        <div class="page-block">
            <div class="row align-items-center">
                <div class="col-md-8">
                    <div class="page-header-title">
                        <h5 class="m-b-10">Pengumpulan Tugas</h5>
                        <p class="m-b-0">Tugas: <strong><?php echo e($assignment->lesson->title); ?></strong></p>
                    </div>
                </div>
                <div class="col-md-4">
                    <ul class="breadcrumb-title">
                        <li class="breadcrumb-item"><a href="<?php echo e(route('instructor.dashboard')); ?>"><i class="fa fa-home"></i></a></li>
                        <li class="breadcrumb-item"><a href="<?php echo e(route('instructor.modules.lessons.index', $assignment->lesson->module)); ?>">Daftar Pelajaran</a></li>
                        <li class="breadcrumb-item"><a href="#!">Pengumpulan</a></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    <!-- Page-header end -->

    <div class="pcoded-inner-content">
        <div class="main-body">
            <div class="page-wrapper">
                <div class="page-body">
                    <div class="row">
                        <div class="col-sm-12">
                            <div class="card">
                                <div class="card-header">
                                    <h5>Daftar Pengumpulan Siswa</h5>
                                    <span>Berikut adalah daftar semua siswa baik yang telah mengumpulkan tugas ini atau belum.</span>
                                </div>
                                <div class="card-block">
                                    <?php if(session('success')): ?>
                                        <div class="alert alert-success"><?php echo e(session('success')); ?></div>
                                    <?php endif; ?>
                                    
                                    <!-- Nav tabs -->
                                    <ul class="nav nav-tabs md-tabs" role="tablist">
                                        <li class="nav-item">
                                            <a class="nav-link active" data-toggle="tab" href="#submitted" role="tab">Menunggu Dinilai <span class="badge badge-info"><?php echo e($submittedSubmissions->count()); ?></span></a>
                                            <div class="slide"></div>
                                        </li>
                                        <li class="nav-item">
                                            <a class="nav-link" data-toggle="tab" href="#revision" role="tab">Perlu Revisi <span class="badge badge-danger"><?php echo e($revisionSubmissions->count()); ?></span></a>
                                            <div class="slide"></div>
                                        </li>
                                        <li class="nav-item">
                                            <a class="nav-link" data-toggle="tab" href="#passed" role="tab">Lulus <span class="badge badge-success"><?php echo e($passedSubmissions->count()); ?></span></a>
                                            <div class="slide"></div>
                                        </li>
                                        <li class="nav-item">
                                            <a class="nav-link" data-toggle="tab" href="#not-submitted" role="tab">Belum Mengumpulkan <span class="badge badge-default"><?php echo e($notSubmittedStudents->count()); ?></span></a>
                                            <div class="slide"></div>
                                        </li>
                                    </ul>
                                    <!-- Tab panes -->
                                    <div class="tab-content card-block">
                                        
                                        <div class="tab-pane active" id="submitted" role="tabpanel">
                                            <?php echo $__env->make('instructor.assignments.partials._submission_table', ['submissions' => $submittedSubmissions], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                                        </div>
                                        
                                        <div class="tab-pane" id="revision" role="tabpanel">
                                            <?php echo $__env->make('instructor.assignments.partials._submission_table', ['submissions' => $revisionSubmissions], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                                        </div>
                                        
                                        <div class="tab-pane" id="passed" role="tabpanel">
                                            <?php echo $__env->make('instructor.assignments.partials._submission_table', ['submissions' => $passedSubmissions], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                                        </div>
                                        
                                        <div class="tab-pane" id="not-submitted" role="tabpanel">
                                            <div class="table-responsive">
                                                <table class="table table-hover">
                                                    <thead>
                                                        <tr>
                                                            <th class="text-center" >NIM/NIDN/NIP</th>
                                                            <th>Nama Siswa</th>
                                                            <th>Email</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                        <?php $__empty_1 = true; $__currentLoopData = $notSubmittedStudents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                                            <tr>
                                                                <td class="text-center"><?php echo e($student->studentProfile->unique_id_number ? $student->studentProfile->unique_id_number : '-'); ?></td>
                                                                <td><?php echo e($student->name); ?></td>
                                                                <td><?php echo e($student->email); ?></td>
                                                            </tr>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                                            <tr>
                                                                <td colspan="2" class="text-center">Semua siswa sudah mengumpulkan tugas.</td>
                                                            </tr>
                                                        <?php endif; ?>
                                                    </tbody>
                                                </table>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Modal untuk setiap pengumpulan -->
    <?php $__currentLoopData = $submittedSubmissions->concat($revisionSubmissions)->concat($passedSubmissions); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $submission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="modal fade" id="submissionModal-<?php echo e($submission->id); ?>" tabindex="-1" role="dialog">
        <div class="modal-dialog modal-lg" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Detail Pengumpulan: <?php echo e($submission->user->name); ?></h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <div class="row">
                        <div class="col-md-7">
                            <h6 class="font-weight-bold">Pratinjau File</h6>
                            <?php if(Str::endsWith($submission->file_path, '.pdf')): ?>
                                <div class="embed-responsive embed-responsive-4by3" style="border: 1px solid #ddd;">
                                    <embed src="<?php echo e(Storage::url($submission->file_path)); ?>" type="application/pdf" width="100%" height="650px" />
                                </div>
                            <?php else: ?>
                                <div class="text-center p-5 bg-light">
                                    <i class="fa fa-file-zip-o fa-3x"></i>
                                    <p class="mt-2">Pratinjau tidak tersedia untuk file ZIP.</p>
                                </div>
                            <?php endif; ?>
                            <a href="<?php echo e(Storage::url($submission->file_path)); ?>" class="btn btn-secondary btn-block mt-3" download>
                                <i class="fa fa-download"></i> Unduh File Tugas
                            </a>
                        </div>
                        <div class="col-md-5">
                            <h6 class="font-weight-bold">Form Penilaian</h6>
                            <form action="<?php echo e(route('instructor.submission.grade', $submission->id)); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <div class="form-group">
                                    <label for="grade-<?php echo e($submission->id); ?>">Nilai (0-100)</label>
                                    <input type="number" name="grade" id="grade-<?php echo e($submission->id); ?>" class="form-control" value="<?php echo e(old('grade', $submission->grade)); ?>" min="0" max="100" required>
                                </div>
                                <div class="form-group">
                                    <label for="feedback-<?php echo e($submission->id); ?>">Umpan Balik (Feedback)</label>
                                    <textarea name="feedback" id="feedback-<?php echo e($submission->id); ?>" class="form-control" rows="8" placeholder="Berikan umpan balik untuk siswa..."><?php echo e(old('feedback', $submission->feedback)); ?></textarea>
                                </div>
                                <button type="submit" class="btn btn-primary btn-block">Simpan Penilaian</button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app-layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/wahaname/public_html/edukasi/resources/views/instructor/assignments/submissions.blade.php ENDPATH**/ ?>