
<h4 class="font-weight-bold">Papan Peringkat: <?php echo e($module->title); ?></h4>
<p class="text-muted">Lihat peringkat Anda berdasarkan total poin yang diperoleh di modul ini.</p>
<hr>

<div class="table-responsive">
    <table class="table table-hover">
        <thead>
            <tr>
                <th style="width: 10%;">Peringkat</th>
                <th>Nama Siswa</th>
                <th class="text-right">Total Poin</th>
            </tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $leaderboardRanks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $rank): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <?php if($rank->user): ?> 
                    
                    <tr class="
                        <?php if($index + 1 <= 3): ?>
                            table-success
                        <?php elseif($index + 1 <= 20): ?>
                            table-info
                        <?php else: ?>
                            table-light
                        <?php endif; ?>
                    ">
                        <td class="font-weight-bold">#<?php echo e($index + 1); ?></td>
                        <td>
                            <?php echo e($rank->user->name); ?>

                            
                            <?php if($rank->user_id === Auth::id()): ?>
                                <span class="badge badge-primary">Anda</span>
                            <?php endif; ?>
                        </td>
                        <td class="text-right font-weight-bold"><?php echo e(number_format($rank->total_points, 0, ',', '.')); ?></td>
                    </tr>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="3" class="text-center text-muted">Belum ada poin yang tercatat di modul ini.</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>
</div><?php /**PATH /home/wahaname/public_html/edukasi/resources/views/student/courses/partials/_module-leaderboard.blade.php ENDPATH**/ ?>