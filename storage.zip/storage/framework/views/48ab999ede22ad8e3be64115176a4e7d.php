<?php $__env->startSection('content'); ?>
<div class="pcoded-content">
    <!-- Page-header start -->
    <div class="page-header">
        <div class="page-block">
            <div class="row align-items-center">
                <div class="col-md-8">
                    <div class="page-header-title">
                        <h5 class="m-b-10">Edit Topik Soal</h5>
                        <p class="m-b-0">Perbarui detail untuk topik: <?php echo e($topic->name); ?></p>
                    </div>
                </div>
                <div class="col-md-4">
                    <ul class="breadcrumb-title">
                        <li class="breadcrumb-item"><a href="<?php echo e(route('instructor.dashboard')); ?>"><i class="fa fa-home"></i></a></li>
                        <li class="breadcrumb-item"><a href="<?php echo e(route('instructor.question-bank.topics.index')); ?>">Bank  Soal</a></li>
                        <li class="breadcrumb-item"><a href="#!">Edit Topik</a></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    <!-- Page-header end -->

    <div class="pcoded-inner-content">
        <div class="main-body"><div class="page-wrapper"><div class="page-body"><div class="row">
            <div class="col-sm-12">
                <div class="card">
                    <div class="card-header"><h5>Detail Topik</h5></div>
                    <div class="card-block">
                        <form action="<?php echo e(route('instructor.question-bank.topics.update', $topic->id)); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('PUT'); ?>
                            <div class="form-group row">
                                <label class="col-sm-2 col-form-label">Nama Topik</label>
                                <div class="col-sm-10">
                                    <input type="text" name="name" class="form-control" value="<?php echo e(old('name', $topic->name)); ?>" required>
                                </div>
                            </div>
                            <div class="form-group row">
                                <label class="col-sm-2 col-form-label">Deskripsi (Opsional)</label>
                                <div class="col-sm-10">
                                    <textarea name="description" class="form-control" rows="3"><?php echo e(old('description', $topic->description)); ?></textarea>
                                </div>
                            </div>

                            <hr>
                            <h6 class="font-weight-bold mt-4">Ketersediaan Topik</h6>
                            <div class="form-group row">
                                <label class="col-sm-2 col-form-label">Opsi Ketersediaan</label>
                                <div class="col-sm-10">
                                    <div class="form-check">
                                        <input class="form-check-input" type="checkbox" name="available_for_all_courses" value="1" id="all-courses-checkbox" <?php echo e(old('available_for_all_courses', $topic->available_for_all_courses) ? 'checked' : ''); ?>>
                                        <label class="form-check-label" for="all-courses-checkbox">
                                            Tersedia untuk semua kursus saya.
                                        </label>
                                    </div>
                                </div>
                            </div>
                            <div class="form-group row" id="course-list-container">
                                <label class="col-sm-2 col-form-label">Pilih Kursus Spesifik</label>
                                <div class="col-sm-10">
                                    
                                        <div class="form-check mb-2">
                                            <input class="form-check-input" type="checkbox" id="select-all-courses">
                                            <label class="form-check-label font-weight-bold" for="select-all-courses">Pilih Semua Kursus</label>
                                        </div>

                                        <?php $linkedCourseIds = $topic->courses->pluck('id')->toArray(); ?>
                                        <?php $__empty_1 = true; $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                            <div class="form-check">
                                                <input class="form-check-input course-checkbox" type="checkbox" name="course_ids[]" value="<?php echo e($course->id); ?>" id="course-<?php echo e($course->id); ?>" <?php echo e(in_array($course->id, old('course_ids', $linkedCourseIds)) ? 'checked' : ''); ?>>
                                                <label class="form-check-label" for="course-<?php echo e($course->id); ?>"><?php echo e($course->title); ?></label>
                                            </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                            <p class="text-muted">Anda belum memiliki kursus.</p>
                                        <?php endif; ?>
                                    
                                </div>
                            </div>

                            <div class="form-group row">
                                <div class="col-sm-12 text-right">
                                    <a href="<?php echo e(route('instructor.question-bank.topics.index')); ?>" class="btn btn-secondary">Batal</a>
                                    <button type="submit" class="btn btn-primary">Simpan Perubahan</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div></div></div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
document.addEventListener('DOMContentLoaded', function() {
    const allCoursesCheckbox = document.getElementById('all-courses-checkbox');
    const courseListContainer = document.getElementById('course-list-container');
    const selectAllCourses = document.getElementById('select-all-courses');
    const courseCheckboxes = document.querySelectorAll('.course-checkbox');

    function toggleCourseList() {
        courseListContainer.style.display = allCoursesCheckbox.checked ? 'none' : 'flex';
    }

    allCoursesCheckbox.addEventListener('change', toggleCourseList);

    selectAllCourses.addEventListener('change', function() {
        courseCheckboxes.forEach(checkbox => {
            checkbox.checked = this.checked;
        });
    });
    
    toggleCourseList();
});
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app-layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/wahaname/public_html/edukasi/resources/views/instructor/question_bank/topics/edit.blade.php ENDPATH**/ ?>