

<h4 class="font-weight-bold"><?php echo e($title); ?></h4>
<p class="text-muted">Menampilkan peringkat teratas berdasarkan total poin yang diperoleh.</p>
<hr>
<div class="table-responsive">
    <table class="table table-hover">
        <thead>
            <tr>
                <th style="width: 10%;">Peringkat</th>
                <th class="text-center" >NIM/NIDN/NIP</th>
                <th>Nama Siswa</th>
                <th class="text-right">Total Poin</th>
            </tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $leaderboardRanks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $rank): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <?php if($rank->user): ?> 
                    
                    <tr class="
                        <?php if($index + 1 <= 5): ?>
                            table-success
                        <?php elseif($index + 1 <= 20): ?>
                            table-info
                        <?php else: ?>
                            table-danger
                        <?php endif; ?>
                    ">
                        <td class="font-weight-bold">#<?php echo e($index + 1); ?></td>
                        <td class="text-center" ><?php echo e($rank->user->studentProfile->unique_id_number ? $rank->user->studentProfile->unique_id_number : '-'); ?></td>
                        <td><?php echo e($rank->user->name); ?></td>
                        
                        <td class="text-right font-weight-bold"><?php echo e(number_format($rank->points_earned ?? $rank->total_points, 0, ',', '.')); ?> <span><i class="bi bi-star-fill text-warning"></i></span></td>
                    </tr>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="3" class="text-center text-muted">Belum ada poin yang tercatat.</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>
</div><?php /**PATH /home/wahaname/public_html/edukasi/resources/views/instructor/leaderboards/_modal_content.blade.php ENDPATH**/ ?>