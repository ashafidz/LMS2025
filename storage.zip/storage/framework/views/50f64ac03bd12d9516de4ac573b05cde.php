<?php $__env->startSection('content'); ?>
<div class="pcoded-content">
    <!-- Page-header start -->
    <div class="page-header">
        <div class="page-block">
            <div class="row align-items-center">
                <div class="col-md-8">
                    <div class="page-header-title">
                        <h5 class="m-b-10">Buat Pertanyaan Ulasan Baru</h5>
                        <p class="m-b-0">Isi detail untuk pertanyaan skala Likert.</p>
                    </div>
                </div>
                <div class="col-md-4">
                    <ul class="breadcrumb-title">
                        <li class="breadcrumb-item"><a href="<?php echo e(route(Auth::user()->getRoleNames()->first() . '.dashboard')); ?>"><i class="fa fa-home"></i></a></li>
                        <li class="breadcrumb-item"><a href="<?php echo e(route(Auth::user()->getRoleNames()->first() . '.likert-questions.index')); ?>">Pertanyaan Ulasan</a></li>
                        <li class="breadcrumb-item"><a href="#!">Buat</a></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    <!-- Page-header end -->

    <div class="pcoded-inner-content">
        <div class="main-body">
            <div class="page-wrapper">
                <div class="page-body">
                    <div class="row">
                        <div class="col-sm-12">
                            <div class="card">
                                <div class="card-header">
                                    <h5>Detail Pertanyaan</h5>
                                </div>
                                <div class="card-block">
                                    <?php if($errors->any()): ?>
                                        <div class="alert alert-danger">
                                            <ul>
                                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <li><?php echo e($error); ?></li>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </ul>
                                        </div>
                                    <?php endif; ?>

                                    <form action="<?php echo e(route(Auth::user()->getRoleNames()->first() . '.likert-questions.store')); ?>" method="POST">
                                        <?php echo csrf_field(); ?>
                                        <div class="form-group row">
                                            <label class="col-sm-2 col-form-label">Teks Pertanyaan</label>
                                            <div class="col-sm-10">
                                                <textarea name="question_text" class="form-control" rows="4" required placeholder="Contoh: Materi kursus mudah dipahami."><?php echo e(old('question_text')); ?></textarea>
                                            </div>
                                        </div>

                                        <div class="form-group row">
                                            <label class="col-sm-2 col-form-label">Kategori Pertanyaan</label>
                                            <div class="col-sm-10">
                                                <select name="category" class="form-control" required>
                                                    <option value="">-- Pilih Kategori --</option>
                                                    <option value="course" <?php echo e(old('category') == 'course' ? 'selected' : ''); ?>>Untuk Menilai Kursus</option>
                                                    <option value="instructor" <?php echo e(old('category') == 'instructor' ? 'selected' : ''); ?>>Untuk Menilai Instruktur</option>
                                                    <option value="platform" <?php echo e(old('category') == 'platform' ? 'selected' : ''); ?>>Untuk Menilai Platform</option>
                                                </select>
                                            </div>
                                        </div>

                                        <div class="form-group row">
                                            <label class="col-sm-2 col-form-label">Status</label>
                                            <div class="col-sm-10">
                                                <div class="form-radio">
                                                    <div class="radio radio-inline">
                                                        <label><input type="radio" name="is_active" value="1" <?php echo e(old('is_active', '1') == '1' ? 'checked' : ''); ?>><i class="helper"></i>Aktif</label>
                                                    </div>
                                                    <div class="radio radio-inline">
                                                        <label><input type="radio" name="is_active" value="0" <?php echo e(old('is_active') == '0' ? 'checked' : ''); ?>><i class="helper"></i>Tidak Aktif</label>
                                                    </div>
                                                </div>
                                                <small class="form-text text-muted">Hanya pertanyaan yang aktif yang akan ditampilkan kepada siswa.</small>
                                            </div>
                                        </div>

                                        <div class="form-group row">
                                            <div class="col-sm-12 text-right">
                                                <a href="<?php echo e(route(Auth::user()->getRoleNames()->first() . '.likert-questions.index')); ?>" class="btn btn-secondary">Batal</a>
                                                <button type="submit" class="btn btn-primary">Simpan Pertanyaan</button>
                                            </div>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app-layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/wahaname/public_html/edukasi/resources/views/shared-admin/likert-questions/create.blade.php ENDPATH**/ ?>