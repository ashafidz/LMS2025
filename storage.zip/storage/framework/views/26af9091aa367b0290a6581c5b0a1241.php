<?php $__env->startSection('content'); ?>
<div class="pcoded-content">
    <!-- Page-header start -->
    <div class="page-header">
        <div class="page-block">
            <div class="row align-items-center">
                <div class="col-md-8">
                    <div class="page-header-title">
                        <h5 class="m-b-10">Hasil Kuis</h5>
                        <p class="m-b-0">Judul Kuis: <strong><?php echo e($quiz->title); ?></strong></p>
                    </div>
                </div>
                <div class="col-md-4">
                    <ul class="breadcrumb-title">
                        <li class="breadcrumb-item"><a href="#!"><i class="fa fa-home"></i> </a></li>
                        <li class="breadcrumb-item"><a href="#!">Kursus Saya</a></li>
                        <li class="breadcrumb-item"><a href="#!">Modul Saya</a></li>
                        <li class="breadcrumb-item"><a href="<?php echo e(route('instructor.modules.lessons.index', $quiz->lesson->module)); ?>">Daftar Pelajaran</a></li>
                        <li class="breadcrumb-item"><a href="#!">Hasil Kuis</a></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    <!-- Page-header end -->

    <div class="pcoded-inner-content">
        <div class="main-body">
            <div class="page-wrapper">
                <div class="page-body">
                    <div class="row">
                        <div class="col-sm-12">
                            <div class="card">
                                <div class="card-header">
                                    <h5>Riwayat Pengerjaan Siswa</h5>
                                    <span>Tabel ini menampilkan status pengerjaan kuis untuk semua siswa yang terdaftar di kursus ini.</span>
                                </div>
                                <div class="card-block table-border-style">
                                    <div class="table-responsive">
                                        <table class="table table-hover">
                                            <thead>
                                                <tr>
                                                    <th class="text-center">NIM/NIP/NIDN</th>
                                                    <th>Nama Siswa</th>
                                                    <th>Status Pengerjaan</th>
                                                    <th class="text-center">Aksi</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php $__empty_1 = true; $__currentLoopData = $enrolledStudents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                                    <tr>
                                                        <td class="text-center"><?php echo e($student->studentProfile->unique_id_number ? $student->studentProfile->unique_id_number : '-'); ?></td>
                                                        <td><?php echo e($student->name); ?></td>
                                                        <td>
                                                            <?php
                                                                $statusClass = '';
                                                                if ($student->quiz_status === 'Lulus') $statusClass = 'label-success';
                                                                elseif ($student->quiz_status === 'Gagal') $statusClass = 'label-danger';
                                                                else $statusClass = 'label-default';
                                                            ?>
                                                            <label class="label <?php echo e($statusClass); ?>"><?php echo e($student->quiz_status); ?></label>
                                                        </td>
                                                        <td class="text-center">
                                                            <?php if($student->attempts->isNotEmpty()): ?>
                                                                <button type="button" class="btn btn-primary btn-sm" data-toggle="modal" data-target="#historyModal-<?php echo e($student->id); ?>">
                                                                    Lihat Riwayat
                                                                </button>
                                                            <?php else: ?>
                                                                <button class="btn btn-secondary btn-sm" disabled>Lihat Riwayat</button>
                                                            <?php endif; ?>
                                                        </td>
                                                    </tr>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                                    <tr>
                                                        <td colspan="3" class="text-center">Belum ada siswa yang terdaftar di kursus ini.</td>
                                                    </tr>
                                                <?php endif; ?>
                                            </tbody>
                                        </table>
                                    </div>
                                    <div class="d-flex justify-content-center">
                                        <?php echo e($enrolledStudents->links()); ?>

                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Modal Riwayat Pengerjaan untuk setiap siswa -->
    <?php $__currentLoopData = $enrolledStudents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if($student->attempts->isNotEmpty()): ?>
        <div class="modal fade" id="historyModal-<?php echo e($student->id); ?>" tabindex="-1" role="dialog">
            <div class="modal-dialog modal-lg" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title">Riwayat Pengerjaan: <?php echo e($student->name); ?></h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <div class="table-responsive">
                            <table class="table table-sm">
                                <thead>
                                    <tr>
                                        <th>Waktu Selesai</th>
                                        <th>Skor</th>
                                        <th>Status</th>
                                        <th class="text-center">Aksi</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $student->attempts->sortByDesc('created_at'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $attempt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($attempt->end_time ? $attempt->end_time->format('d M Y, H:i') : 'Dalam Pengerjaan'); ?></td>
                                        <td><strong><?php echo e(rtrim(rtrim(number_format($attempt->score, 2, ',', '.'), '0'), ',')); ?></strong></td>
                                        <td>
                                            <?php if($attempt->status == 'passed'): ?>
                                                <label class="label label-success">Lulus</label>
                                            <?php else: ?>
                                                <label class="label label-danger">Gagal</label>
                                            <?php endif; ?>
                                        </td>
                                        <td class="text-center">
                                            <a href="<?php echo e(route('instructor.quiz.review_attempt', $attempt->id)); ?>" class="btn btn-inverse btn-sm">Periksa Jawaban</a>
                                        </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Tutup</button>
                    </div>
                </div>
            </div>
        </div>
        <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app-layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/wahaname/public_html/edukasi/resources/views/instructor/quizzes/results/index.blade.php ENDPATH**/ ?>