<?php $__env->startSection('content'); ?>
    <div class="pcoded-content">
        <div class="page-header">
            <div class="page-block">
                <div class="row align-items-center">
                    <div class="col-md-12">
                        <div class="page-header-title">
                            <h5 class="m-b-10">Buat Pelajaran Baru</h5>
                            <p class="m-b-0">Tipe: Kuis</p>
                        </div>
                    </div>
                    <div class="col-md-12 d-flex mt-3">
                        <ul class="breadcrumb-title">
                            <li class="breadcrumb-item"><a href="<?php echo e(route('instructor.dashboard')); ?>"><i class="fa fa-home"></i></a></li>
                            <li class="breadcrumb-item"><a href="#!">Kursus Saya</a></li>
                            <li class="breadcrumb-item"><a href="<?php echo e(route('instructor.courses.modules.index', $module->course)); ?>">Modul</a></li>
                            <li class="breadcrumb-item"><a href="<?php echo e(route('instructor.modules.lessons.index', $module)); ?>"><?php echo e(Str::limit($module->title, 20)); ?></a>
                            </li>
                            <li class="breadcrumb-item"><a href="#!">Buat Kuis</a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
        <div class="pcoded-inner-content">
            <div class="main-body">
                <div class="page-wrapper">
                    <div class="page-body">
                        <div class="row">
                            <div class="col-sm-12">
                                <div class="card">
                                    <div class="card-header">
                                        <h5>Detail Pelajaran Kuis</h5>
                                        <span>Isi detail untuk pelajaran baru Anda. Setelah kuis dibuat, Anda dapat
                                            menambahkan soal.</span>
                                    </div>
                                    <div class="card-block">
                                        <form action="<?php echo e(route('instructor.modules.lessons.store', $module)); ?>"
                                            method="POST">
                                            <?php echo csrf_field(); ?>
                                            <input type="hidden" name="lesson_type" value="quiz">

                                            

                                            <input 
                                                type="hidden" 
                                                name="title" 
                                                id="lesson_title_input"  
                                                value="<?php echo e(old('title') ?? old('quiz_title')); ?>" 
                                                required
                                            >

                                            <h6 class="font-weight-bold mt-4">Informasi Spesifik Kuis</h6>
                                            <div class="form-group row">
                                                <label class="col-sm-3 col-form-label">Judul Kuis</label>
                                                <div class="col-sm-9">
                                                    <input 
                                                        type="text" 
                                                        name="quiz_title" 
                                                        id="quiz_title_input" 
                                                        class="form-control"
                                                        value="<?php echo e(old('quiz_title')); ?>" 
                                                        required
                                                        placeholder="Contoh: Ujian Pemahaman Dasar PHP"
                                                    >
                                                </div>
                                            </div>
                                            <div class="form-group row">
                                                <label class="col-sm-3 col-form-label">Deskripsi Kuis (Opsional)</label>
                                                <div class="col-sm-9">
                                                    <textarea rows="3" name="quiz_description" class="form-control"
                                                        placeholder="Jelaskan instruksi atau topik yang dicakup dalam kuis ini..."><?php echo e(old('quiz_description')); ?></textarea>
                                                </div>
                                            </div>
                                            <div class="form-group row">
                                                <label class="col-sm-3 col-form-label">Nilai Kelulusan (%)</label>
                                                <div class="col-sm-9">
                                                    <input type="number" name="pass_mark" class="form-control"
                                                        value="<?php echo e(old('pass_mark', 75)); ?>" required min="0"
                                                        max="100">
                                                </div>
                                            </div>
                                            <div class="form-group row">
                                                <label class="col-sm-3 col-form-label">Batas Waktu (Menit)</label>
                                                <div class="col-sm-9">
                                                    <input type="number" name="time_limit" class="form-control"
                                                        value="<?php echo e(old('time_limit')); ?>" min="1"
                                                        placeholder="Kosongkan jika tidak ada batas waktu">
                                                </div>
                                            </div>

                                            
                                            <div class="form-group row">
                                                <label class="col-sm-3 col-form-label">Opsi Batas Waktu</label>
                                                <div class="col-sm-9">
                                                    <div class="form-check form-switch">
                                                        <input type="hidden" name="allow_exceed_time_limit" value="0">
                                                        <input class="form-check-input" type="checkbox"
                                                            name="allow_exceed_time_limit" value="1"
                                                            id="allowExceedTime"
                                                            <?php echo e(old('allow_exceed_time_limit') ? 'checked' : ''); ?>>
                                                        <label class="form-check-label" for="allowExceedTime">Izinkan siswa
                                                            tetap mengirim jawaban setelah waktu habis (tidak akan mendapat
                                                            poin).</label>
                                                    </div>
                                                </div>
                                            </div>

                                            
                                            <div class="form-group row">
                                                <label class="col-sm-3 col-form-label">Opsi Hasil Kuis</label>
                                                <div class="col-sm-9">
                                                    <div class="form-check form-switch">
                                                        <input type="hidden" name="reveal_answers" value="0">
                                                        <input class="form-check-input" type="checkbox"
                                                            name="reveal_answers" value="1" id="revealAnswers"
                                                            checked>
                                                        <label class="form-check-label" for="revealAnswers">Tampilkan
                                                            rincian jawaban (benar/salah) kepada siswa di halaman
                                                            hasil.</label>
                                                    </div>
                                                </div>
                                            </div>


                                            
                                            <div class="form-group row">
                                                <label class="col-sm-3 col-form-label">Batas Pengerjaan</label>
                                                <div class="col-sm-9">
                                                    <div class="form-radio">
                                                        <div class="radio radio-inline">
                                                            <label>
                                                                <input type="radio" name="attempt_limit_type"
                                                                    value="unlimited" checked
                                                                    onchange="toggleMaxAttempts(this.value)">
                                                                <i class="helper"></i>Tanpa Batas
                                                            </label>
                                                        </div>
                                                        <div class="radio radio-inline">
                                                            <label>
                                                                <input type="radio" name="attempt_limit_type"
                                                                    value="limited"
                                                                    onchange="toggleMaxAttempts(this.value)">
                                                                <i class="helper"></i>Dibatasi
                                                            </label>
                                                        </div>
                                                    </div>
                                                    <div id="max-attempts-container" style="display: none;"
                                                        class="mt-2">
                                                        <input type="number" name="max_attempts" class="form-control"
                                                            placeholder="Masukkan jumlah percobaan, misal: 3"
                                                            min="1">
                                                    </div>
                                                </div>
                                            </div>

                                            <div class="form-group row">
                                                <label class="col-sm-3 col-form-label">Jadwal Ketersediaan
                                                    (Opsional)</label>
                                                <div class="col-sm-9">
                                                    <div class="row">
                                                        <div class="col-md-6">
                                                            <label>Mulai Tersedia Pada</label>
                                                            <input type="datetime-local" name="available_from"
                                                                class="form-control" value="<?php echo e(old('available_from')); ?>">
                                                        </div>
                                                        <div class="col-md-6">
                                                            <label>Tersedia Hingga</label>
                                                            <input type="datetime-local" name="available_to"
                                                                class="form-control" value="<?php echo e(old('available_to')); ?>">
                                                        </div>
                                                    </div>
                                                    <small class="form-text text-muted">Kosongkan jika kuis bisa dikerjakan
                                                        kapan saja.</small>
                                                </div>
                                            </div>

                                            <div class="form-group row mt-4">
                                                <div class="col-sm-12 text-right">
                                                    <a href="<?php echo e(route('instructor.modules.lessons.index', $module)); ?>"
                                                        class="btn btn-secondary">Batal</a>
                                                    <button type="submit" class="btn btn-primary">Simpan &
                                                        Lanjutkan</button>
                                                </div>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php $__env->startPush('scripts'); ?>
    <script>
        function toggleMaxAttempts(value) {
            const container = document.getElementById('max-attempts-container');
            const input = container.querySelector('input');
            if (value === 'limited') {
                container.style.display = 'block';
                input.required = true;
            } else {
                container.style.display = 'none';
                input.required = false;
                input.value = ''; // Kosongkan nilainya
            }
        }
    </script>



<script>
    // Ambil kedua elemen input berdasarkan id-nya
    const quizTitleInput = document.getElementById('quiz_title_input');
    const lessonTitleInput = document.getElementById('lesson_title_input');

    // Fungsi untuk menyamakan nilainya
    function syncTitles() {
        lessonTitleInput.value = quizTitleInput.value;
    }

    // 1. Langsung samakan nilainya saat halaman pertama kali dimuat
    //    (untuk menangani jika ada data 'old()' setelah validasi gagal)
    syncTitles();

    // 2. Tambahkan event listener 'input' pada 'quiz_title'
    //    agar nilainya selalu update secara real-time setiap kali ada ketikan
    quizTitleInput.addEventListener('input', syncTitles);
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app-layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/wahaname/public_html/edukasi/resources/views/instructor/lessons/create-quiz.blade.php ENDPATH**/ ?>