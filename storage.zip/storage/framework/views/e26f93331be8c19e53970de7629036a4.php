<?php $__env->startSection('content'); ?>
<div class="pcoded-content">
    <!-- Page-header start -->
    <div class="page-header">
        <div class="page-block">
            <div class="row align-items-center">
                <div class="col-md-8">
                    <div class="page-header-title">
                        <h5 class="m-b-10">Hasil Kuis: <?php echo e($attempt->quiz->title); ?></h5>
                        <p class="m-b-0">Kursus: <?php echo e($attempt->quiz->lesson->module->course->title); ?></p>
                    </div>
                </div>
                <div class="col-md-4">
                    <ul class="breadcrumb-title">
                        <li class="breadcrumb-item"><a href="#"><i class="fa fa-home"></i></a></li>
                        <li class="breadcrumb-item"><a href="<?php echo e(route('student.courses.show', $attempt->quiz->lesson->module->course->slug)); ?>">Kursus</a></li>
                        <li class="breadcrumb-item"><a href="#!">Hasil Kuis</a></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    <!-- Page-header end -->

    <div class="pcoded-inner-content">
        <div class="main-body">
            <div class="page-wrapper">
                <div class="page-body">
                    <div class="row d-flex justify-content-center">
                        <div class="col-md-10 col-lg-8">
                            <!-- Kartu Hasil Ringkas -->
                            <div class="card">
                                <div class="card-body text-center">
                                    <?php if($is_preview): ?>
                                        <h2 class="text-warning">Hasil Preview Quiz</h2>
                                    <?php endif; ?>
                                    <?php if($attempt->status == 'passed'): ?>
                                        <h2 class="text-success">Selamat, Anda Lulus!</h2>
                                        <i class="fa fa-check-circle fa-4x text-success mb-3"></i>
                                    <?php else: ?>
                                        <h2 class="text-danger">Sayang sekali, Anda Gagal.</h2>
                                        <i class="fa fa-times-circle fa-4x text-danger mb-3"></i>
                                    <?php endif; ?>

                                    <h4>Skor Anda: <strong><?php echo e(rtrim(rtrim(number_format($attempt->score, 2, ',', '.'), '0'), ',')); ?></strong></h4>
                                    <p class="text-muted">Nilai Kelulusan Minimum: <?php echo e($attempt->quiz->pass_mark); ?>%</p>
                                    <p class="text-muted" >Nilai Maksimum : <?php echo e($maxPossibleScore); ?></p>
                                    <p class="text-muted" >Nilai minimum : <?php echo e($minimumScore); ?></p>
                                    <hr>
                                    <?php if($is_preview): ?>
                                        <a href="<?php echo e(route('student.courses.show', ['course' => $attempt->quiz->lesson->module->course->slug, 'preview' => 'true'])); ?>" class="btn btn-primary">Kembali ke Preview Kursus</a>
                                    <?php else: ?>
                                        <a href="<?php echo e(route('student.courses.show', $attempt->quiz->lesson->module->course->slug)); ?>" class="btn btn-primary">Kembali ke Kursus</a>
                                    <?php endif; ?>

                                </div>
                            </div>

                            <?php if($attempt->quiz->reveal_answers): ?>
                                                            <!-- Rincian Jawaban -->
                            <div class="card">
                                <div class="card-header">
                                    <h5>Rincian Jawaban</h5>
                                </div>
                                <div class="card-block">
                                    <?php $__currentLoopData = $attempt->quiz->questions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="mb-5">
                                            <h6>Soal <?php echo e($index + 1); ?>:</h6>
                                            <p class="lead"><?php echo nl2br(e(str_replace(preg_match_all('/(\[\[BLANK_\d+\]\])/', $question->question_text, $matches) ? $matches[0] : [], '___', $question->question_text))); ?></p>

                                            <?php
                                                $studentAnswersForThisQuestion = $attempt->answers->where('question_id', $question->id);
                                                $studentAnswerIds = $studentAnswersForThisQuestion->pluck('selected_option_id')->toArray();
                                                $isQuestionCorrect = $studentAnswersForThisQuestion->isNotEmpty() && $studentAnswersForThisQuestion->first()->is_correct;
                                            ?>

                                            <div class="options-review">
                                                <?php $__currentLoopData = $question->options; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <?php
                                                        $isStudentAnswer = in_array($option->id, $studentAnswerIds);
                                                        // LOGIKA DISEMPURNAKAN: Sekarang kita bisa percaya pada $option->is_correct
                                                        $isCorrectAnswer = $option->is_correct;
                                                        $labelClass = '';

                                                        if ($isStudentAnswer && $isCorrectAnswer) {
                                                            $labelClass = 'bg-success text-white'; // Jawaban siswa, dan itu benar
                                                        } elseif ($isStudentAnswer && !$isCorrectAnswer) {
                                                            $labelClass = 'bg-danger text-white'; // Jawaban siswa, tapi salah
                                                        } elseif (!$isStudentAnswer && $isCorrectAnswer) {
                                                            $labelClass = 'bg-info text-white'; // Bukan jawaban siswa, tapi ini kunci jawaban
                                                        }
                                                    ?>
                                                    <div class="p-2 rounded mb-2 <?php echo e($labelClass); ?>">
                                                        <?php if($isStudentAnswer && $isCorrectAnswer): ?>
                                                            <i class="fa fa-check-circle-o mr-2"></i> <strong>Jawaban Anda (Benar)</strong>
                                                        <?php elseif($isStudentAnswer && !$isCorrectAnswer): ?>
                                                            <i class="fa fa-times-circle-o mr-2"></i> <strong>Jawaban Anda (Salah)</strong>
                                                        <?php elseif(!$isStudentAnswer && $isCorrectAnswer): ?>
                                                            <i class="fa fa-check mr-2"></i> <strong>Kunci Jawaban</strong>
                                                        <?php else: ?>
                                                            <i class="fa fa-circle-o mr-2" style="opacity: 0.5;"></i>
                                                        <?php endif; ?>
                                                        <?php echo e($option->option_text); ?>

                                                    </div>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </div>

                                            <?php if($isQuestionCorrect && $question->explanation): ?>
                                                <div class="alert alert-success mt-3">
                                                    <strong><i class="fa fa-lightbulb-o"></i> Penjelasan:</strong><br>
                                                    <?php echo nl2br(e($question->explanation)); ?>

                                                </div>
                                            <?php endif; ?>
                                        </div>
                                        <?php if(!$loop->last): ?>
                                            <hr>
                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            </div>
                            <?php else: ?>
                                <div class="alert alert-info">
                                    Jawaban Anda telah disembunyikan oleh penyelenggara kursus ini.
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app-layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/wahaname/public_html/edukasi/resources/views/student/quizzes/result.blade.php ENDPATH**/ ?>