

<hr class="my-5">
<div class="discussion-container">
    <h4 class="font-weight-bold mb-4">Diskusi Pelajaran</h4>

    
    <?php if(!$is_preview): ?>
        <div class="card mb-4">
            <div class="card-body">
                <form action="<?php echo e(route('student.lessons.discussions.store', $lesson->id)); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="form-group">
                        <textarea name="content" class="form-control" rows="3" placeholder="Tulis komentar atau pertanyaan Anda di sini..."
                            required></textarea>
                    </div>
                    <button type="submit" class="btn btn-primary">Kirim Komentar</button>
                </form>
            </div>
        </div>
    <?php endif; ?>

    
    <?php $__empty_1 = true; $__currentLoopData = $discussions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $discussion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <div class="media mb-4">
            <img class="d-flex mr-3 rounded-circle"
                src="<?php echo e($discussion->user->profile_picture_url ? asset('storage/' . ltrim($discussion->user->profile_picture_url, '/')) : 'https://placehold.co/50x50'); ?>"
                alt="User Avatar" style="width: 50px; height: 50px;">
            <div class="media-body">
                <div class="mt-0 d-flex align-items-center gap-2">
                    <h5 class="d-flex align-items-center mr-1">
                        <?php echo e($discussion->user->name); ?>

                        <?php if($discussion->user->equippedBadge): ?>
                            <span class="badge badge-primary mx-1">
                                <?php echo e($discussion->user->equippedBadge->title); ?>

                            </span>
                        <?php endif; ?>
                    </h5>
                    <small class="text-muted mx-1">- <?php echo e($discussion->created_at->diffForHumans()); ?></small>
                </div>

                <?php echo nl2br(e($discussion->content)); ?>


                
                <?php if(!$is_preview && !$discussion->is_deleted): ?>
                    <br>
                    <a href="#" class="reply-btn" data-toggle="collapse"
                        data-target="#reply-form-<?php echo e($discussion->id); ?>">Balas</a>

                    
                    <?php if(Auth::user()->id === $discussion->user_id): ?>
                        <span class="text-muted small mx-1">&middot;</span>
                        <form action="<?php echo e(route('student.lessons.discussions.destroy', $discussion->id)); ?>"
                            method="POST" class="d-inline"
                            onsubmit="return confirm('Apakah Anda yakin ingin menghapus komentar ini? Aksi ini tidak dapat dibatalkan.');">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="btn btn-link text-danger p-0 small">Hapus</button>
                        </form>
                    <?php endif; ?>
                <?php endif; ?>

                
                <div class="collapse mt-3" id="reply-form-<?php echo e($discussion->id); ?>">
                    <form action="<?php echo e(route('student.lessons.discussions.store', $lesson->id)); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="parent_id" value="<?php echo e($discussion->id); ?>">
                        <div class="form-group">
                            <textarea name="content" class="form-control" rows="2" placeholder="Tulis balasan Anda..." required></textarea>
                        </div>
                        <button type="submit" class="btn btn-sm btn-secondary">Kirim Balasan</button>
                    </form>
                </div>

                
                <?php $__currentLoopData = $discussion->replies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reply): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="media mt-4">
                        <a class="d-flex pr-3" href="#">
                            <img src="<?php echo e($reply->user->profile_picture_url ? asset('storage/' . ltrim($reply->user->profile_picture_url, '/')) : 'https://placehold.co/40x40'); ?>"
                                alt="User Avatar" class="rounded-circle" style="width: 40px; height: 40px;">
                        </a>
                        <div class="media-body">
                            <div class="mt-0 d-flex align-items-center gap-2">
                                <h5 class="d-flex align-items-center mr-1">
                                    <?php echo e($reply->user->name); ?>

                                    <?php if($reply->user->equippedBadge): ?>
                                        <span class="badge badge-primary mx-1">
                                            <?php echo e($reply->user->equippedBadge->title); ?>

                                        </span>
                                    <?php endif; ?>
                                </h5>
                                <small class="text-muted mx-1">- <?php echo e($reply->created_at->diffForHumans()); ?></small>
                            </div>
                            
                            <?php echo nl2br(e($reply->content)); ?>


                            
                            <?php if(!$reply->is_deleted): ?>
                                <?php if(Auth::user()->id === $reply->user_id): ?>
                                    <br>
                                    <form action="<?php echo e(route('student.lessons.discussions.destroy', $reply->id)); ?>"
                                        method="POST" class="d-inline"
                                        onsubmit="return confirm('Apakah Anda yakin ingin menghapus komentar ini? Aksi ini tidak dapat dibatalkan.');">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button type="submit" class="btn btn-link text-danger p-0 small">Hapus</button>
                                    </form>
                                <?php endif; ?>
                            <?php endif; ?>

                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <p class="text-muted text-center">Jadilah yang pertama memulai diskusi untuk pelajaran ini.</p>
    <?php endif; ?>
</div>
<?php /**PATH /home/wahaname/public_html/edukasi/resources/views/student/courses/partials/_discussion_forum.blade.php ENDPATH**/ ?>