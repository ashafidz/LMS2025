


        <h5><?php echo e($title); ?></h5>


        <ul class="nav nav-tabs md-tabs" role="tablist">
            <li class="nav-item">
                <a class="nav-link active" data-toggle="tab" href="#daftar_siswa" role="tab">Daftar Siswa</a>
                <div class="slide"></div>
            </li>
            <li class="nav-item">
                <a class="nav-link" data-toggle="tab" href="#peringkat" role="tab">Peringkat</a>
                <div class="slide"></div>
            </li>
        </ul>
        <div class="tab-content card-block">
            
            <div class="tab-pane active" id="daftar_siswa" role="tabpanel">
                <div class="table-responsive">
                    <table class="table table-hover">
                        <thead>
                            <tr>
                                <th class="text-center">NIM/NIP/NIDN</th>
                                <th>Nama Siswa</th>
                                <th>Email</th>
                                <!--<th class="text-right">Poin Diperoleh</th>-->
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $enrolledStudents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td class="text-center" ><?php echo e($student->studentProfile->unique_id_number ? $student->studentProfile->unique_id_number : '-'); ?></td>
                                    <td><?php echo e($student->name); ?></td>
                                    <td><?php echo e($student->email); ?></td>
                                    <!--<td class="text-right font-weight-bold"><?php echo e(number_format($student->points_earned, 0, ',', '.')); ?></td>-->
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan="3" class="text-center">Belum ada siswa yang terdaftar di kursus ini.</td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>

            
            <div class="tab-pane" id="peringkat" role="tabpanel">
                <div class="table-responsive">
                    <table class="table table-hover">
                        <thead>
                            <tr>
                                <th style="width: 10%;">Peringkat</th>
                                <th class="text-center">NIM/NIP/NIDN</th>
                                <th>Nama Siswa</th>
                                <th class="text-right">Total Poin</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $leaderboardRanks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $rank): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    
                                <tr class="
                        <?php if($index + 1 <= 5): ?>
                            table-success
                        <?php elseif($index + 1 <= 20): ?>
                            table-info
                        <?php else: ?>
                            table-danger
                        <?php endif; ?>
                    " >
                                    <td class="font-weight-bold">#<?php echo e($index + 1); ?></td>
                                    <td class="text-center" ><?php echo e($rank->user->studentProfile->unique_id_number ? $rank->user->studentProfile->unique_id_number : '-'); ?></td>
                                    <td><?php echo e($rank->user->name); ?></td>
                                    <td class="text-right font-weight-bold"><?php echo e(number_format($rank->points_earned, 0, ',', '.')); ?> <span><i class="bi bi-star-fill text-warning"></ic></span></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan="3" class="text-center">Belum ada poin yang tercatat untuk dibuat peringkat.</td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

<?php /**PATH /home/wahaname/public_html/edukasi/resources/views/instructor/leaderboards/_course_data_modal.blade.php ENDPATH**/ ?>