<?php $__env->startSection('content'); ?>
<div class="pcoded-content">
    <div class="page-header">
        <div class="page-block">
            <div class="row align-items-center">
                <div class="col-md-8">
                    <div class="page-header-title">
                        <h5 class="m-b-10">Kelola Pengguna</h5>
                        <p class="m-b-0">Kursus: <strong><?php echo e($course->title); ?></strong></p>
                    </div>
                </div>
                <div class="col-md-4">
                    <ul class="breadcrumb-title">
                        <li class="breadcrumb-item"><a href="<?php echo e(route(Auth::user()->getRoleNames()->first() . '.dashboard')); ?>"><i class="fa fa-home"></i></a></li>
                        <li class="breadcrumb-item"><a href="<?php echo e(route(Auth::user()->getRoleNames()->first() . '.course-enrollments.index')); ?>">Kelola Pengguna</a></li>
                        <li class="breadcrumb-item"><a href="#!"><?php echo e(Str::limit($course->title, 20)); ?></a></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    <div class="pcoded-inner-content">
        <div class="main-body">
            <div class="page-wrapper">
                <div class="page-body">
                    <div class="row">
                        <div class="col-sm-12">
                            <div class="card">
                                <div class="card-header">
                                    <h5>Daftar Pengguna Terdaftar</h5>
                                    <span>Halaman kelola pengguna manual untuk kursus <?php echo e($course->title); ?></span>
                                    <div class="card-header-right">
                                        <a href="<?php echo e(route(Auth::user()->getRoleNames()->first() . '.course-enrollments.create', $course->id)); ?>" class="btn btn-primary">
                                            <i class="fa fa-plus"></i> Tambah Pengguna Baru
                                        </a>
                                    </div>
                                </div>
                                <div class="card-block">
                                    <?php if(session('success')): ?>
                                        <div class="alert alert-success"><?php echo e(session('success')); ?></div>
                                    <?php endif; ?>
                                    <form id="bulk-delete-form" action="<?php echo e(route(Auth::user()->getRoleNames()->first() . '.course-enrollments.destroy', $course->id)); ?>" method="POST">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <div class="mb-3">
                                            
                                            <button type="button" class="btn btn-danger" id="bulk-delete-btn" data-toggle="modal" data-target="#bulkDeleteModal" disabled>
                                                <i class="fa fa-trash"></i> Hapus yang Dipilih
                                            </button>
                                            <button type="button" class="btn btn-danger" data-toggle="modal" data-target="#deleteAllModal"><i class="fa fa-trash-o"></i> Hapus Semua Pengguna</button>
                                        </div>
                                        <div class="table-responsive">
                                            <table class="table table-hover">
                                                <thead>
                                                    <tr>
                                                        <th style="width: 5%;">
                                                            
                                                            <input type="checkbox" id="select-all">
                                                        </th>
                                                        <th>Nama Siswa</th>
                                                        <th>Email</th>
                                                        <th>Tanggal Terdaftar</th>
                                                        <th class="text-center">Aksi</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <?php $__empty_1 = true; $__currentLoopData = $enrolledUsers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                                        <tr>
                                                            <td>
                                                                
                                                                <input type="checkbox" name="user_ids[]" value="<?php echo e($user->id); ?>" class="user-checkbox">
                                                            </td>
                                                            <td><?php echo e($user->name); ?></td>
                                                            <td><?php echo e($user->email); ?></td>
                                                            <td><?php echo e($user->pivot->enrolled_at ? \Carbon\Carbon::parse($user->pivot->enrolled_at)->format('d M Y, H:i') : 'N/A'); ?></td>
                                                            <td class="text-center">
                                                                <button type="button" class="btn btn-danger btn-sm" data-toggle="modal" data-target="#deleteSingleModal-<?php echo e($user->id); ?>">
                                                                    <i class="fa fa-trash"></i> Hapus
                                                                </button>
                                                            </td>
                                                        </tr>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                                        <tr>
                                                            <td colspan="5" class="text-center">Belum ada pengguna yang terdaftar di kursus ini.</td>
                                                        </tr>
                                                    <?php endif; ?>
                                                </tbody>
                                            </table>
                                        </div>
                                    </form>
                                    <div class="d-flex justify-content-center">
                                        <?php echo e($enrolledUsers->links()); ?>

                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <?php $__currentLoopData = $enrolledUsers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="modal fade" id="deleteSingleModal-<?php echo e($user->id); ?>" tabindex="-1" role="dialog">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title">Konfirmasi Hapus</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                    </div>
                    <div class="modal-body">
                        <p>Apakah Anda yakin ingin menghapus <strong><?php echo e($user->name); ?></strong> dari kursus ini?</p>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Batal</button>
                        <form action="<?php echo e(route(Auth::user()->getRoleNames()->first() . '.course-enrollments.destroy', $course->id)); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <input type="hidden" name="user_ids[]" value="<?php echo e($user->id); ?>">
                            <button type="submit" class="btn btn-danger">Ya, Hapus</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <div class="modal fade" id="deleteAllModal" tabindex="-1" role="dialog">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title">Konfirmasi Hapus Semua</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                    </div>
                    <div class="modal-body">
                        <p>Apakah Anda yakin ingin menghapus <strong>semua pengguna</strong> dari kursus ini? Aksi ini tidak dapat dibatalkan.</p>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Batal</button>
                        <form action="<?php echo e(route(Auth::user()->getRoleNames()->first() . '.course-enrollments.destroy', $course->id)); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <?php $__currentLoopData = $enrolledUsers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <input type="hidden" name="user_ids[]" value="<?php echo e($user->id); ?>">
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <button type="submit" class="btn btn-danger">Ya, Hapus Semua</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
</div>



<div class="modal fade" id="bulkDeleteModal" tabindex="-1" role="dialog">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Konfirmasi Hapus Pengguna Terpilih</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <p>Apakah Anda yakin ingin menghapus pengguna yang <strong>dipilih</strong> dari kursus ini?</p>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Batal</button>
                
                <button type="button" class="btn btn-danger" id="confirm-bulk-delete-btn">Ya, Hapus</button>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>




<script>
document.addEventListener('DOMContentLoaded', function() {
    const selectAll = document.getElementById('select-all');
    const userCheckboxes = document.querySelectorAll('.user-checkbox');
    const bulkDeleteBtn = document.getElementById('bulk-delete-btn');
    const confirmBulkDeleteBtn = document.getElementById('confirm-bulk-delete-btn'); // Get the new modal button

    function toggleBulkDeleteBtn() {
        const anyChecked = Array.from(userCheckboxes).some(cb => cb.checked);
        bulkDeleteBtn.disabled = !anyChecked;
    }

    if (selectAll) {
        selectAll.addEventListener('change', function() {
            userCheckboxes.forEach(cb => {
                cb.checked = this.checked;
            });
            toggleBulkDeleteBtn();
        });
    }

    userCheckboxes.forEach(cb => {
        cb.addEventListener('change', function() {
            if (!this.checked) {
                // Uncheck "select all" if any individual box is unchecked
                if (selectAll) {
                    selectAll.checked = false;
                }
            } else {
                // Check if all are checked to update "select all"
                const allChecked = Array.from(userCheckboxes).every(cb => cb.checked);
                if (selectAll) {
                    selectAll.checked = allChecked;
                }
            }
            toggleBulkDeleteBtn();
        });
    });
    
    // This event listener now handles the final submission from the modal
    if (confirmBulkDeleteBtn) {
        confirmBulkDeleteBtn.addEventListener('click', function() {
            document.getElementById('bulk-delete-form').submit();
        });
    }

    // Initialize the button state on page load
    toggleBulkDeleteBtn();
});
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app-layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/wahaname/public_html/edukasi/resources/views/shared-admin/course-enrollments/show.blade.php ENDPATH**/ ?>