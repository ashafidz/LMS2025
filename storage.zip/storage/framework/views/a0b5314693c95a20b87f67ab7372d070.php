

<?php
    $totalPointsFromThisLesson = 0;
    if(Auth::check() && !$is_preview) {
        // Ambil total poin yang didapat user dari pelajaran ini saja
        $totalPointsFromThisLesson = Auth::user()->pointHistories()
            ->where('description', 'like', 'Poin manual dari pelajaran: ' . $lesson->title)
            ->sum('points');
    }
?>

<h4 class="font-weight-bold"><?php echo e($lesson->lessonable->title); ?></h4>
<p class="text-muted"><?php echo e($lesson->lessonable->description); ?></p>
<hr>

<div class="text-center p-4">
    <div class="card" style="max-width: 300px; margin: auto;">
        <div class="card-body">
            <p class="mb-2">Total Poin yang Anda Peroleh di Sesi Ini:</p>
            <h2 class="font-weight-bold text-warning d-flex justify-content-center align-items-center">
                <i class="ti-medall-alt me-2"></i> <?php echo e(number_format($totalPointsFromThisLesson, 0, ',', '.')); ?>

            </h2>
        </div>
    </div>
</div><?php /**PATH /home/wahaname/public_html/edukasi/resources/views/instructor/lessons/previews/_lessonpoint.blade.php ENDPATH**/ ?>