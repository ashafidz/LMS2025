

<?php $__env->startSection('content'); ?>
<div class="pcoded-content">
    <!-- Page-header start -->
    <div class="page-header">
        <div class="page-block">
            <div class="row align-items-center">
                <div class="col-md-8">
                    <div class="page-header-title">
                        <h5 class="m-b-10">Bank Soal</h5>
                        <p class="m-b-0">Kelola semua topik untuk bank soal Anda.</p>
                    </div>
                </div>
                <div class="col-md-4">
                    <ul class="breadcrumb-title">
                        <li class="breadcrumb-item"><a href="<?php echo e(route('instructor.dashboard')); ?>"><i class="fa fa-home"></i></a></li>
                        <li class="breadcrumb-item"><a href="#!">Bank Soal</a></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    <!-- Page-header end -->

    <div class="pcoded-inner-content">
        <div class="main-body">
            <div class="page-wrapper">
                <div class="page-body">
                    <div class="row">
                        <div class="col-sm-12">
                            <div class="card">
                                <div class="card-header">
                                    <h5>Daftar Topik</h5>
                                    <span>Anda dapat menambah, mengedit, atau menghapus topik di bawah ini.</span>
                                    <div class="card-header-right">
                                        <a href="<?php echo e(route('instructor.question-bank.topics.create')); ?>" class="btn btn-primary"><i class="bi bi-plus-lg text-white"></i>Buat Topik Baru</a>
                                    </div>
                                </div>
                                <div class="card-block">
                                    <?php if(session('success')): ?>
                                        <div class="alert alert-success"><?php echo e(session('success')); ?></div>
                                    <?php endif; ?>

                                    
                                    <form action="<?php echo e(route('instructor.question-bank.topics.index')); ?>" method="GET" class="mb-4">
                                        <div class="form-group row align-items-end">
                                            <div class="col-md-4">
                                                <label for="filter_course">Tampilkan Topik Untuk Kursus:</label>
                                                <select name="filter_course" id="filter_course" class="form-control" onchange="this.form.submit()">
                                                    <option value="all" <?php echo e(request('filter_course') == 'all' ? 'selected' : ''); ?>>Tampilkan Semua Topik Saya</option>
                                                    <option value="global" <?php echo e(request('filter_course') == 'global' ? 'selected' : ''); ?>>Topik yang muncul di Semua Kursus Saya</option>
                                                    <optgroup label="Kursus Spesifik">
                                                        <?php $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <option value="<?php echo e($course->id); ?>" <?php echo e(request('filter_course') == $course->id ? 'selected' : ''); ?>><?php echo e($course->title); ?></option>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </optgroup>
                                                </select>
                                            </div>
                                        </div>
                                    </form>

                                    <div class="table-responsive">
                                        <table class="table table-hover">
                                            <thead>
                                                <tr>
                                                    <th>Nama Topik</th>
                                                    <th>Jumlah Soal</th>
                                                    <th>Ketersediaan</th>
                                                    <th class="text-center">Aksi</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php $__empty_1 = true; $__currentLoopData = $topics; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $topic): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                                    <tr>
                                                        <td>
                                                            <strong><a href="<?php echo e(route('instructor.question-bank.questions.index', $topic)); ?>"><?php echo e($topic->name); ?></a></strong>
                                                            <p class="text-muted mb-0"><?php echo e(Str::limit($topic->description, 70)); ?></p>
                                                        </td>
                                                        <td><?php echo e($topic->questions_count); ?> Soal</td>
                                                        <td>
                                                            <?php if($topic->available_for_all_courses): ?>
                                                                <label class="label label-info">Semua Kursus</label>
                                                            <?php else: ?>
                                                                <label class="label label-default">Kursus Spesifik</label>
                                                            <?php endif; ?>
                                                        </td>
                                                        <td class="text-center">
                                                            <a href="<?php echo e(route('instructor.question-bank.questions.index', $topic)); ?>" class="btn btn-success btn-sm"><i class="bi bi-eye me-1"></i>Lihat Soal</a>
                                                            <a href="<?php echo e(route('instructor.question-bank.topics.edit', $topic->id)); ?>" class="btn btn-info btn-sm <?php echo e($topic->is_locked ? 'disabled' : ''); ?>" <?php echo e($topic->is_locked ? 'onclick="return false;"' : ''); ?>><i class="fa fa-pencil"></i>Edit</a>
                                                            <form action="<?php echo e(route('instructor.question-bank.topics.destroy', $topic->id)); ?>" method="POST" class="d-inline" onsubmit="return confirm('Apakah Anda yakin ingin menghapus topik ini?');">
                                                                <?php echo csrf_field(); ?>
                                                                <?php echo method_field('DELETE'); ?>
                                                                <button type="submit" class="btn btn-danger btn-sm <?php echo e($topic->is_locked ? 'disabled' : ''); ?>"><i class="fa fa-trash"></i>Hapus</button>
                                                            </form>
                                                        </td>
                                                    </tr>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                                    <tr>
                                                        <td colspan="4" class="text-center">Tidak ada topik yang cocok dengan filter Anda.</td>
                                                    </tr>
                                                <?php endif; ?>
                                            </tbody>
                                        </table>
                                    </div>
                                    <div class="d-flex justify-content-center">
                                        <?php echo e($topics->links()); ?>

                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app-layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/wahaname/public_html/edukasi/resources/views/instructor/question_bank/topics/index.blade.php ENDPATH**/ ?>