

<h4 class="font-weight-bold"><?php echo e($lesson->title); ?></h4>
<hr>

<?php if($lesson->lessonable->video_path): ?>
    <?php if($lesson->lessonable->source_type == 'upload'): ?>
        
        <video width="100%" controls controlsList="nodownload">
            <source src="<?php echo e(Storage::url($lesson->lessonable->video_path)); ?>" type="video/mp4">
            Browser Anda tidak mendukung tag video.
        </video>

    <?php elseif($lesson->lessonable->source_type == 'youtube'): ?>
        
        <?php
            // Ekstrak ID video dari berbagai format URL YouTube
            preg_match('%(?:youtube(?:-nocookie)?\.com/(?:[^/]+/.+/|(?:v|e(?:mbed)?)/|.*[?&]v=)|youtu\.be/)([^"&?/ ]{11})%i', $lesson->lessonable->video_path, $match);
            $youtube_id = $match[1] ?? null;
        ?>

        <?php if($youtube_id): ?>
            <div class="embed-responsive embed-responsive-16by9">
                <iframe class="embed-responsive-item" src="https://www.youtube.com/embed/<?php echo e($youtube_id); ?>" allowfullscreen></iframe>
            </div>
        <?php else: ?>
            <div class="alert alert-warning">
                URL YouTube tidak valid atau tidak dapat diproses. URL: <?php echo e($lesson->lessonable->video_path); ?>

            </div>
        <?php endif; ?>
    <?php endif; ?>
<?php else: ?>
    <p class="text-muted text-center">Tidak ada video yang terhubung dengan pelajaran ini.</p>
<?php endif; ?><?php /**PATH /home/wahaname/public_html/edukasi/resources/views/instructor/lessons/previews/_lessonvideo.blade.php ENDPATH**/ ?>