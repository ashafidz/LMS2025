

<div class="table-responsive">
    <table class="table table-hover">
        <thead>
            <tr>
                <th>Nama Siswa</th>
                <th>Waktu Pengumpulan</th>
                <th>Nilai</th>
                <th class="text-center">Aksi</th>
            </tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $submissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $submission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><?php echo e($submission->user->name); ?></td>
                    <td><?php echo e($submission->submitted_at->format('d F Y, H:i')); ?></td>
                    <td>
                        <?php if(!is_null($submission->grade)): ?>
                            <span class="badge badge-inverse"><?php echo e($submission->grade); ?> / 100</span>
                        <?php else: ?>
                            -
                        <?php endif; ?>
                    </td>
                    <td class="text-center">
                        <button type="button" class="btn btn-primary btn-sm" data-toggle="modal" data-target="#submissionModal-<?php echo e($submission->id); ?>">
                            Lihat & Nilai
                        </button>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="4" class="text-center">Tidak ada data pengumpulan di kategori ini.</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>
</div><?php /**PATH /home/wahaname/public_html/edukasi/resources/views/instructor/assignments/partials/_submission_table.blade.php ENDPATH**/ ?>