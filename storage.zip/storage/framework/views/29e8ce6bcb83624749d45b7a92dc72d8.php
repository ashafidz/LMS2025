<?php $__env->startSection('content'); ?>
<div class="pcoded-content">
    <!-- Page-header start -->
    <div class="page-header">
        <div class="page-block">
            <div class="row align-items-center">
                <div class="col-md-8">
                    <div class="page-header-title">
                        <h5 class="m-b-10">Manajemen Kupon</h5>
                        <p class="m-b-0">Buat, lihat, dan kelola semua kupon diskon.</p>
                    </div>
                </div>
                <div class="col-md-4">
                    <ul class="breadcrumb-title">
                        
                        <li class="breadcrumb-item"><a href="<?php echo e(route(Auth::user()->getRoleNames()->first() . '.dashboard')); ?>"><i class="fa fa-home"></i></a></li>
                        <li class="breadcrumb-item"><a href="#!">Kupon</a></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    <!-- Page-header end -->

    <div class="pcoded-inner-content">
        <div class="main-body">
            <div class="page-wrapper">
                <div class="page-body">
                    <div class="row">
                        <div class="col-sm-12">
                            <div class="card">
                                <div class="card-header">
                                    <h5>Daftar Kupon</h5>
                                    <span>Menampilkan semua kupon diskon</span>
                                    <div class="card-header-right">
                                        <a href="<?php echo e(route(Auth::user()->getRoleNames()->first() . '.coupons.create')); ?>" class="btn btn-primary">Buat Kupon Baru</a>
                                    </div>
                                </div>
                                <div class="card-block table-border-style">
                                    <?php if(session('success')): ?>
                                        <div class="alert alert-success"><?php echo e(session('success')); ?></div>
                                    <?php endif; ?>
                                    <?php if(session('error')): ?>
                                        <div class="alert alert-danger"><?php echo e(session('error')); ?></div>
                                    <?php endif; ?>
                                    <div class="table-responsive">
                                        <table class="table table-hover">
                                            <thead>
                                                <tr>
                                                    <th>#</th>
                                                    <th>Kode</th>
                                                    <th>Tipe</th>
                                                    <th>Nilai</th>
                                                    <th>Berlaku Untuk</th>
                                                    <th>Penggunaan</th>
                                                    <th>Status</th>
                                                    <th>Kedaluwarsa</th>
                                                    <th class="text-center">Aksi</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php $__empty_1 = true; $__currentLoopData = $coupons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $coupon): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                                    <tr>
                                                        <th scope="row"><?php echo e($loop->iteration + $coupons->firstItem() - 1); ?></th>
                                                        <td><strong><?php echo e($coupon->code); ?></strong></td>
                                                        <td><?php echo e(ucfirst($coupon->type)); ?></td>
                                                        <td>
                                                            <?php if($coupon->type == 'percent'): ?>
                                                                <?php echo e($coupon->value); ?>%
                                                            <?php else: ?>
                                                                Rp <?php echo e(number_format($coupon->value, 0, ',', '.')); ?>

                                                            <?php endif; ?>
                                                        </td>
                                                        <td><?php echo e($coupon->course->title ?? 'Semua Kursus'); ?></td>
                                                        <td><?php echo e($coupon->uses_count); ?> / <?php echo e($coupon->max_uses ?? '∞'); ?></td>
                                                        <td>
                                                            <?php if($coupon->is_active): ?>
                                                                <label class="label label-success">Aktif</label>
                                                            <?php else: ?>
                                                                <label class="label label-default">Tidak Aktif</label>
                                                            <?php endif; ?>
                                                        </td>
                                                        <td><?php echo e($coupon->expires_at ? $coupon->expires_at->format('d M Y') : 'Tidak ada'); ?></td>
                                                        <td class="text-center">
                                                            <a href="<?php echo e(route(Auth::user()->getRoleNames()->first() . '.coupons.edit', $coupon->id)); ?>" class="btn btn-info btn-sm">
                                                                <i class="fa fa-pencil"></i> Edit
                                                            </a>
                                                            <form action="<?php echo e(route(Auth::user()->getRoleNames()->first() . '.coupons.destroy', $coupon->id)); ?>" method="POST" class="d-inline" onsubmit="return confirm('Apakah Anda yakin ingin menghapus kupon ini?');">
                                                                <?php echo csrf_field(); ?>
                                                                <?php echo method_field('DELETE'); ?>
                                                                <button type="submit" class="btn btn-danger btn-sm">
                                                                    <i class="fa fa-trash"></i> Hapus
                                                                </button>
                                                            </form>
                                                        </td>
                                                    </tr>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                                    <tr>
                                                        <td colspan="9" class="text-center">Belum ada kupon yang dibuat.</td>
                                                    </tr>
                                                <?php endif; ?>
                                            </tbody>
                                        </table>
                                    </div>
                                    <div class="d-flex justify-content-center">
                                        <?php echo e($coupons->links()); ?>

                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app-layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/wahaname/public_html/edukasi/resources/views/shared-admin/coupons/index.blade.php ENDPATH**/ ?>