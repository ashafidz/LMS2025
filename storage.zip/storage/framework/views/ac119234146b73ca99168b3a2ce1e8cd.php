

<?php $__env->startSection('title', 'Keranjang Belanja'); ?>

<?php $__env->startSection('content'); ?>
<section class="py-5" style="margin-top: 60px; background-color: #f8f9fa;">
    <div class="container">
        <h2 class="fw-bold mb-4">Keranjang Belanja Anda</h2>

        <?php if(session('success')): ?>
            <div class="alert alert-success"><?php echo e(session('success')); ?></div>
        <?php endif; ?>
        <?php if(session('info')): ?>
            <div class="alert alert-info"><?php echo e(session('info')); ?></div>
        <?php endif; ?>
        <?php if($errors->any()): ?>
            <div class="alert alert-danger">
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php echo e($error); ?>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        <?php endif; ?>
        
        <div class="row align-items-start">
            
            <?php if($cartItems->isEmpty()): ?>
                <div class="col-12">
                    <div class="bg-white border rounded p-5 text-center" style="max-width: 600px; margin: auto;">
                        <i class="bi bi-cart-x fs-1 text-muted"></i>
                        <h4 class="mt-3">Keranjang Anda Kosong</h4>
                        <p class="text-muted">Sepertinya Anda belum menambahkan kursus apapun ke keranjang.</p>
                        <a href="<?php echo e(route('courses')); ?>" class="btn btn-primary rounded-pill w-50 mt-3">
                            Jelajahi Kursus
                        </a>
                    </div>
                </div>
            <?php else: ?>
                <div class="col-lg-8">
                    <?php $__currentLoopData = $cartItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="d-flex border rounded p-3 mb-3 bg-white shadow-sm">
                            <img src="<?php echo e($item->course->thumbnail_url ? Storage::url($item->course->thumbnail_url) : 'https://placehold.co/120x80'); ?>"
                                alt="<?php echo e($item->course->title); ?>"
                                class="rounded-2 me-3"
                                style="width: 120px; height: 80px; object-fit: cover; object-position: center;">
                            
                            <div class="flex-grow-1 d-flex flex-column justify-content-between">
                                <div>
                                    <h5 class="mb-1"><?php echo e($item->course->title); ?></h5>
                                    <p class="text-muted mb-1"><?php echo e($item->course->instructor->name); ?></p>
                                </div>
                                <div class="d-flex justify-content-between align-items-end mt-2">
                                    <button type="button" class="btn btn-sm btn-outline-danger d-inline-flex align-items-center gap-1"
                                        data-bs-toggle="modal" data-bs-target="#deleteModal<?php echo e($item->id); ?>">
                                        <i class="bi bi-trash"></i> Hapus
                                    </button>
                                    <strong class="text-primary fs-5">Rp<?php echo e(number_format($item->course->price, 0, ',', '.')); ?></strong>
                                </div>
                            </div>
                        </div>

                        <div class="modal fade" id="deleteModal<?php echo e($item->id); ?>" tabindex="-1" aria-labelledby="deleteModalLabel<?php echo e($item->id); ?>" aria-hidden="true">
                            <div class="modal-dialog modal-dialog-centered">
                                <div class="modal-content rounded-4 shadow-sm border-0">
                                    <div class="modal-header border-0 pb-0">
                                        <h5 class="modal-title text-danger d-flex align-items-center" id="deleteModalLabel<?php echo e($item->id); ?>">
                                            <i class="bi bi-trash-fill me-2"></i> Konfirmasi Hapus
                                        </h5>
                                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Tutup"></button>
                                    </div>
                                    <div class="modal-body text-center">
                                        <p class="mb-3 fs-6">
                                            Yakin ingin menghapus <strong><?php echo e($item->course->title); ?></strong> dari keranjang?
                                        </p>
                                    </div>
                                    <div class="modal-footer border-0 justify-content-center pb-4">
                                        <button type="button" class="btn btn-secondary rounded-pill px-4" data-bs-dismiss="modal">Batal</button>
                                        <form action="<?php echo e(route('student.cart.remove', $item->id)); ?>" method="POST" class="d-inline">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <button type="submit" class="btn btn-danger rounded-pill px-4 ms-2">
                                                <i class="bi bi-check-circle me-1"></i> Hapus
                                            </button>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>

                <div class="col-lg-4">
                    <div class="bg-white border rounded p-4 shadow-sm">
                        <h5 class="fw-bold">Ringkasan Belanja</h5>
                        <hr>
                        
                        <?php if(session()->has('coupon')): ?>
                            <div class="d-flex justify-content-between">
                                <span>Kupon diterapkan:</span>
                                <strong><?php echo e(session('coupon')->code); ?></strong>
                            </div>
                            <form action="<?php echo e(route('student.cart.remove_coupon')); ?>" method="POST" class="mt-2">
                                <?php echo csrf_field(); ?>
                                <button type="submit" class="btn btn-sm btn-outline-danger w-100">Hapus Kupon</button>
                            </form>
                        <?php else: ?>
                            <form action="<?php echo e(route('student.cart.apply_coupon')); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <label for="coupon_code" class="form-label">Punya Kupon?</label>
                                <div class="input-group">
                                    <input type="text" name="code" id="coupon_code" class="form-control" placeholder="Masukkan kode kupon">
                                    <button class="btn btn-outline-secondary" type="submit">Terapkan</button>
                                </div>
                            </form>
                             <button type="button" class="btn btn-primary rounded-pill w-100 d-flex align-items-center justify-content-center gap-2 mt-2" data-bs-toggle="modal" data-bs-target="#modalKupon">
                                <i class="bi bi-percent"></i> Lihat Promo
                            </button>
                        <?php endif; ?>
                        
                        <hr>
                        <div class="d-flex justify-content-between mb-2">
                            <span class="text-muted">Subtotal:</span>
                            <span>Rp<?php echo e(number_format($subtotal, 0, ',', '.')); ?></span>
                        </div>
                        <?php if(session()->has('coupon')): ?>
                            <div class="d-flex justify-content-between mb-2 text-success">
                                <span class="text-muted">Diskon:</span>
                                <span>- Rp<?php echo e(number_format($discount, 0, ',', '.')); ?></span>
                            </div>
                        <?php endif; ?>
                        <div class="d-flex justify-content-between mb-2">
                            <span class="text-muted">PPN (11%):</span>
                            <span>+ Rp<?php echo e(number_format($vatAmount, 0, ',', '.')); ?></span>
                        </div>
                        <div class="d-flex justify-content-between mb-2">
                            <span class="text-muted">Biaya Layanan:</span>
                            <span>+ Rp<?php echo e(number_format($transactionFee, 0, ',', '.')); ?></span>
                        </div>
                        <hr>
                        <div class="d-flex justify-content-between fw-bold fs-5">
                            <span>Total:</span>
                            <span>Rp<?php echo e(number_format($finalTotal, 0, ',', '.')); ?></span>
                        </div>

                        
                        <form action="<?php echo e(route('checkout.process')); ?>" method="POST" id="checkout-form">
                            <?php echo csrf_field(); ?>
                            <button type="button" id="checkout-btn" class="btn btn-primary rounded-pill w-100 mt-3">
                                Lanjut ke Pembayaran
                            </button>
                        </form>
                    </div>
                </div>
            <?php endif; ?>
        </div>
    </div>

    
    

</section>



<?php if($popularCourses->isNotEmpty()): ?>
<section class="py-5" style="background-color: #f8f9fa;">
    <div class="container">
        <div class="mt-5">
            <h4 class="fw-bold text-primary mb-4">Rekomendasi Kursus Untuk Anda</h4>
            <div class="row g-4">

                
                <?php $__currentLoopData = $popularCourses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-4 col-lg-3">
                    
                    <a href="<?php echo e(route('courses.show', $course->slug)); ?>" class="text-decoration-none">
                        <div class="card h-100 shadow-sm border-0 rounded-4">
                            
                            
                            <img src="<?php echo e($course->thumbnail_url ? asset('storage/' . $course->thumbnail_url) : 'https://placehold.co/600x400/e0edff/007bff?text=Kursus'); ?>" 
                                 class="card-img-top rounded-top-4" 
                                 style="height: 150px; object-fit: cover;" 
                                 alt="<?php echo e($course->title); ?>">
                                 
                            <div class="card-body d-flex flex-column">
                                
                                <h5 class="card-title flex-grow-1"><?php echo e(Str::limit($course->title, 50)); ?></h5>

                                
                                <p class="text-muted mb-2"><?php echo e($course->instructor->name ?? 'Tanpa Instruktur'); ?></p>

                                
                                <span class="fw-bold text-dark">
                                    <?php if($course->price > 0): ?>
                                        Rp<?php echo e(number_format($course->price, 0, ',', '.')); ?>

                                    <?php else: ?>
                                        Gratis
                                    <?php endif; ?>
                                </span>
                            </div>
                        </div>
                    </a>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </div>
        </div>
        <div class="text-center mt-5">
            <a href="<?php echo e(route('courses')); ?>" class="btn btn-outline-primary rounded-pill px-4 py-2">
                Lihat Lainnya <i class="bi bi-arrow-right ms-1"></i>
            </a>
        </div>
    </div>
</section>
<?php endif; ?>




<div class="modal fade" id="modalKupon" tabindex="-1" aria-labelledby="modalKuponLabel" aria-hidden="true">
  <div class="modal-dialog modal-dialog-scrollable">
    <div class="modal-content">
        <div class="modal-header">
            <h5 class="modal-title" id="modalKuponLabel">Promo Tersedia</h5>
            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Tutup"></button>
        </div>
        <div class="modal-body">
            
            <div class="border rounded p-3 mb-3 shadow-sm">
                <span class="badge bg-info mb-2">Diskon hingga 30%</span>
                <h6 class="fw-bold mb-1">Promo JAGOCODING - Full Stack</h6>
                <div class="d-flex justify-content-between align-items-center">
                    <span class="text-muted small">Kode: <code>JAGOCODING</code></span>
                    <button class="btn btn-sm btn-primary" onclick="pilihKupon('JAGOCODING')">Gunakan</button>
                </div>
            </div>
        </div>
    </div>
  </div>
</div>


<div class="modal fade" id="checkoutConfirmModal" tabindex="-1" aria-labelledby="checkoutConfirmModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content rounded-4 shadow-sm border-0">
            <div class="modal-header border-0 pb-0">
                <h5 class="modal-title" id="checkoutConfirmModalLabel">Konfirmasi Pesanan</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Tutup"></button>
            </div>
            <div class="modal-body py-4 text-center">
                <p class="fs-6">
                    Apakah Anda yakin ingin membuat pesanan dan lanjut ke tahap pembayaran?
                </p>
            </div>
            <div class="modal-footer border-0 justify-content-center pb-4">
                <button type="button" class="btn btn-secondary rounded-pill px-4" data-bs-dismiss="modal">Batal</button>
                <button type="button" id="confirm-checkout-btn" class="btn btn-primary rounded-pill px-4 ms-2">
                    Ya, Lanjutkan
                </button>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
    function pilihKupon(kode) {
        document.getElementById('coupon_code').value = kode;
        var modal = bootstrap.Modal.getInstance(document.getElementById('modalKupon'));
        modal.hide();
    }

    // BARU: Logika untuk modal konfirmasi checkout
    document.addEventListener('DOMContentLoaded', function() {
        const checkoutBtn = document.getElementById('checkout-btn');
        
        // Cek jika tombol checkout ada (saat keranjang tidak kosong)
        if (checkoutBtn) {
            const checkoutForm = document.getElementById('checkout-form');
            const confirmCheckoutBtn = document.getElementById('confirm-checkout-btn');
            const checkoutModal = new bootstrap.Modal(document.getElementById('checkoutConfirmModal'));

            // 1. Saat tombol "Lanjut ke Pembayaran" diklik, tampilkan modal
            checkoutBtn.addEventListener('click', function() {
                checkoutModal.show();
            });

            // 2. Saat tombol "Ya, Lanjutkan" di modal diklik, submit form
            confirmCheckoutBtn.addEventListener('click', function() {
                checkoutForm.submit();
            });
        }
    });
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.home-layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/wahaname/public_html/edukasi/resources/views/student/cart/index.blade.php ENDPATH**/ ?>