<?php $__env->startSection('title', 'Pembayaran Dibatalkan'); ?>

<?php $__env->startSection('content'); ?>
<section class="py-5" style="margin-top: 60px; background-color: #f8f9fa;">
    <div class="container">
        <div class="row d-flex justify-content-center">
            <div class="col-lg-6">
                <div class="card border-0 shadow-sm rounded-4 text-center">
                    <div class="card-body p-5">
                        <i class="bi bi-info-circle-fill text-secondary" style="font-size: 5rem;"></i>
                        <h2 class="fw-bold mt-3">Pembayaran Dibatalkan</h2>
                        <p class="text-muted">
                            Anda telah menutup jendela pembayaran. Pesanan Anda telah dibatalkan.
                        </p>
                        <hr>
                        <a href="<?php echo e(route('student.transactions.index')); ?>" class="btn btn-primary w-100 mt-3">Lihat Riwayat Transaksi</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.home-layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/wahaname/public_html/edukasi/resources/views/student/checkout/cancelled.blade.php ENDPATH**/ ?>