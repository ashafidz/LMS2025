                        <nav class="pcoded-navbar">
                            <div class="sidebar_toggle">
                                <a href="#"><i class="icon-close icons"></i></a>
                            </div>
                            <div class="pcoded-inner-navbar main-menu">
                                <div class="">
                                    <div class="main-menu-header">
                                        
                                        <div class="user-details">
                                            <span id="more-details"><?php echo e(Auth::user()->name); ?><i
                                                    class="fa fa-caret-down"></i></span>
                                        </div>
                                    </div>

                                    <div class="main-menu-content">
                                        <ul>
                                            <li class="more-details">
                                                <a href="<?php echo e(route('home')); ?>"><i class="ti-home"></i>Home</a>
                                                <a href="<?php echo e(route('user.profile.index')); ?>"><i class="ti-user"></i>
                                                    Profile</a>
                                                <a href="#!"><i class="ti-settings"></i>Settings</a>
                                                <a href="<?php echo e(route('logout')); ?>"
                                                    onclick="event.preventDefault(); document.getElementById('logout-form').submit();"><i
                                                        class="ti-layout-sidebar-left"></i>Logout</a>
                                                <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST"
                                                    style="display: none;">
                                                    <?php echo csrf_field(); ?>
                                                </form>
                                            </li>
                                        </ul>
                                    </div>
                                </div>

                                <div class="pcoded-navigation-label" data-i18n="nav.category.navigation">
                                    Menu Sidebar
                                </div>
                                <ul class="pcoded-item pcoded-left-item">
                                    
                                    <li class="<?php echo e(Request::routeIs('instructor.dashboard') ? 'active' : ''); ?>">
                                        <a href="<?php echo e(route('instructor.dashboard')); ?>" class="waves-effect waves-dark">
                                            <span class="pcoded-micon"><i class="ti-home"></i><b>D</b></span>
                                            <span class="pcoded-mtext" data-i18n="nav.dash.main">Dashboard</span>
                                            <span class="pcoded-mcaret"></span>
                                        </a>
                                    </li>
                                    

                                    
                                    <li class="<?php echo e(Request::routeIs('instructor.courses.index') ? 'active' : ''); ?>">
                                        <a href="<?php echo e(route('instructor.courses.index')); ?>" class="waves-effect waves-dark">
                                            <span class="pcoded-micon"><i class="ti-desktop"></i><b>D</b></span>
                                            <span class="pcoded-mtext" data-i18n="nav.dash.main">Manajemen Course</span>
                                            <span class="pcoded-mcaret"></span>
                                        </a>
                                    </li>
                                    

                                    
                                    <li class="<?php echo e(Request::routeIs('instructor.question-bank.topics.index') ? 'active' : ''); ?>">
                                        <a href="<?php echo e(route('instructor.question-bank.topics.index')); ?>" class="waves-effect waves-dark">
                                            <span class="pcoded-micon"><i class="fa fa-university"></i><b>FC</b></span>
                                            <span class="pcoded-mtext" data-i18n="nav.form-components.main">Bank Soal</span>
                                            <span class="pcoded-mcaret"></span>
                                        </a>
                                    </li>
                                    

                                    
                                    <li class="">
                                        <a href="#" class="waves-effect waves-dark">
                                            <span class="pcoded-micon"><i class="ti-layers"></i><b>FC</b></span>
                                            <span class="pcoded-mtext" data-i18n="nav.form-components.main">Fitur Selanjutnya</span>
                                            <span class="pcoded-mcaret"></span>
                                        </a>
                                    </li>
                                    
                                </ul>
                                
                                <ul class="pcoded-item pcoded-left-item">
                                    <li class="pcoded-hasmenu">
                                        
                                        <a
                                            href="javascript:void(0)"
                                            class="waves-effect waves-dark"
                                        >
                                            <span class="pcoded-micon"
                                                ><i class="ti-direction-alt"></i
                                                ><b>M</b></span
                                            >
                                            <span
                                                class="pcoded-mtext"
                                                data-i18n="nav.menu-levels.main"
                                                >menu level</span
                                            >
                                            <span class="pcoded-mcaret"></span>
                                        </a>
                                        
                                        <ul class="pcoded-submenu">
                                            <li class="">
                                                <a
                                                    href="javascript:void(0)"
                                                    class="waves-effect waves-dark"
                                                >
                                                    <span class="pcoded-micon"
                                                        ><i
                                                            class="ti-angle-right"
                                                        ></i
                                                    ></span>
                                                    <span
                                                        class="pcoded-mtext"
                                                        data-i18n="nav.menu-levels.menu-level-21"
                                                        >Materi</span
                                                    >
                                                    <span
                                                        class="pcoded-mcaret"
                                                    ></span>
                                                </a>
                                            </li>
                                            <li class="">
                                                <a
                                                    href="javascript:void(0)"
                                                    class="waves-effect waves-dark"
                                                >
                                                    <span class="pcoded-micon"
                                                        ><i
                                                            class="ti-angle-right"
                                                        ></i
                                                    ></span>
                                                    <span
                                                        class="pcoded-mtext"
                                                        data-i18n="nav.menu-levels.menu-level-21"
                                                        >Materi</span
                                                    >
                                                    <span
                                                        class="pcoded-mcaret"
                                                    ></span>
                                                </a>
                                            </li>
                                            
                                        </ul>
                                    </li>
                                </ul>
                                

                            </div>
                        </nav>
<?php /**PATH /home/wahaname/public_html/edukasi/resources/views/layouts/navigations/sidebars/instructor-sidebar.blade.php ENDPATH**/ ?>