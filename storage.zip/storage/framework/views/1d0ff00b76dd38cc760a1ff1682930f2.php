

<div class="card">
    <div class="card-body">
        <h5 class="card-title"><?php echo e($lesson->lessonable->title); ?></h5>
        <p class="card-text">
            <?php echo nl2br(e($lesson->lessonable->description)); ?>

        </p>
        <ul class="list-group list-group-flush">
            
            <li class="list-group-item d-flex justify-content-between">
                <span><i class="fa fa-question-circle-o mr-2"></i> Jumlah Soal</span>
                <strong><?php echo e($lesson->lessonable->questions->count()); ?> soal</strong>
            </li>
            <?php if(isset($maxScore)): ?>
            <li class="list-group-item d-flex justify-content-between">
                <span><i class="fa fa-trophy mr-2"></i> Total Skor Maksimal</span>
                <strong><?php echo e($maxScore); ?> poin</strong>
            </li>
            <?php endif; ?>
            <li class="list-group-item d-flex justify-content-between">
                <span><i class="fa fa-check-square-o mr-2"></i> Nilai Kelulusan</span>
                <strong><?php echo e($lesson->lessonable->pass_mark); ?>%</strong>
            </li>
             <li class="list-group-item d-flex justify-content-between">
                <span><i class="fa fa-check-square-o mr-2"></i> Nilai Minimum</span>
                <strong><?php echo e($minimumScore); ?></strong>
            </li>
            <li class="list-group-item d-flex justify-content-between">
                <span><i class="fa fa-clock-o mr-2"></i> Batas Waktu</span>
                <strong><?php echo e($lesson->lessonable->time_limit ? $lesson->lessonable->time_limit . ' menit' : 'Tidak ada'); ?></strong>
            </li>

            
            <?php if(!$is_preview && isset($attemptCount)): ?>
                <li class="list-group-item d-flex justify-content-between">
                    <span><i class="fa fa-repeat mr-2"></i> Kesempatan Anda</span>
                    <strong><?php echo e($attemptCount); ?> / <?php echo e($lesson->lessonable->max_attempts ?? '∞'); ?></strong>
                </li>
                <?php if(isset($lastAttempt) && $lastAttempt): ?>
                    <li class="list-group-item d-flex justify-content-between">
                        <span><i class="fa fa-star mr-2"></i> Skor Terakhir Anda</span>
                        <strong>
                            <?php echo e(rtrim(rtrim($lastAttempt->score, '0'), '.')); ?>

                            <?php if($lastAttempt->status == 'passed'): ?>
                                <span class="badge badge-success ml-2">Lulus</span>
                            <?php elseif($lastAttempt->status == 'in_progress'): ?>
                                <span class="badge badge-warning ml-2">Sedang Dikerjakan</span>
                            <?php else: ?>
                                <span class="badge badge-danger ml-2">Gagal</span>
                            <?php endif; ?>
                        </strong>
                    </li>
                <?php endif; ?>
            <?php endif; ?>

            <li class="list-group-item d-flex justify-content-between">
                <span><i class="fa fa-clock-o mr-2"></i> Boleh Melebihi Batas Waktu</span>
                <strong><?php echo e($lesson->lessonable->allow_exceed_time_limit == 1 ? 'Ya' : 'Tidak'); ?></strong>
            </li>
            <li class="list-group-item d-flex justify-content-between">
                <span><i class="fa fa-clock-o mr-2"></i> Tersedia Mulai</span>
                <strong><?php echo e($lesson->lessonable->available_from ? $lesson->lessonable->available_from->format('d F Y, H:i') : '-'); ?></strong>
            </li>
            <li class="list-group-item d-flex justify-content-between">
                <span><i class="fa fa-clock-o mr-2"></i> Tutup Pada</span>
                <strong><?php echo e($lesson->lessonable->available_to ? $lesson->lessonable->available_to->format('d F Y, H:i') : '-'); ?></strong>
            </li>


        </ul>
        <?php if($lesson->lessonable->allow_exceed_time_limit == 1): ?>
            <p class="mt-2 text-center text-danger">
                Quiz ini boleh melebihi batas waktu, tetapi anda perlu menyelesaikan kuis sebelum waktu habis untuk mendapatkan poin dan dinyatakan selesai dalam lesson ini.
            </p>
        <?php endif; ?>

        
        <div class="text-center mt-4">
            <?php if($is_preview): ?>
                
                <a href="<?php echo e(route('student.quiz.start', ['quiz' => $lesson->lessonable->id, 'preview' => 'true'])); ?>" class="btn btn-primary btn-lg">
                    Mulai Kuis (Preview)
                </a>
            <?php else: ?>
                
                <?php
                    $quiz = $lesson->lessonable;
                    // Pastikan attemptCount ada, jika tidak, anggap 0
                    $currentAttemptCount = $attemptCount ?? 0;
                    // Cek apakah siswa masih punya kesempatan
                    $canAttempt = is_null($quiz->max_attempts) || $currentAttemptCount < $quiz->max_attempts;
                ?>

                
                

                <?php if($isAvailable): ?>
                    
                    <?php if($canAttempt): ?>
                        <?php if(!isset($lastAttempt) || $lastAttempt->status != 'in_progress'): ?>
                            <a href="<?php echo e(route('student.quiz.start', $quiz->id)); ?>" class="btn btn-primary btn-lg">
                                
                                <?php echo e($currentAttemptCount > 0 ? 'Coba Lagi' : 'Mulai Kuis'); ?>

                            </a>
                        <?php else: ?>
                            <a href="<?php echo e(route('student.quiz.start', $quiz->id)); ?>" class="btn btn-primary btn-lg">
                                Lanjutkan
                            </a>
                        <?php endif; ?>
                    <?php elseif(!isset($lastAttempt)): ?>
                        
                        <a href="<?php echo e(route('student.quiz.start', $quiz->id)); ?>" class="btn btn-primary btn-lg">Mulai Kuis</a>
                    <?php else: ?>
                        
                        <p class="text-danger mt-2">Anda telah mencapai batas maksimal pengerjaan.</p>
                    <?php endif; ?>
                <?php else: ?>
                    <p class="text-danger mt-2">Kuis ini tidak tersedia saat ini.</p>
                <?php endif; ?>

            <?php endif; ?>
        </div>
    </div>
</div>



<?php if(!$is_preview && isset($allAttempts) && $allAttempts->isNotEmpty()): ?>
    <?php echo $__env->make('student.quizzes.partials._quiz_attempt_history', ['allAttempts' => $allAttempts], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php endif; ?>
<?php /**PATH /home/wahaname/public_html/edukasi/resources/views/student/quizzes/partials/_quiz_preview_in_lesson.blade.php ENDPATH**/ ?>